(function (root) {
  'use strict';
  const O = typeof module !== 'undefined' && module.exports ? require('./onboarding.js') : root.BookmarkOnboarding;
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  function createPrompt({ document, window, button, shadow, location, chrome }) {
    let hint = null, token = null, runId = null, pending = false, again = false, tutorial = false, returning = false;
    const style = document.createElement('style');
    style.textContent = `
      .quick-guide { all: initial; box-sizing: border-box; position: fixed; z-index: 2147483647;
        display: flex; flex-direction: column; gap: 8px; width: min(280px, calc(100vw - 16px));
        padding: 12px; border: 1px solid #dcdcdc; border-radius: 10px; color: #303030; background: white;
        font: 14px/1.6 "Segoe UI", "Microsoft YaHei", sans-serif; box-shadow: 0 5px 24px #0003; }
      .quick-guide p { margin: 0; overflow-y: auto; min-height: 0; }
      .quick-guide::before { content: ''; position: absolute; left: var(--pointer-left); width: 10px; height: 10px;
        background: #fff; border: 1px solid #dcdcdc; transform: translateX(-50%) rotate(45deg); }
      .quick-guide[data-pointer="up"]::before { top: -6px; border-right: 0; border-bottom: 0; }
      .quick-guide[data-pointer="down"]::before { bottom: -6px; border-left: 0; border-top: 0; }
      .quick-guide[data-pointer="none"]::before { display: none; }
      .quick-guide-actions { display: flex; flex-wrap: wrap; flex: none; align-items: center; justify-content: flex-end; gap: 8px; }
      .quick-guide button { all: unset; box-sizing: border-box; cursor: pointer; font: inherit; color: inherit;
        border: 1px solid #dcdcdc; border-radius: 5px; background: #fff; padding: 4px 10px; min-height: 32px; }
      .quick-guide button:focus-visible { outline: 2px solid #4b6480; outline-offset: 2px; }
      .quick-guide button:hover { background: #f2f2f2; }
    `;
    shadow.append(style);
    function visible(allowSaved = tutorial) {
      try {
        const box = button.getBoundingClientRect();
        return !document.hidden && !button.hidden && !button.disabled && (allowSaved || button.getAttribute('aria-disabled') !== 'true') && button.getClientRects().length > 0 &&
          box.bottom > 0 && box.top < (window.innerHeight || 600) && box.right > 0 && box.left < (window.innerWidth || 360) &&
          M.normalizeURL(location.href).kind === 'chatgpt' && (!window.getComputedStyle || window.getComputedStyle(button).visibility === 'visible');
      } catch { return false; }
    }
    function hide() { hint?.remove(); hint = null; token = null; runId = null; tutorial = false; }
    function position() {
      if (!hint) return;
      const width = window.innerWidth || 360, height = window.innerHeight || 600;
      const box = button.getBoundingClientRect();
      hint.style.maxHeight = Math.max(0, height - 16) + 'px';
      const size = hint.getBoundingClientRect();
      const right = Math.max(8, Math.min(width - box.right, width - size.width - 8));
      hint.style.right = right + 'px';
      let top = box.bottom + 10; hint.dataset.pointer = 'up';
      if (top + size.height > height - 8) {
        top = box.top - size.height - 10; hint.dataset.pointer = 'down';
        if (top < 8) { top = Math.max(8, height - size.height - 8); hint.dataset.pointer = 'none'; }
      }
      hint.style.top = top + 'px';
      hint.style.setProperty('--pointer-left', Math.max(16, Math.min(box.left + box.width / 2 - (width - right - size.width), size.width - 16)) + 'px');
    }
    async function dismiss() {
      const claim = { token, runId, url: location.href }; hide();
      try { await chrome.runtime.sendMessage({ channel: O.CHANNEL, action: 'hint-dismiss', ...claim }); }
      catch { /* Retry remains possible if the show confirmation was never stored. */ }
    }
    async function back(step) {
      if (returning) return;
      returning = true;
      try {
        const result = await chrome.runtime.sendMessage({ channel: O.CHANNEL, action: 'hint-return', url: location.href, token, runId, step });
        if (!result?.ok) throw Error(result?.error || '返回侧栏失败，请重试。');
        if (result.returned) hide();
      } catch (error) {
        const status = hint?.querySelector('[role="alert"]'); if (status) status.textContent = error.message;
      } finally { returning = false; }
    }
    function show(claim) {
      token = claim.token; runId = claim.runId; tutorial = claim.tutorial === true;
      if (hint) { position(); return; }
      hint = document.createElement('section'); hint.className = 'quick-guide';
      hint.setAttribute('role', 'dialog'); hint.setAttribute('aria-label', tutorial ? '悬浮球快速收藏' : '快速收藏提示');
      const text = document.createElement('p'); text.textContent = tutorial ? "侧栏关闭状态下，可以点击页面右侧的悬浮球将当前页面快速收藏到“未分类”。" : '侧栏已关闭，点击收藏球可快速收藏到“未分类”。';
      if (tutorial) { const progress = document.createElement('span'); progress.textContent = `2 / ${O.STEP_IDS.length - (claim.includeDots === true ? 0 : 1)}`; hint.append(progress); }
      const actions = document.createElement('div'); actions.className = 'quick-guide-actions';
      if (tutorial) for (const [label, step] of [['上一步', 0], ['返回侧栏', 1], ['下一步', 2]]) {
        const control = document.createElement('button'); control.type = 'button'; control.textContent = label; control.setAttribute('aria-label', label);
        control.addEventListener('click', event => { event.stopPropagation(); return back(step); }); actions.append(control);
      }
      for (const [label, aria] of tutorial ? [['×', '关闭教程']] : [['知道了', '知道了'], ['×', '关闭提示']]) {
        const close = document.createElement('button'); close.type = 'button'; close.textContent = label; close.setAttribute('aria-label', aria);
        close.addEventListener('click', event => { event.stopPropagation(); return dismiss(); }); actions.append(close);
      }
      hint.addEventListener('keydown', event => {
        if (event.key === 'Escape') { event.preventDefault(); void dismiss(); }
        if (tutorial && ['ArrowLeft', 'ArrowRight'].includes(event.key)) { event.preventDefault(); void back(event.key === 'ArrowLeft' ? 0 : 2); }
      });
      const status = document.createElement('p'); status.setAttribute('role', 'alert');
      hint.append(text, status, actions); shadow.append(hint); position();
    }
    async function check() {
      if (pending) { again = true; return; }
      if (!visible()) { hide(); return; }
      pending = true;
      const url = location.href, existing = token;
      try {
        const response = await chrome.runtime.sendMessage({ channel: O.CHANNEL,
          action: existing ? 'hint-status' : 'hint-claim', url, token: existing, runId });
        if (response?.ok && response.show && visible() && url === location.href) {
          show(response);
          // Confirm after the bubble is mounted and the document had a rendering opportunity.
          if (!response.confirmed) {
            if (window.requestAnimationFrame) await new Promise(resolve => window.requestAnimationFrame(() => window.requestAnimationFrame(resolve)));
            if (!hint || !visible() || location.href !== url || token !== response.token) return;
            try {
              const confirmed = await chrome.runtime.sendMessage({ channel: O.CHANNEL, action: 'hint-shown', url, token, runId });
              if (confirmed?.ok && !confirmed.show) hide();
            } catch { /* Keep the mounted bubble; a later event can retry confirmation with the same token. */ }
          }
        } else hide();
      } catch { hide(); }
      finally { pending = false; if (again) { again = false; void check(); } }
    }
    document.addEventListener('visibilitychange', () => { void check(); });
    window.addEventListener('resize', () => { position(); void check(); });
    chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes[O.KEY]) void check(); });
    chrome.runtime.onMessage?.addListener((message, sender, respond) => {
      if (sender.id === chrome.runtime.id && message?.channel === O.CHANNEL && message.action === 'hint-ready') respond?.({ ready: visible() });
      if (sender.id === chrome.runtime.id && message?.channel === O.CHANNEL && message.action === 'hint-probe') void check();
    });
    return { check, hide };
  }
  const api = { createPrompt };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkQuickGuide = api;
})(globalThis);
