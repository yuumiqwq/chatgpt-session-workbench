(function (root) {
  'use strict';
  const KEY = 'sessionBookmarksDotsGuide';
  const CLAIM_MS = 120000;
  const DISPLAY_MARGIN_MS = 500;
  function createService(storage, { now = Date.now, newToken = () => crypto.randomUUID(), hasPanel = () => true } = {}) {
    let queue = Promise.resolve();
    const serial = task => { const next = queue.then(task); queue = next.catch(() => {}); return next; };
    const read = async () => (await storage.get(KEY))[KEY];
    function claim(windowId, eligible) {
      return serial(async () => {
        if (eligible !== true || !Number.isInteger(windowId) || windowId < 0) return { show: false };
        const current = await read(), time = now();
        if (current?.version === 1 && current.status === 'shown') return { show: false };
        if (current?.version === 1 && current.status === 'claimed' && Number.isFinite(current.claimedAt) &&
            current.claimedAt + CLAIM_MS > time && current.claimedAt <= time &&
            typeof current.token === 'string' && current.token.length && hasPanel(current.windowId)) {
          if (current.windowId !== windowId) return { show: false };
          if (current.claimedAt + CLAIM_MS > time + DISPLAY_MARGIN_MS)
            return { show: true, token: current.token, expiresAt: current.claimedAt + CLAIM_MS };
          // Renew only this owner before display; other windows retain the full claim boundary.
        }
        const value = { version: 1, status: 'claimed', windowId, token: newToken(), claimedAt: time };
        await storage.set({ [KEY]: value });
        return { show: true, token: value.token, expiresAt: time + CLAIM_MS };
      });
    }
    function shown(windowId, token) {
      return serial(async () => {
        if (!Number.isInteger(windowId) || typeof token !== 'string' || !token) return { shown: false };
        const current = await read(), time = now();
        if (current?.version !== 1 || current.status !== 'claimed' ||
            current.windowId !== windowId || current.token !== token ||
            !Number.isFinite(current.claimedAt) || current.claimedAt > time || current.claimedAt + CLAIM_MS <= time) return { shown: false };
        await storage.set({ [KEY]: { version: 1, status: 'shown', shownAt: time } });
        return { shown: true };
      });
    }
    function release(windowId, token) {
      return serial(async () => {
        const current = await read();
        if (current?.version !== 1 || current.status !== 'claimed' ||
            windowId !== undefined && current.windowId !== windowId || token !== undefined && current.token !== token) return;
        await storage.set({ [KEY]: { version: 1, status: 'pending' } });
      });
    }
    function shownInTour() {
      return serial(async () => {
        const current = await read();
        if (current?.version !== 1 || current.status !== 'shown') await storage.set({ [KEY]: { version: 1, status: 'shown', shownAt: now() } });
        return { shown: true };
      });
    }
    return { claim, shown, release, shownInTour };
  }
  const api = { KEY, CLAIM_MS, DISPLAY_MARGIN_MS, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkDotsGuide = api;
})(globalThis);
