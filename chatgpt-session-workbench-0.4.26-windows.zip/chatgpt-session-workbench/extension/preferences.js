(function (root) {
  'use strict';
  const KEY = 'sessionBookmarksSelectedCategory';
  const AUTO_GROUP_KEY = 'sessionBookmarksAutoGroup';
  const MANUAL_PRO_KEY = 'sessionBookmarksManualPro';
  const valid = value => value === 'archive:removed' || typeof value === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(value);
  function createSelectionStore(storage) {
    let queue = Promise.resolve();
    return {
      async load() {
        const stored = await storage.get(KEY);
        return valid(stored[KEY]) ? stored[KEY] : 'all';
      },
      save(selected) {
        const value = valid(selected) ? selected : 'all';
        const write = queue.then(async () => {
          const stored = await storage.get(KEY);
          if (stored[KEY] !== value) await storage.set({ [KEY]: value });
        });
        queue = write.catch(() => {});
        return write;
      }
    };
  }
  function createAutoGroupStore(storage) {
    let queue = Promise.resolve();
    return {
      async load() {
        await queue;
        const stored = await storage.get(AUTO_GROUP_KEY);
        return typeof stored[AUTO_GROUP_KEY] === 'boolean' ? stored[AUTO_GROUP_KEY] : true;
      },
      save(enabled) {
        if (typeof enabled !== 'boolean') return Promise.reject(Error('自动分组选项无效。'));
        const next = queue.then(async () => {
          const stored = await storage.get(AUTO_GROUP_KEY);
          if (stored[AUTO_GROUP_KEY] !== enabled) await storage.set({ [AUTO_GROUP_KEY]: enabled });
        });
        queue = next.catch(() => {});
        return next;
      }
    };
  }
  function createManualProStore(storage) {
    let queue = Promise.resolve();
    return {
      async load() { await queue; return (await storage.get(MANUAL_PRO_KEY))[MANUAL_PRO_KEY] === true; },
      save(enabled) {
        if (typeof enabled !== 'boolean') return Promise.reject(Error('选项无效。'));
        const next = queue.then(async () => {
          if ((await storage.get(MANUAL_PRO_KEY))[MANUAL_PRO_KEY] !== enabled) await storage.set({ [MANUAL_PRO_KEY]: enabled });
        });
        queue = next.catch(() => {}); return next;
      }
    };
  }
  const api = { KEY, AUTO_GROUP_KEY, MANUAL_PRO_KEY, createSelectionStore, createAutoGroupStore, createManualProStore };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkPreferences = Object.freeze(api);
})(globalThis);
