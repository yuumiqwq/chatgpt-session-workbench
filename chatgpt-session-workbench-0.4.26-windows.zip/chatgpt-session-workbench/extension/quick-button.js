(function (root) {
  'use strict';
  const css = `
    :host { color-scheme: light; }
    .quick-button { all: initial; box-sizing: border-box; width: 44px; height: 44px;
      display: flex; align-items: center; justify-content: center; border-radius: 50%;
      border: 1px solid #333; background: #333; color: #fff; cursor: pointer;
      box-shadow: 0 2px 10px #00000026; transition: background .15s, color .15s; }
    .quick-button[hidden] { display: none; }
    .quick-button:hover { background: #494949; border-color: #494949; }
    .quick-button:active { background: #202020; border-color: #202020; }
    .quick-button:focus-visible { outline: 2px solid #4b6480; outline-offset: 3px; }
    .quick-button:disabled { cursor: wait; background: #eee; color: #aaa; border-color: #ddd; }
    .quick-button[aria-disabled="true"] { background: #eee; color: #aaa; border-color: #ddd; cursor: default; }
    .quick-button svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 1.65; stroke-linecap: round; stroke-linejoin: round; }
    @media (prefers-reduced-motion: reduce) { .quick-button { transition: none; } }
  `;
  function create(document) {
    const style = document.createElement('style'); style.textContent = css;
    const button = document.createElement('button'); button.type = 'button'; button.className = 'quick-button';
    button.setAttribute('aria-disabled', 'false');
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('aria-hidden', 'true');
    const path = document.createElementNS(svg.namespaceURI, 'path');
    path.setAttribute('d', 'M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4Z');
    svg.append(path); button.append(svg);
    return { style, button };
  }
  function preview(document) {
    const host = document.createElement('div'); host.className = 'tutorial-quick-preview';
    host.inert = true; host.setAttribute('aria-hidden', 'true');
    const shadow = host.attachShadow({ mode: 'open' }), component = create(document);
    component.button.tabIndex = -1;
    component.button.style.transform = 'scale(2)'; component.button.style.transformOrigin = 'top left';
    shadow.append(component.style, component.button);
    return host;
  }
  function geometry(button, window) {
    const box = button.getBoundingClientRect();
    if (button.hidden || !button.getClientRects().length || window.document.hidden ||
        window.getComputedStyle?.(button).visibility === 'hidden' || box.width <= 0 || box.height <= 0 ||
        box.top >= window.innerHeight || box.bottom <= 0 || box.left >= window.innerWidth || box.right <= 0) return null;
    return { centerY: box.top + box.height / 2, innerHeight: window.innerHeight, devicePixelRatio: window.devicePixelRatio };
  }
  function failure(error) {
    const text = String(error?.message || error || '扩展未返回有效结果');
    const invalidated = error?.code === 'CONTEXT_INVALIDATED' || /context invalidated/i.test(text);
    const disconnected = /receiving end|message port|message channel|channel closed|connection|could not establish/i.test(text);
    const code = invalidated ? 'CONTEXT_INVALIDATED' : error?.code || (disconnected ? 'TRANSPORT_DISCONNECTED' : 'QUICK_REQUEST_FAILED');
    return { code, message: invalidated ? '扩展已更新，请刷新当前页面后再收藏' : text, reload: invalidated, retryable: !invalidated && (disconnected || code === 'RESPONSE_INVALID') };
  }
  function createClient(runtime, { pause = ms => new Promise(resolve => setTimeout(resolve, ms)) } = {}) {
    return async (action, url) => {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          if (!runtime?.id) throw Object.assign(Error('Extension context invalidated'), { code: 'CONTEXT_INVALIDATED' });
          const result = await runtime.sendMessage({ channel: 'session-bookmarks-quick', action, url });
          if (!result || typeof result.ok !== 'boolean') throw Object.assign(Error('扩展未响应，请刷新当前页面后重试'), { code: 'RESPONSE_INVALID' });
          if (!result.ok) throw Object.assign(Error(result.error || '收藏读取或保存失败，请在侧栏检查'), { code: result.code || 'QUICK_REJECTED' });
          if (typeof result.bookmarked !== 'boolean') throw Object.assign(Error('扩展响应格式不正确，请刷新当前页面后重试'), { code: 'RESPONSE_INVALID' });
          if (action === 'quick-add' && result.bookmarked !== true) throw Object.assign(Error('保存尚未确认，请重试'), { code: 'SAVE_NOT_CONFIRMED' });
          return result.bookmarked;
        } catch (error) {
          const detail = failure(error);
          if (attempt === 0 && detail.retryable) { await pause(150); continue; }
          throw Object.assign(Error(detail.message), detail);
        }
      }
    };
  }
  const api = { css, create, preview, geometry, failure, createClient };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkQuickButton = api;
})(globalThis);
