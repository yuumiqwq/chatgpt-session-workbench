(function (root) {
  'use strict';
  const KEY = 'sessionBookmarksDailyStats';
  const DAY = 86400000;
  const MAX_PENDING_MS = 120000;
  const ID = /^[a-zA-Z0-9_-]{1,128}$/;
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const integer = value => Number.isSafeInteger(value) && value >= 0;
  // Asia/Shanghai UTC+08:00, with the reporting day starting at local 05:00.
  const OFFSET = 3 * 3600000;
  const dayKey = time => new Date(time + OFFSET).toISOString().slice(0, 10);
  const periodStart = time => Math.floor((time + OFFSET) / DAY) * DAY - OFFSET;
  const nextDay = time => periodStart(time) + DAY;
  const closedPeriod = time => ({ day: dayKey(periodStart(time) - DAY), startAt: periodStart(time) - DAY, endAt: periodStart(time) });
  const formatRange = ({ startAt, endAt }) => `${dayKey(startAt)} 05:00 – ${dayKey(endAt)} 05:00`;
  function summarize(text) {
    let characters = 0, a = 2166136261, b = 3339675911;
    for (const char of text) {
      if (/[\s\p{White_Space}]/u.test(char)) continue;
      characters++;
      const point = char.codePointAt(0);
      a = Math.imul(a ^ point, 16777619) >>> 0;
      b = Math.imul(b ^ point, 2246822519) >>> 0;
    }
    return { characters, digest: `${characters}:${a.toString(16)}:${b.toString(16)}` };
  }
  function normalize(raw) {
    if (!object(raw) || raw.version !== 1 || !integer(raw.enabledAt) || !object(raw.days) || !Array.isArray(raw.events)) throw Error('统计数据无效。');
    const days = {};
    for (const [day, value] of Object.entries(raw.days)) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day) || !object(value) || !integer(value.messages) || !integer(value.characters)) throw Error('统计数据无效。');
      days[day] = { messages: value.messages, characters: value.characters };
    }
    const events = raw.events.map(event => {
      if (!object(event) || !ID.test(event.transactionId || '') || !integer(event.sentAt) ||
          !(event.messageId === null || ID.test(event.messageId || ''))) throw Error('统计数据无效。');
      return { transactionId: event.transactionId, messageId: event.messageId, sentAt: event.sentAt };
    });
    return { version: 1, enabledAt: raw.enabledAt, days, events };
  }
  function createRepository(storage, clock = Date.now) {
    let queue = Promise.resolve();
    async function execute(action, payload = {}) {
      if (!['stats-start', 'stats-today', 'stats-record'].includes(action)) throw Error('操作不受支持。');
      const now = clock(), stored = (await storage.get(KEY))[KEY];
      let state = stored == null ? null : normalize(stored);
      if (!state) {
        if (action === 'stats-record') throw Error('统计尚未启用。');
        const start = integer(payload.startedAt) && payload.startedAt >= now - MAX_PENDING_MS && payload.startedAt <= now ? payload.startedAt : now;
        state = { version: 1, enabledAt: start, days: {}, events: [] };
        await storage.set({ [KEY]: state });
      }
      if (action === 'stats-start') return { enabledAt: state.enabledAt };
      if (action === 'stats-today') {
        const period = closedPeriod(now), available = state.enabledAt <= period.startAt;
        return { ...period, available, ...(available ? state.days[period.day] || { messages: 0, characters: 0 } : {}) };
      }
      const { transactionId, messageId = null, sentAt, characters } = payload;
      if (!ID.test(transactionId || '') || !(messageId === null || ID.test(messageId)) ||
          !integer(sentAt) || !integer(characters) || characters > 10000000 || sentAt > now + 1000) throw Error('统计记录无效。');
      if (sentAt < state.enabledAt || sentAt < now - DAY) return { recorded: false };
      if (state.events.some(event => event.transactionId === transactionId || messageId && event.messageId === messageId)) return { recorded: false };
      const day = dayKey(sentAt), previousDay = dayKey(now - 2 * DAY);
      const days = Object.fromEntries(Object.entries(state.days).filter(([key]) => key >= previousDay));
      const totals = days[day] || { messages: 0, characters: 0 };
      if (!integer(totals.messages + 1) || !integer(totals.characters + characters)) throw Error('统计数值超出范围。');
      days[day] = { messages: totals.messages + 1, characters: totals.characters + characters };
      const events = state.events.filter(event => dayKey(event.sentAt) >= previousDay);
      events.push({ transactionId, messageId, sentAt });
      await storage.set({ [KEY]: { ...state, days, events } });
      return { recorded: true };
    }
    return { dispatch(action, payload) {
      const next = queue.then(() => execute(action, payload));
      queue = next.catch(() => {});
      return next;
    } };
  }
  function createTracker({ route, entries = [], readText, newId, now = Date.now }) {
    let currentRoute = route, pending = null;
    const knownIds = new Set(), knownNodes = new WeakSet();
    const remember = items => {
      for (const item of items) { if (item.id) knownIds.add(item.id); knownNodes.add(item.node); }
      while (knownIds.size > 4096) knownIds.delete(knownIds.values().next().value);
    };
    remember(entries);
    function sync(nextRoute, items) {
      if (nextRoute === currentRoute) return;
      const firstConversation = pending && currentRoute.startsWith('new:') && nextRoute.startsWith('chatgpt:');
      currentRoute = nextRoute;
      if (!firstConversation) { pending = null; remember(items); }
    }
    return {
      get hasPending() { return pending !== null; },
      begin({ route: nextRoute, entries: items, text, sentAt = now() }) {
        sync(nextRoute, items);
        remember(items);
        const summary = summarize(text);
        // Enter/click and the corresponding submit event represent one transaction.
        if (pending && sentAt - pending.sentAt < 250 && (pending.digest === summary.digest || summary.characters === 0)) return;
        pending = { ...summary, transactionId: newId(), sentAt };
      },
      observe({ route: nextRoute, entries: items, observedAt = now() }) {
        sync(nextRoute, items);
        if (pending && observedAt - pending.sentAt > MAX_PENDING_MS) pending = null;
        if (!pending) { remember(items); return null; }
        for (const item of items) {
          if (item.author !== 'user' || knownNodes.has(item.node) || item.id && knownIds.has(item.id)) continue;
          const summary = summarize(readText(item));
          if (summary.digest !== pending.digest) continue;
          const record = { transactionId: pending.transactionId, messageId: item.id || null, sentAt: pending.sentAt, characters: pending.characters };
          pending = null; remember(items); return record;
        }
        return null;
      },
      reset({ route: nextRoute, entries: items }) { pending = null; currentRoute = nextRoute; remember(items); }
    };
  }
  const api = { KEY, dayKey, nextDay, closedPeriod, formatRange, summarize, createRepository, createTracker };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkStatistics = api;
})(globalThis);
