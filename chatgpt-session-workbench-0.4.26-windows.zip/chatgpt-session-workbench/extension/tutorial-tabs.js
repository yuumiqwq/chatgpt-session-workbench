(function (root) {
  'use strict';
  const KEY = 'sessionBookmarksTutorialTab';
  function createService({ browser }) {
    let queue = Promise.resolve(), memory = null;
    const serial = operation => { const next = queue.then(operation); queue = next.catch(() => {}); return next; };
    const read = async () => browser.storage.session ? (await browser.storage.session.get(KEY))[KEY] : memory;
    async function save(record) {
      if (browser.storage.session) await browser.storage.session.set({ [KEY]: record });
      memory = record;
    }
    async function release(record) {
      if (!Number.isInteger(record?.tabId) || !Number.isInteger(record.windowId) || !record.runId ||
          !/^https:\/\/chatgpt\.com\/#workbench-tutorial-[\da-f-]{36}$/.test(record.url)) return;
      let tab;
      try { tab = await browser.tabs.get(record.tabId); } catch { return; }
      if (tab?.windowId === record.windowId && (tab.pendingUrl || tab.url) === record.url && !tab.active) await browser.tabs.remove(tab.id);
    }
    return {
      sync: (view, windowId) => serial(async () => {
        const record = await read();
        if (record?.windowId === windowId) { await release(record); await save(null); }
        return view;
      }),
      close: (view, windowId) => serial(async () => {
        const record = await read();
        if (record?.windowId === windowId) { await release(record); await save(null); }
        return view;
      }),
      releaseWindow: windowId => serial(async () => {
        const record = await read();
        if (record && (windowId === undefined || record.windowId === windowId)) { await release(record); await save(null); }
      })
    };
  }
  const api = { KEY, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkTutorialTabs = api;
})(globalThis);
