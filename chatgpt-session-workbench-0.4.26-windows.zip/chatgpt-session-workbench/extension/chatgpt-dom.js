(function (root) {
  'use strict';
  const ID = /^[a-zA-Z0-9_-]{1,128}$/;
  const UUID = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
  const COMPOSER = '[data-composer-markdown][contenteditable="true"], #prompt-textarea, textarea[data-testid="prompt-textarea"], textarea[placeholder]';
  const STOP = '[data-testid="stop-button"], [data-testid="stop-generating-button"], button[aria-label="Stop generating"], button[aria-label="停止生成"], button[aria-label="停止"]';
  const BUSY = `${STOP}, [data-is-streaming="true"], [data-message-status="in_progress"], .result-streaming`;
  const COMPLETED = '[data-testid="copy-turn-action-button"], [data-testid="good-response-turn-action-button"], [data-testid="bad-response-turn-action-button"]';
  const WORK_AGENT = '[data-chatgpt-agent-turn-start]';
  function rendered(node, allowContents) {
    if (!node || node.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
    const copy = node.closest('[data-chatgpt-search-message-ids]');
    if (copy?.getAttribute('data-chatgpt-search-message-ids')?.startsWith('fallback-turn-')) return false;
    const css = root.getComputedStyle(node);
    if (css.visibility === 'hidden' || css.visibility === 'collapse' || css.display === 'none') return false;
    return Boolean(node.getClientRects().length) || Boolean(allowContents && css.display === 'contents' && rendered(node.parentElement, true));
  }
  function visible(node) { return rendered(node, false); }
  function messages(document) {
    const result = [];
    for (const node of document.querySelectorAll(`[data-message-author-role], h4, ${WORK_AGENT}`)) {
      let author = node.getAttribute('data-message-author-role'), turn, body = node, id;
      if (author) {
        if (!['user', 'assistant', 'tool'].includes(author) || !visible(node)) continue;
        turn = node.closest('[data-testid^="conversation-turn-"], article') || node;
        const value = node.getAttribute('data-message-id');
        id = ID.test(value || '') ? value : null;
      } else {
        turn = node.closest('[data-talvt-turn-state]');
        const agentStart = node.matches(WORK_AGENT);
        if (!turn || node.closest('[data-message-author-role]') || !visible(turn) ||
            !(agentStart ? rendered(node.parentElement, true) : visible(node))) continue;
        const label = node.textContent.trim();
        author = agentStart || node.getAttribute('data-conversation-role') === 'assistant' ? 'assistant' :
          /^(?:你说[：:]|You said:)$/.test(label) ? 'user' : /^(?:ChatGPT\s*说[：:]|ChatGPT said:)$/.test(label) ? 'assistant' : null;
        if (!author) continue;
        const key = turn.closest('[data-turn-key]')?.getAttribute('data-turn-key');
        id = UUID.test(key || '') ? `work-${key.toLowerCase()}-${author}` : null;
        body = node.nextElementSibling;
        // The ChatGPT turn layout mounts a hidden agent-start sentinel before reasoning/tools, and only
        // mounts the assistant heading for a final answer. Both describe one turn.
        const earlier = result.findIndex(item => item.turn === turn && item.author === author && item.id === id);
        if (earlier >= 0) result.splice(earlier, 1);
      }
      result.push({ node, turn, body, author, id });
    }
    return result;
  }
  function permissionEvidence(last) {
    const result = { detected: false, reason: 'no-tail', scope: null, controls: 0, allow: 0, deny: 0, depth: null };
    if (!last) return result;
    const { node, turn, author } = last;
    if (!['assistant', 'tool'].includes(author)) return { ...result, reason: 'not-assistant' };
    if (turn.getAttribute('data-talvt-turn-state') === 'complete' || node.getAttribute('data-message-status') === 'complete' ||
        node.getAttribute('data-is-streaming') === 'false') return { ...result, reason: 'completed-turn' };
    const work = turn.closest('[data-turn-key]');
    const scope = work && UUID.test(work.getAttribute('data-turn-key') || '') ? work : turn;
    result.scope = scope === turn ? 'message-turn' : 'work-turn';
    const ordered = [...scope.querySelectorAll(`[data-message-author-role], h4, ${WORK_AGENT}, button, [role="button"]`)];
    const anchor = ordered.findIndex(part => part === node || part.matches(WORK_AGENT) && part.closest('[data-talvt-turn-state]') === turn);
    const controls = ordered.slice(anchor + 1).filter(button =>
      button.matches('button, [role="button"]') && visible(button) && !button.disabled && button.getAttribute('disabled') === null &&
      !button.closest('[aria-disabled="true"], fieldset[disabled], pre, code, blockquote, [data-message-author-role="user"], [class~="group/user-message"], [data-talvt-turn-state="complete"], [data-message-status="complete"], [data-is-streaming="false"]'));
    function actionText(part) {
      if (part.nodeType === 3) return part.textContent;
      if (part.nodeType !== 1 || part.matches('kbd, svg, [aria-hidden="true"], [hidden]')) return '';
      return [...part.childNodes].map(actionText).join('');
    }
    // Normalize only a trailing keyboard hint/icon, never arbitrary permission prose.
    const label = button => (button.getAttribute('aria-label') || actionText(button)).trim().replace(/\s+/g, ' ')
      .replace(/(?:\s*(?:Esc|Escape|Enter|Return|回车|↵|⏎|⌄|▾|▼))+$/i, '').trim();
    const allow = /^(?:允许|允许一次|允许本次|始终允许|批准|批准一次|批准此请求|Allow|Allow once|Always allow|Approve|Approve once|Approve request)$/i;
    const deny = /^(?:拒绝|不允许|拒绝请求|Deny|Deny request|Reject|Reject request|Don't allow|Do not allow)$/i;
    const allows = controls.filter(button => allow.test(label(button))), denies = controls.filter(button => deny.test(label(button)));
    Object.assign(result, { controls: controls.length, allow: allows.length, deny: denies.length, reason: 'no-action-pair' });
    for (const button of allows) {
      let card = button.parentElement;
      for (let depth = 0; depth < 8 && card && card !== scope && !card.contains(node); depth++, card = card.parentElement) {
        const buttons = [...card.querySelectorAll('button, [role="button"]')];
        if (buttons.length <= 12 && buttons.some(other => denies.includes(other))) return { ...result, detected: true, reason: 'action-pair', depth };
      }
    }
    if (allows.length && denies.length) result.reason = 'unbounded-action-pair';
    return result;
  }
  function reply(document, entries = messages(document), busy) {
    if (!entries.length) return null;
    const last = entries.at(-1), users = entries.filter(m => m.author === 'user');
    const { node, turn, author } = last;
    if (busy === undefined) busy = generationActive(document, last);
    const ended = turn.getAttribute('data-talvt-turn-state') === 'complete' ||
      node.getAttribute('data-is-streaming') === 'false' || node.getAttribute('data-message-status') === 'complete';
    const completed = ended ||
      [...turn.querySelectorAll(COMPLETED)].some(visible);
    const permission = permissionEvidence(last).detected;
    const turnUser = last.id?.startsWith('work-') ? users.findLast(message => message.turn === turn) : users.at(-1);
    const precedingMessageIds = turnUser ? [...new Set(entries.slice(entries.indexOf(turnUser) + 1, -1)
      .filter(message => message.author !== 'user' && message.id && message.id !== last.id).map(message => message.id))].slice(-256) : [];
    return { author, phase: author === 'user' ? 'complete' : permission ? 'awaiting_permission' : busy ? 'generating' : author === 'assistant' && completed ? 'complete' : 'unknown',
      messageId: last.id, userMessageId: turnUser?.id || null, userMessageIds: users.map(m => m.id).filter(Boolean).slice(-256), precedingMessageIds };
  }
  function generationActive(document, last = messages(document).at(-1)) {
    const turn = last?.turn;
    return turn?.getAttribute('data-talvt-turn-state') === 'in_progress' ||
      last?.node.getAttribute('data-message-status') === 'in_progress' ||
      [...document.querySelectorAll(BUSY)].some(node => rendered(node, true)) || turn?.getAttribute('aria-busy') === 'true' ||
      Boolean(turn && [...turn.querySelectorAll('[aria-busy="true"]')].some(node => rendered(node, true)));
  }
  function replySignal(document, last, busy) {
    if (!last) return '';
    const { node, turn } = last;
    const state = turn.getAttribute('data-talvt-turn-state'), status = node.getAttribute('data-message-status');
    busy = busy === false ? false : state === 'in_progress' || status === 'in_progress' ||
      (turn.matches(`${BUSY}, [aria-busy="true"]`) && rendered(turn, true)) ||
      [...turn.querySelectorAll(`${BUSY}, [aria-busy="true"]`)].some(part => rendered(part, true)) ||
      [...document.querySelectorAll(STOP)].some(part => rendered(part, true));
    return JSON.stringify([node.isConnected, visible(turn), node.getAttribute('data-message-id'),
      turn.closest('[data-turn-key]')?.getAttribute('data-turn-key'), state, status, node.getAttribute('data-is-streaming'), busy,
      !busy && [...turn.querySelectorAll(COMPLETED)].some(visible)]);
  }
  function activeTurnEvidence(entries, observed) {
    const last = entries.at(-1);
    if (observed?.author !== 'assistant' || !['generating', 'awaiting_permission'].includes(observed.phase) ||
        last?.turn.getAttribute('data-talvt-turn-state') !== 'in_progress') return null;
    const turnId = last.turn.closest('[data-turn-key]')?.getAttribute('data-turn-key')?.toLowerCase();
    return UUID.test(turnId || '') && last.id === `work-${turnId}-assistant` &&
      (!observed.userMessageId || observed.userMessageId === `work-${turnId}-user`) ? { turnId } : null;
  }
  function replyEvidence(document, entries = messages(document)) {
    const last = entries.at(-1), node = last?.node, turn = last?.turn;
    return { messages: entries.length, permission: permissionEvidence(last),
      generation: { active: generationActive(document, last),
        turn: turn?.getAttribute('data-talvt-turn-state') === 'in_progress',
        message: node?.getAttribute('data-message-status') === 'in_progress',
        streaming: !!turn && [...turn.querySelectorAll('[data-is-streaming="true"], .result-streaming')].some(n => rendered(n, true)),
        stop: [...document.querySelectorAll(STOP)].some(n => rendered(n, true)),
        ariaBusy: turn?.getAttribute('aria-busy') === 'true' || !!turn && [...turn.querySelectorAll('[aria-busy="true"]')].some(n => rendered(n, true)) },
      completion: { turn: turn?.getAttribute('data-talvt-turn-state') === 'complete',
        message: node?.getAttribute('data-message-status') === 'complete', streamingEnded: node?.getAttribute('data-is-streaming') === 'false',
        actions: !!turn && [...turn.querySelectorAll(COMPLETED)].some(visible) } };
  }
  function completedTurnEvidence(entries, observed) {
    const last = entries.at(-1);
    if (observed?.author !== 'assistant' || observed.phase !== 'complete' || !last ||
        last.turn.getAttribute('data-talvt-turn-state') !== 'complete') return null;
    const turnId = last.turn.closest('[data-turn-key]')?.getAttribute('data-turn-key')?.toLowerCase();
    if (!UUID.test(turnId || '') || last.id !== `work-${turnId}-assistant` ||
        observed.userMessageId !== `work-${turnId}-user` ||
        !entries.some(item => item.author === 'user' && item.id === observed.userMessageId && item.turn === last.turn)) return null;
    return { turnId };
  }
  function textOnly(node) {
    if (!rendered(node, true)) return '';
    // Walk the rendered text leaves; controls and attachment metadata never enter the digest/count.
    const skip = 'button, svg, img, picture, video, audio, input, script, style, [hidden], [inert], [aria-hidden="true"], [data-testid*="attachment"], [data-testid*="file-thumbnail"], [download], [contenteditable="false"]';
    function read(part) {
      if (part.nodeType === 3) return part.textContent;
      if (part.nodeType !== 1 || part.matches(skip) || !rendered(part, true)) return '';
      return [...part.childNodes].map(read).join('');
    }
    return read(node);
  }
  function userText(message) {
    if (message.author !== 'user' || !message.body) return '';
    const bubbles = [...message.body.querySelectorAll('[data-user-message-bubble="true"]')].filter(node => rendered(node, true));
    if (bubbles.length) return bubbles.map(textOnly).join('\n');
    const selector = message.id?.startsWith('work-') ? 'div.w-full[data-content-search-unit-key]' : '.whitespace-pre-wrap';
    const bodies = [message.body, ...message.body.querySelectorAll(selector)].filter(node => node.matches(selector) && rendered(node, true));
    // The turn wrapper also contains selected-text and image controls, outside the body div.
    return bodies.length ? bodies.filter(n => !bodies.some(other => other !== n && other.contains(n))).map(textOnly).join('\n') :
      message.id?.startsWith('work-') ? '' : textOnly(message.body);
  }
  function userHasAttachment(message) {
    return message.author === 'user' && !!message.body &&
      [...message.body.querySelectorAll('img, a[download]')].some(visible);
  }
  function composer(document) { return [...document.querySelectorAll(COMPOSER)].find(visible) || null; }
  function composerText(node) { return node?.tagName.toLowerCase() === 'textarea' ? node.value : textOnly(node); }
  function sendButton(node) {
    const button = node?.closest('button');
    if (!button || !visible(button) || button.disabled || button.getAttribute('aria-disabled') === 'true') return false;
    return ['send-button', 'composer-submit-button'].includes(button.getAttribute('data-testid')) ||
      /^(?:发送|发送消息|发送提示|Send|Send message|Send prompt)$/i.test(button.getAttribute('aria-label') || '');
  }
  // Keep text inside the content-script world. Only IDs and status cross the message channel.
  function sendSummary(text) { return root.BookmarkStatistics.summarize(text.normalize('NFC')); }
  function replyFingerprint(document, last = messages(document).at(-1)) {
    return last ? sendSummary(textOnly(last.body || last.node)).digest : '';
  }
  function createReplyMachine() {
    let state = 'idle', key = '', user = '', generated = false, fingerprint = '', quietAt = 0;
    return {
      reset() { state = 'idle'; key = ''; user = ''; generated = false; fingerprint = ''; quietAt = 0; },
      observe(value, textKey, now, busy = false) {
        // Quiet time begins when an observed active generation ends, not at its
        // last token. Streaming can be quiet for seconds before the stop disappears.
        if (['generating', 'awaiting_permission'].includes(state) && !busy && !['generating', 'awaiting_permission'].includes(value.phase)) quietAt = now;
        const nextKey = `${value.userMessageId}:${value.messageId}`;
        if (value.userMessageId !== user && !(user == null && key.endsWith(`:${value.messageId}`))) {
          generated = false;
        }
        user = value.userMessageId;
        if (nextKey !== key) { key = nextKey; fingerprint = ''; quietAt = now; }
        if (textKey !== fingerprint) { fingerprint = textKey; quietAt = now; }
        if (busy) generated = true;
        let reason;
        if (value.author === 'user') { state = 'idle'; reason = 'user-committed'; }
        else if (value.phase === 'awaiting_permission') { state = 'awaiting_permission'; generated = false; quietAt = now; reason = 'permission-controls'; }
        else if (value.phase === 'generating') { state = 'generating'; generated = true; quietAt = now; reason = 'generation-signal'; }
        // Explicit completion also covers history loaded in batches. Route/message
        // ownership and retired IDs are checked by the collector and repository.
        else if (value.author === 'assistant' && (value.phase === 'complete' || generated)) {
          state = now - quietAt >= 300 ? 'completed' : 'candidate';
          reason = value.phase === 'complete' ? 'completion-signal-quiet' : 'generation-ended-quiet';
        } else { state = 'idle'; reason = 'no-active-signal'; }
        return { state, reason,
          value: state === 'completed' ? { ...value, phase: 'complete' } : value };
      }
    };
  }
  const api = { visible, messages, reply, userText, userHasAttachment, composer, composerText, sendButton,
    sendSummary, replyFingerprint, createReplyMachine, generationActive, replySignal, permissionEvidence, replyEvidence, completedTurnEvidence, activeTurnEvidence };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkChatDOM = api;
})(globalThis);
