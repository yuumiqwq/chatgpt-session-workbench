(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  function pageIdForBookmark(id) { return id.startsWith('dots:') ? 'dots:home' : id; }
  function navigationLink(input) {
    if (input === 'https://chatgpt.com/') return { kind: 'chatgpt', id: 'chatgpt:home', url: input };
    return input === 'https://chatgpt.com/dots/home' ? { kind: 'dots', id: 'dots:home', url: input } : M.normalizeURL(input);
  }
  function tabConversationId(tab) {
    try {
      const link = navigationLink(tab.pendingUrl || tab.url);
      return ['chatgpt', 'dots'].includes(link.kind) ? link.id : null;
    } catch { return null; }
  }
  // baseIndex is a stable fallback, never the current DOM order or a claimed chat timestamp.
  // A project supplies all member IDs, including members hidden by the title filter.
  function sortByOpen(items, openOrder) {
    const rank = item => item.bookmarkIds.reduce((first, id) => {
      if (!id.startsWith('chatgpt:') && !id.startsWith('dots:')) return first;
      const pageId = pageIdForBookmark(id);
      return openOrder.has(pageId) ? Math.min(first, openOrder.get(pageId)) : first;
    }, Infinity);
    return items.map(item => ({ item, rank: rank(item) }))
      .sort((a, b) => {
        if (a.rank !== b.rank) return a.rank < b.rank ? -1 : 1;
        if (a.rank === Infinity) {
          const activity = (b.item.activityAt ?? -1) - (a.item.activityAt ?? -1);
          if (activity) return activity;
        }
        return a.item.baseIndex - b.item.baseIndex;
      })
      .map(entry => entry.item);
  }
  async function finishCreatedTab(tab, onCreated, createdURL) {
    if (onCreated) {
      try { await onCreated(tab, createdURL); }
      catch {
        const error = new Error('页面已打开，自动分组失败。'); error.opened = true; throw error;
      }
    }
    return tab;
  }
  function createNavigator(browser, { onCreated } = {}) {
    const pending = new Map();
    async function activate(link) {
      const tabs = await browser.tabs.query({});
      const match = tabs.find(tab => {
        if (!Number.isInteger(tab.id) || tab.id < 0) return false;
        return tabConversationId(tab) === link.id;
      });
      if (!match) {
        const tab = await browser.tabs.create({ url: link.url, active: true });
        return finishCreatedTab(tab, onCreated, link.url);
      }
      await browser.tabs.update(match.id, { active: true });
      await browser.windows.update(match.windowId, { focused: true });
      return match;
    }
    return function open(input) {
      const link = navigationLink(input);
      if (link.kind !== 'chatgpt') return Promise.resolve(false);
      if (!pending.has(link.id)) {
        // Coalesce repeated activation while querying/creating; never create on an API failure.
        const operation = activate(link).finally(() => pending.delete(link.id));
        pending.set(link.id, operation);
      }
      return pending.get(link.id);
    };
  }
  function createTabTracker(browser, changed) {
    let sequence = 0;
    let timer;
    let closed = false;
    let firstSnapshot = true;
    let nextOrder = 0;
    const tabOrders = new Map();
    const subscriptions = [];
    let lastSnapshot = null;
    function observe(tab, initialOrder) {
      const id = tabConversationId(tab);
      let record = tabOrders.get(tab.id);
      if (!record) {
        record = { order: initialOrder ?? ++nextOrder, conversationId: id, hasMatched: Boolean(id) };
        tabOrders.set(tab.id, record);
      } else {
        // Entering a different conversation (or returning after leaving it) is a new opening.
        // A newly created blank tab retains its reserved position when its first URL arrives.
        if (id && id !== record.conversationId && record.hasMatched) record.order = ++nextOrder;
        record.conversationId = id;
        record.hasMatched ||= Boolean(id);
      }
      return record;
    }
    async function refresh() {
      const ticket = ++sequence;
      let snapshot = { openIds: new Set(), openOrder: new Map(), activeId: null, windowActiveIds: new Map() };
      const activeTabs = [];
      try {
        const [tabs, focused] = await Promise.all([
          browser.tabs.query({}),
          browser.windows?.getLastFocused ? browser.windows.getLastFocused().catch(() => null) : null
        ]);
        if (closed || ticket !== sequence) return;
        const present = new Set(tabs.map(tab => tab.id));
        for (const id of tabOrders.keys()) if (!present.has(id)) tabOrders.delete(id);
        for (const [index, tab] of tabs.entries()) {
          // Existing tabs have no creation timestamp. On the first successful query only,
          // use its stable snapshot order before newly observed onCreated events.
          const record = observe(tab, firstSnapshot ? index - tabs.length : undefined);
          const id = tabConversationId(tab);
          if (tab.active) {
            snapshot.windowActiveIds.set(tab.windowId, id);
            activeTabs.push([tab.windowId, tab.id, tab.pendingUrl || tab.url, tab.status]);
          }
          if (!id) continue;
          snapshot.openIds.add(id);
          snapshot.openOrder.set(id, Math.min(snapshot.openOrder.get(id) ?? Infinity, record.order));
          if (tab.active && tab.windowId === focused?.id) snapshot.activeId = id;
        }
        firstSnapshot = false;
      } catch { /* A preview or unavailable API simply has no tab highlighting. */ }
      const signature = JSON.stringify([snapshot.activeId, [...snapshot.openOrder].sort(), activeTabs.sort((a, b) => a[0] - b[0])]);
      if (!closed && ticket === sequence && signature !== lastSnapshot) { lastSnapshot = signature; changed(snapshot); }
    }
    function schedule() {
      sequence++; // An event invalidates any in-flight pre-event query immediately.
      clearTimeout(timer);
      timer = setTimeout(() => { void refresh(); }, 50);
    }
    const created = tab => {
      if (Number.isInteger(tab?.id)) observe(tab);
      schedule();
    };
    const updated = (id, changes, tab) => {
      if (Number.isInteger(id) && (tabOrders.has(id) || !firstSnapshot) && (tab || typeof changes?.url === 'string')) observe(tab || { id, url: changes.url });
      schedule();
    };
    const removed = id => { tabOrders.delete(id); schedule(); };
    for (const [event, listener] of [[browser?.tabs?.onCreated, created], [browser?.tabs?.onUpdated, updated], [browser?.tabs?.onRemoved, removed], [browser?.tabs?.onActivated, schedule], [browser?.windows?.onFocusChanged, schedule]]) {
      if (!event?.addListener) continue;
      event.addListener(listener); subscriptions.push([event, listener]);
    }
    return { refresh, destroy() {
      closed = true; sequence++; clearTimeout(timer);
      for (const [event, listener] of subscriptions) event.removeListener?.(listener);
      tabOrders.clear();
    } };
  }
  function createCloser(browser) {
    const pending = new Map();
    return function close(input) {
      const link = navigationLink(input);
      if (!['chatgpt', 'dots'].includes(link.kind)) return Promise.resolve(false);
      if (!pending.has(link.id)) {
        const operation = (async () => {
          const [tabs, current] = await Promise.all([browser.tabs.query({}), browser.windows.getCurrent()]);
          const matches = tabs.filter(t => Number.isInteger(t.id) && t.id >= 0 && tabConversationId(t) === link.id)
            .sort((a, b) => Number(b.windowId === current.id) - Number(a.windowId === current.id) ||
              a.windowId - b.windowId || (a.index ?? 0) - (b.index ?? 0) || a.id - b.id);
          for (const candidate of matches) {
            let tab;
            try { tab = await browser.tabs.get(candidate.id); }
            catch (error) {
              // Only an absent ID in a fresh snapshot proves that this target
              // disappeared; other API failures must remain visible.
              if (!(await browser.tabs.query({})).some(t => t.id === candidate.id)) continue;
              throw error;
            }
            if (tabConversationId(tab) !== link.id) continue;
            await browser.tabs.remove(tab.id);
            return tab.id;
          }
          return false;
        })().finally(() => pending.delete(link.id));
        pending.set(link.id, operation);
      }
      return pending.get(link.id);
    };
  }
  function createPanelContext(browser, { onCreated, onReady, isVisible = () => true } = {}) {
    let port = null;
    let categoryId = null;
    let closed = false;
    let retry;
    let windowId;
    let creatingChat = null;
    async function resolveWindow() {
      try { windowId = (await browser.windows.getCurrent()).id; }
      catch { windowId = (await browser.tabs.query({ active: true, currentWindow: true }))[0]?.windowId; }
      if (!Number.isInteger(windowId) || windowId < 0) throw new Error('无法读取侧栏所属窗口。');
      return windowId;
    }
    const ready = resolveWindow();
    function report() {
      if (!port) return;
      try { port.postMessage({ windowId, categoryId, visible: isVisible() }); }
      catch { /* Disconnection falls back to unfiled until a new connection is registered. */ }
    }
    function connect() {
      if (closed) return;
      try {
        const connection = browser.runtime.connect({ name: 'session-bookmarks-panel' });
        port = connection;
        let registered = false;
        connection.onMessage?.addListener(message => {
          if (closed || port !== connection || registered || message?.channel !== 'session-bookmarks-panel' ||
              message.action !== 'ready' || message.windowId !== windowId) return;
          registered = true; onReady?.();
        });
        connection.onDisconnect.addListener(() => {
          void browser.runtime.lastError;
          if (port !== connection) return;
          port = null;
          if (!closed) retry = setTimeout(connect, 250);
        });
        report();
      } catch { /* An unloaded extension stays usable only after reloading its page. */ }
    }
    void ready.then(connect).catch(() => {});
    return {
      setCategory(value) { categoryId = value || null; report(); },
      reportVisibility: report,
      getWindowId: () => ready,
      async getActiveTab() {
        return (await browser.tabs.query({ active: true, windowId: await ready }))[0];
      },
      createChat() {
        if (!creatingChat) {
          creatingChat = (async () => {
            const tab = await browser.tabs.create({ url: 'https://chatgpt.com/', active: true, windowId: await ready });
            return finishCreatedTab(tab, onCreated, 'https://chatgpt.com/');
          })().finally(() => { creatingChat = null; });
        }
        return creatingChat;
      },
      destroy() { closed = true; clearTimeout(retry); port?.disconnect(); port = null; }
    };
  }
  const api = { createNavigator, createCloser, createTabTracker, createPanelContext, sortByOpen, pageIdForBookmark };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkNavigation = Object.freeze(api);
})(globalThis);
