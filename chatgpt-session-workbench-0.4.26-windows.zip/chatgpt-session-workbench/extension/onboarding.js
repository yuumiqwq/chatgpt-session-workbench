(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const P = typeof module !== 'undefined' && module.exports ? require('./preferences.js') : root.BookmarkPreferences;
  const KEY = 'sessionBookmarksOnboarding';
  const CHANNEL = 'session-bookmarks-onboarding';
  const STEP_IDS = Object.freeze(['collect', 'quick', 'codex', 'dots', 'organize', 'open', 'close', 'new', 'markers', 'remove']);
  const V2_STEP_IDS = ['collect', 'quick', 'codex', 'dots', 'organize', 'open', 'actions', 'markers', 'remove'];
  const LEGACY_STEP_IDS = ['collect', 'quick', 'organize', 'open', 'actions', 'markers', 'remove'];
  const LAST_STEP = STEP_IDS.length - 1, HINT_STEP = STEP_IDS.indexOf('quick');
  const windowNumber = value => Number.isInteger(value) && value >= 0;
  const lastPart = step => STEP_IDS[step] === 'codex' ? 1 : 0;
  const empty = status => ({ version: 3, status, runId: null, windowId: null, step: 0, part: 0, hint: 'off', claim: null });
  function createStore(storage, { hasPanel = () => false, getTab = async () => null, newId = () => crypto.randomUUID() } = {}) {
    let queue = Promise.resolve();
    const serial = fn => { const next = queue.then(fn); queue = next.catch(() => {}); return next; };
    async function read() {
      const raw = (await storage.get(KEY))[KEY];
      if (raw === undefined) return null;
      if (![1, 2, 3].includes(raw?.version) || !['pending', 'active', 'completed', 'skipped', 'existing'].includes(raw.status) ||
          !Number.isInteger(raw.step) || raw.step < 0 || raw.step >= (raw.version === 1 ? LEGACY_STEP_IDS.length : raw.version === 2 ? V2_STEP_IDS.length : STEP_IDS.length) ||
          raw.version === 3 && (!Number.isInteger(raw.part) || raw.part < 0 || raw.part > lastPart(raw.step)) ||
          !['off', 'pending', 'claimed', 'shown', 'done', 'cancelled'].includes(raw.hint)) return empty('existing');
      if (raw.version < 3) {
        const id = (raw.version === 1 ? LEGACY_STEP_IDS : V2_STEP_IDS)[raw.step];
        return save({ ...raw, version: 3, step: STEP_IDS.indexOf(id === 'dots' ? 'organize' : id === 'actions' ? 'close' : id), part: 0 });
      }
      // Older active walkthroughs may have been left on Dots. Resume at categories.
      if (raw.version === 3 && raw.status === 'active' && raw.step === STEP_IDS.indexOf('dots') && raw.includeDots !== true)
        return save({ ...raw, step: STEP_IDS.indexOf('organize'), part: 0 });
      return raw;
    }
    async function save(state) { await storage.set({ [KEY]: state }); return state; }
    const view = (state, windowId) => state?.status === 'active' && state.windowId === windowId && !Number.isInteger(state.pageTabId) ?
      { show: true, runId: state.runId, step: state.step, part: state.part, ...(state.includeDots === true ? { includeDots: true } : {}) } : { show: false };
    async function eligible(state, context, allowPanel = false) {
      const transferred = state?.status === 'active' && state.step === HINT_STEP && state.pageTabId === context.tabId;
      if (!state || !['active', 'completed'].includes(state.status) || state.windowId !== context.windowId || hasPanel(state.windowId) && !transferred && !allowPanel) return false;
      const tab = await getTab(context.tabId);
      if (!tab || tab.id !== context.tabId || !tab.active || tab.windowId !== state.windowId || hasPanel(state.windowId) && !transferred && !allowPanel) return false;
      try { const link = M.normalizeURL(tab.pendingUrl || tab.url); return link.kind === 'chatgpt' && link.id === context.id; }
      catch { return false; }
    }
    async function execute(action, payload = {}, context = {}) {
      let state = await read();
      if (action.startsWith('tutorial-')) {
        const windowId = payload.windowId;
        if (!windowNumber(windowId) || !hasPanel(windowId)) throw Error('教程窗口不可用。');
        if (action === 'tutorial-restart' || action === 'tutorial-open' && state?.status === 'pending') {
          const includeDots = action === 'tutorial-restart' && (await storage.get(P.MANUAL_PRO_KEY))[P.MANUAL_PRO_KEY] === true;
          state = await save({ ...empty('active'), windowId, runId: newId(), ...(includeDots ? { includeDots: true } : {}) });
        } else if (action !== 'tutorial-open') {
          if (!['tutorial-step', 'tutorial-finish', 'tutorial-skip', 'tutorial-handoff'].includes(action)) throw Error('教程操作无效。');
          if (state?.status !== 'active' || state.windowId !== windowId || state.runId !== payload.runId) return { show: false };
          if (action === 'tutorial-handoff') {
            if (state.step !== HINT_STEP || payload.expectedStep !== HINT_STEP || !windowNumber(payload.tabId)) return view(state, windowId);
            const tab = await getTab(payload.tabId);
            if (!tab?.active || tab.windowId !== windowId) throw Error('当前网页不可用。');
            try { if (M.normalizeURL(tab.pendingUrl || tab.url).kind !== 'chatgpt') throw Error(); }
            catch { throw Error('请先打开 ChatGPT 会话页。'); }
            await save({ ...state, pageTabId: tab.id, hint: 'pending', claim: null });
            return { show: false, handoff: true, runId: state.runId };
          }
          if (action === 'tutorial-skip') state = await save({ ...state, status: 'skipped', hint: 'cancelled', claim: null });
          else if (payload.expectedStep === state.step && (payload.expectedPart ?? 0) === state.part) {
            if (action === 'tutorial-finish') {
              if (state.step !== LAST_STEP) throw Error('教程尚未完成。');
              state = await save({ ...state, status: 'completed' });
            } else {
              const part = payload.part ?? 0;
              const forward = state.part < lastPart(state.step) ? { step: state.step, part: state.part + 1 } : { step: state.step + 1, part: 0 };
              if (forward.step === STEP_IDS.indexOf('dots') && state.includeDots !== true) forward.step++;
              const backward = state.part > 0 ? { step: state.step, part: state.part - 1 } : { step: state.step - 1, part: lastPart(state.step - 1) };
              if (backward.step === STEP_IDS.indexOf('dots') && state.includeDots !== true) { backward.step--; backward.part = lastPart(backward.step); }
              if (![forward, backward].some(target => target.step === payload.step && target.part === part) || payload.step < 0 || payload.step > LAST_STEP) throw Error('教程步骤无效。');
              state = await save({ ...state, step: payload.step, part, hint: payload.step >= HINT_STEP && state.hint === 'off' ? 'pending' : state.hint });
            }
          }
        }
        if (action === 'tutorial-open' && state?.status === 'active' && Number.isInteger(state.pageTabId)) {
          let tab; try { tab = await getTab(state.pageTabId); } catch { /* The page was closed. */ }
          let available = tab?.active && tab.windowId === state.windowId;
          try { available = available && M.normalizeURL(tab.pendingUrl || tab.url).kind === 'chatgpt'; } catch { available = false; }
          if (!available) state = await save({ ...state, pageTabId: null, hint: 'pending', claim: null });
        }
        return view(state, windowId);
      }
      const ownsTab = state?.windowId === context.windowId && state?.claim?.tabId === context.tabId && state.claim.id === context.id;
      const ownsClaim = ownsTab && state.claim.token === payload.token && state.runId === payload.runId;
      if (action === 'hint-return') {
        if (!ownsClaim || state.status !== 'active' || state.step !== HINT_STEP || !await eligible(state, context, true)) return { show: false };
        if (![0, 1, 2].includes(payload.step)) throw Error('教程步骤无效。');
        await save({ ...state, pageTabId: null, step: payload.step, part: 0, hint: 'done', claim: null });
        return { show: false, returned: true, runId: state.runId };
      }
      if (action === 'hint-dismiss') {
        if (['claimed', 'shown'].includes(state?.hint) && ownsClaim) await save({ ...state, hint: 'done', claim: null,
          ...(state.status === 'active' && state.step === HINT_STEP ? { status: 'skipped', pageTabId: null } : {}) });
        return { show: false };
      }
      if (!['hint-claim', 'hint-status', 'hint-shown'].includes(action)) throw Error('教程操作无效。');
      if (action !== 'hint-claim' && (!['claimed', 'shown'].includes(state?.hint) || !ownsClaim)) return { show: false };
      const tutorial = state?.status === 'active' && state.step === HINT_STEP;
      if (action === 'hint-claim' && !['pending', 'claimed'].includes(state?.hint) && !(tutorial && state.pageTabId === context.tabId && state.hint === 'shown')) return { show: false };
      if (!await eligible(state, context)) return { show: false };
      if (action === 'hint-claim' && !ownsTab) {
        // An undelivered claim is recoverable, but cannot be taken from a still eligible owner.
        if (state.hint === 'claimed') {
          let previous;
          try { previous = await getTab(state.claim.tabId); } catch { /* Closed tab. */ }
          if (previous?.active && previous.windowId === state.windowId) {
            try { if (M.normalizeURL(previous.pendingUrl || previous.url).id === state.claim.id) return { show: false }; }
            catch { /* The previous tab left the eligible conversation. */ }
          }
          // The candidate can change while resolving the old owner.
          if (!await eligible(state, context)) return { show: false };
        }
        state = await save({ ...state, hint: 'claimed', claim: { tabId: context.tabId, id: context.id, token: newId() } });
      }
      if (action === 'hint-shown' && state.hint === 'claimed') state = await save({ ...state, hint: 'shown' });
      return { show: true, runId: state.runId, token: state.claim.token, confirmed: state.hint === 'shown', tutorial,
        ...(state.includeDots === true ? { includeDots: true } : {}) };
    }
    return {
      initialize(reason) {
        return serial(async () => {
          if (!['install', 'update'].includes(reason) || (await storage.get(KEY))[KEY] !== undefined) return;
          await save(empty(reason === 'install' ? 'pending' : 'existing'));
        });
      },
      dispatch: (action, payload, context) => serial(() => execute(action, payload, context)),
      dotsPresented: (windowId, runId) => serial(async () => {
        const state = await read();
        return state?.status === 'active' && state.includeDots === true && state.windowId === windowId &&
          state.runId === runId && state.step === STEP_IDS.indexOf('dots') && !Number.isInteger(state.pageTabId);
      }),
      ownerWindow: () => serial(async () => { const state = await read(); return state && ['pending', 'claimed', 'shown'].includes(state.hint) ? state.windowId : null; })
    };
  }
  const api = { KEY, CHANNEL, STEP_IDS, LAST_STEP, lastPart, createStore };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkOnboarding = api;
})(globalThis);
