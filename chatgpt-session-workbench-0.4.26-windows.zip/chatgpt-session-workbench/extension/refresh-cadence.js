(function(root){
  'use strict';
  const KEY='sessionBookmarksRefreshCadence',INTERVAL=180000;
  function createStore(storage,now=Date.now){
    let queue=Promise.resolve();
    function initialize(defer=false){
      const next=queue.then(async()=>{
        const value=(await storage.get(KEY))[KEY];
        if(defer||value?.schema!==2)await storage.set({[KEY]:{schema:2,entries:Array.isArray(value?.entries)?value.entries:[],notBefore:now()+INTERVAL}});
      });queue=next.catch(()=>{});return next;
    }
    function claim(id,source){
      const next=queue.then(async()=>{
        const value=(await storage.get(KEY))[KEY],at=now();
        if(Number.isSafeInteger(value?.notBefore)&&value.notBefore>at)return {allowed:false,nextAt:value.notBefore};
        const entries=(Array.isArray(value?.entries)?value.entries:[]).filter(e=>/^chatgpt:[0-9a-f-]{36}$/.test(e?.id||'')&&Number.isSafeInteger(e.at)&&e.at>=0);
        const previous=entries.find(e=>e.id===id);
        if(previous&&at-previous.at<INTERVAL)return {allowed:false,nextAt:previous.at+INTERVAL};
        await storage.set({[KEY]:{schema:2,notBefore:value?.notBefore||0,entries:[...entries.filter(e=>e.id!==id),{id,at,source}].slice(-512)}});
        return {allowed:true,nextAt:at+INTERVAL};
      });
      queue=next.catch(()=>{});return next;
    }
    return {claim,initialize,defer:()=>initialize(true)};
  }
  const api={KEY,INTERVAL,createStore};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.BookmarkRefreshCadence=api;
})(globalThis);
