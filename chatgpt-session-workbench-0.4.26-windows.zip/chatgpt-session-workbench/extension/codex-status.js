(function (root) {
  'use strict';
  const HOST = 'com.chatgpt_session_workbench.codex';
  const CHANNEL = 'session-bookmarks-codex';
  const MAX_AGE = 15000;
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
  const emptySnapshot = () => ({ connected: false, threads: [], activeThreadId: null,
    capabilities: { completion: false, approval: false, activeThread: false } });
  function normalizeSnapshot(value, expected, now = Date.now()) {
    if (value?.version !== 1 || value.type !== 'snapshot' || value.requestId !== expected.requestId ||
        !Number.isSafeInteger(value.observedAt) || value.observedAt > now + 1000 || value.observedAt <= now - MAX_AGE ||
        !Array.isArray(value.threads)) throw Error('Invalid native snapshot');
    if ((value.hostInstanceId !== undefined || value.sequence !== undefined) &&
        (!UUID.test(value.hostInstanceId || '') || !Number.isSafeInteger(value.sequence) || value.sequence < 1)) throw Error('Invalid native revision');
    const capabilities = Object.fromEntries(['completion', 'approval', 'activeThread'].map(key => [key, value.capabilities?.[key] === true]));
    const wanted = new Set(expected.threadIds), seen = new Set(), threads = [];
    for (const item of value.threads) {
      if (!wanted.has(item?.threadId) || seen.has(item.threadId)) continue;
      seen.add(item.threadId);
      const author = ['assistant', 'user', 'tool'].includes(item.author) ? item.author : null;
      let phase = ['complete', 'generating', 'awaiting_permission'].includes(item.phase) ? item.phase : 'unknown';
      if (!author || phase === 'complete' && !capabilities.completion ||
          phase === 'awaiting_permission' && (!capabilities.approval || author === 'user')) phase = 'unknown';
      threads.push({ threadId: item.threadId, author, phase });
    }
    return { connected: true, threads, capabilities, observedAt: value.observedAt,
      activeThreadId: capabilities.activeThread && wanted.has(value.activeThreadId) ? value.activeThreadId : null };
  }
  function isFresh(snapshot, now = Date.now()) {
    return Boolean(snapshot?.connected && Number.isSafeInteger(snapshot.observedAt) &&
      snapshot.observedAt > now - MAX_AGE && snapshot.observedAt <= now + 1000);
  }
  function isActive(snapshot, id, now = Date.now()) {
    return isFresh(snapshot, now) && snapshot.capabilities?.activeThread === true && id === `codex:${snapshot.activeThreadId}`;
  }
  function applyToState(state, snapshot = emptySnapshot(), now = Date.now()) {
    const observations = new Map(isFresh(snapshot, now) ? snapshot.threads.map(item => [item.threadId, item]) : []);
    return { ...state, bookmarks: state.bookmarks.map(bookmark => {
      if (bookmark.kind !== 'codex') return bookmark;
      const { replyState, ...result } = bookmark;
      const observation = observations.get(bookmark.id.slice(6));
      return observation ? { ...result, replyState: { author: observation.author, phase: observation.phase } } : result;
    }) };
  }
  function createService({ browser, repository, timeoutMs = 5000, idleMs = 15000, now = () => Date.now(), onDisconnect = () => {} }) {
    let port = null, sequence = 0, pendingRead = null, idleTimer = null, retryAt = 0, stopped = false;
    let generation = 0;
    const requests = new Map();
    function finish(requestId, error, value) {
      const request = requests.get(requestId);
      if (!request) return;
      requests.delete(requestId); clearTimeout(request.timer);
      if (error) request.reject(error); else request.resolve(value);
    }
    function disconnect(failed = false) {
      if (failed) retryAt = now() + 5000;
      clearTimeout(idleTimer); idleTimer = null;
      const previous = port; port = null;
      generation++;
      for (const id of [...requests.keys()]) finish(id, Error('Native host disconnected'));
      try { previous?.disconnect(); } catch { /* The browser may have closed it already. */ }
      if (previous) onDisconnect();
    }
    function connection() {
      if (stopped || now() < retryAt) throw Error('Native host unavailable');
      if (port) return port;
      let current;
      try { current = browser.runtime.connectNative(HOST); }
      catch (error) { retryAt = now() + 5000; throw error; }
      port = current;
      let hostInstanceId, nativeSequence = 0, observedAt = 0;
      current.onMessage.addListener(message => {
        if (port !== current) return;
        const request = requests.get(message?.requestId);
        if (!request) return;
        try {
          const snapshot = normalizeSnapshot(message, request.message, now());
          // Once revision-aware, a connection cannot fall back to an unversioned host.
          if (hostInstanceId !== undefined && message.hostInstanceId !== hostInstanceId ||
              message.sequence !== undefined && message.sequence <= nativeSequence || message.observedAt < observedAt) throw Error('Stale native snapshot');
          hostInstanceId = message.hostInstanceId; nativeSequence = message.sequence || 0; observedAt = message.observedAt;
          finish(message.requestId, null, snapshot);
        } catch (error) { finish(message.requestId, error); disconnect(true); }
      });
      current.onDisconnect.addListener(() => {
        void browser.runtime.lastError;
        if (port !== current) return;
        disconnect(true);
      });
      return current;
    }
    function request(threadIds) {
      return new Promise((resolve, reject) => {
        let current;
        try { current = connection(); } catch (error) { reject(error); return; }
        const message = { version: 1, type: 'read', requestId: String(++sequence), threadIds };
        const timer = setTimeout(() => { finish(message.requestId, Error('Native host timed out')); disconnect(true); }, timeoutMs);
        requests.set(message.requestId, { message, resolve, reject, timer });
        try { current.postMessage(message); } catch (error) { finish(message.requestId, error); disconnect(true); }
      });
    }
    async function readCurrent() {
      clearTimeout(idleTimer); idleTimer = null;
      try {
        const { state } = await repository.dispatch('load');
        const ids = [...new Set(state.bookmarks.filter(item => item.kind === 'codex').map(item => item.id.slice(6)).filter(id => UUID.test(id)))];
        if (!ids.length || stopped) return emptySnapshot();
        const readGeneration = generation;
        let snapshot = null;
        for (let offset = 0; offset < ids.length; offset += 200) {
          const next = await request(ids.slice(offset, offset + 200));
          if (readGeneration !== generation || !port || !isFresh(next, now())) return emptySnapshot();
          snapshot = snapshot ? { ...next, observedAt: Math.min(snapshot.observedAt, next.observedAt),
            capabilities: Object.fromEntries(Object.keys(next.capabilities).map(key => [key, snapshot.capabilities[key] || next.capabilities[key]])),
            activeThreadId: next.activeThreadId || snapshot.activeThreadId, threads: [...snapshot.threads, ...next.threads] } : next;
        }
        return snapshot || emptySnapshot();
      } catch { return emptySnapshot(); }
      finally { if (!stopped && port) idleTimer = setTimeout(disconnect, idleMs); }
    }
    return {
      read() {
        if (!pendingRead) pendingRead = readCurrent().finally(() => { pendingRead = null; });
        return pendingRead;
      },
      async refresh() {
        // A manual refresh follows any in-flight poll with a new native read.
        if (pendingRead) await pendingRead;
        return this.read();
      },
      destroy() { stopped = true; disconnect(); }
    };
  }
  const api = { HOST, CHANNEL, MAX_AGE, emptySnapshot, normalizeSnapshot, isFresh, isActive, applyToState, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkCodexStatus = Object.freeze(api);
})(globalThis);
