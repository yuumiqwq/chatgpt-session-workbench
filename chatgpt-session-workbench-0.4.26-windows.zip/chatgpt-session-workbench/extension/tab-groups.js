(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const P = typeof module !== 'undefined' && module.exports ? require('./preferences.js') : root.BookmarkPreferences;
  function pageId(tab) {
    const url = tab.pendingUrl || tab.url;
    // Only the exact new-chat landing page extends the existing conversation allowlist.
    if (url === 'https://chatgpt.com/') return 'chatgpt:home';
    if (url === 'https://chatgpt.com/dots/home') return 'dots:home';
    const link = M.normalizeURL(url);
    if (link.kind !== 'chatgpt') throw Error('标签页无效。');
    return link.id;
  }
  function createManager(browser, { wait = ms => new Promise(resolve => setTimeout(resolve, ms)) } = {}) {
    const preferences = P.createAutoGroupStore(browser.storage.local);
    // One service-worker queue per real window, shared by all panel documents.
    const windows = new Map();
    const unnamed = new Map();
    const blank = tab => ['', 'about:blank', undefined].includes(tab.pendingUrl || tab.url);
    function verify(tab, windowId, target) {
      const currentTarget = pageId(tab);
      // A new-chat page may acquire its first conversation while waiting for this window's queue.
      if (tab.windowId !== windowId || target !== 'chatgpt:home' && currentTarget !== target) throw Error('标签页已变化。');
      return tab;
    }
    async function liveTab(tabId, windowId, target, allowWait) {
      let tab = await browser.tabs.get(tabId);
      // Only the creation callback's validated destination permits bounded metadata retries.
      for (let retry = 0; allowWait && blank(tab) && retry < 5; retry++) {
        if (tab.windowId !== windowId) throw Error('标签页已变化。');
        await wait(100); tab = await browser.tabs.get(tabId);
      }
      return verify(tab, windowId, target);
    }
    async function groupCreatedTab(tabId, createdURL) {
      if (!Number.isInteger(tabId) || tabId < 0) throw Error('标签页无效。');
      if (!await preferences.load()) return { grouped: false };
      const created = await browser.tabs.get(tabId);
      const target = createdURL === undefined ? pageId(created) : pageId({ url: createdURL });
      if (!Number.isInteger(created.windowId) || created.windowId < 0) throw Error('标签页无效。');
      const windowId = created.windowId;
      if (!blank(created)) verify(created, windowId, target);
      const operation = (windows.get(windowId) || Promise.resolve()).catch(() => {}).then(async () => {
        if (!await preferences.load()) return { grouped: false };
        await liveTab(tabId, windowId, target, createdURL !== undefined);
        const groups = await browser.tabGroups.query({ windowId });
        let group = groups.filter(item => item.windowId === windowId && item.title === 'chatgpt').sort((a, b) => a.id - b.id)[0];
        // Recover only this worker's own unfinished group, never another unnamed/manual group.
        const unfinished = groups.find(item => item.id === unnamed.get(windowId) && item.windowId === windowId && !item.title);
        if (group || !unfinished) unnamed.delete(windowId);
        if (!await preferences.load()) return { grouped: false };
        let current = await liveTab(tabId, windowId, target, createdURL !== undefined);
        if (!group && unfinished) {
          await browser.tabGroups.update(unfinished.id, { title: 'chatgpt' });
          unnamed.delete(windowId); group = unfinished;
          if (!await preferences.load()) return { grouped: false };
          current = await liveTab(tabId, windowId, target, createdURL !== undefined);
        }
        if (group) {
          if (current.groupId !== group.id) await browser.tabs.group({ groupId: group.id, tabIds: [tabId] });
          return { grouped: true };
        }
        const groupId = await browser.tabs.group({ tabIds: [tabId], createProperties: { windowId } });
        unnamed.set(windowId, groupId);
        await browser.tabGroups.update(groupId, { title: 'chatgpt' });
        unnamed.delete(windowId);
        return { grouped: true };
      });
      windows.set(windowId, operation);
      try { return await operation; }
      finally { if (windows.get(windowId) === operation) windows.delete(windowId); }
    }
    return { groupCreatedTab, getEnabled: () => preferences.load(), setEnabled: enabled => preferences.save(enabled) };
  }
  const api = { createManager };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkTabGroups = api;
})(globalThis);
