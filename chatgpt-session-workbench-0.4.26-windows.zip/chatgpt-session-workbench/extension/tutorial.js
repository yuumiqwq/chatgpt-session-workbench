(function (root) {
  'use strict';
  const O = typeof module !== 'undefined' && module.exports ? require('./onboarding.js') : root.BookmarkOnboarding;
  const Q = typeof module !== 'undefined' && module.exports ? require('./quick-button.js') : root.BookmarkQuickButton;
  function panelCenterY(page, panel) {
    if (!page || ![page.centerY, page.innerHeight, page.devicePixelRatio, panel.innerHeight, panel.devicePixelRatio].every(Number.isFinite) ||
        page.innerHeight <= 0 || panel.innerHeight <= 0 || page.devicePixelRatio <= 0 || panel.devicePixelRatio <= 0 ||
        page.centerY < 0 || page.centerY > page.innerHeight) return null;
    return panel.innerHeight - (page.innerHeight - page.centerY) * page.devicePixelRatio / panel.devicePixelRatio;
  }
  const definitions = {
    collect: { title: '收藏当前对话', text: '收藏当前对话，默认放入当前打开的类别，没有打开的类别则放入未分类。', anchor: 'add-current' },
    quick: { title: '悬浮球快速收藏', text: "侧栏关闭状态下，可以点击页面右侧的悬浮球将当前页面快速收藏到“未分类”。", centered: true },
    organize: { title: '分类结构：类别—项目（可选）—会话', text: '可以拖动会话来调整类别。\n\n项目是可选的结构，把多个会话拖动到一起可以形成项目，只有同类别的会话可以形成项目。', anchor: 'category-list' },
    open: { title: '已打开的会话、当前会话', text: '已打开的 ChatGPT 会话会拥有边框，当前正在查看的会话会被高亮。', sample: 'states' },
    close: { title: '关闭已打开的会话', text: '点这里会关闭该会话的标签页，不会删除对该会话的收藏哦。' },
    new: { title: '新建会话', text: '此处可以跳转 ChatGPT 新对话界面。', anchor: 'new-chat' },
    markers: { title: '会话的状态标识', text: '红色感叹号表示回复完成，等待你继续回复；绿色问号表示等待你确认权限。', sample: 'markers' },
    remove: { title: '结束处理并移除', text: '如果你不再准备继续回复某个会话，可以在该会话的编辑界面移除它。' }
  };
  definitions.codex = { title: '添加 Codex', text: '复制 Codex 会话的深度链接，粘贴到‘添加 Codex’中，再填写名称并选择类别。', anchor: 'add-codex', images: [
    { src: 'assets/tutorial/codex-sidebar.webp', alt: 'Codex 侧边栏复制深度链接菜单', caption: '侧边栏会话标题右键 → 复制 → 复制深度链接' },
    { src: 'assets/tutorial/codex-conversation.webp', alt: 'Codex 会话右上角复制深度链接菜单', caption: '会话右上角‘…’ → 复制 → 复制深度链接' }
  ] };
  definitions.dots = { title: '添加 Dots', text: "交给dots正在跟进的事宜也可以创建为会话。\n由于dots跟进的事宜常常不止一项，同一个dots可以创建为多个会话。", anchor: 'add-dots' };
  const steps = O.STEP_IDS.map(id => ({ id, ...definitions[id] }));
  function createTour({ document, window, request, onView = () => {}, onError = () => {}, onDotsShown = () => {} }) {
    const get = id => document.getElementById(id);
    const make = (tag, className = '', text = '') => {
      const node = document.createElement(tag); node.className = className; node.textContent = text; return node;
    };
    const dialog = make('dialog', 'tutorial-dialog'); dialog.id = 'tutorial';
    dialog.setAttribute('aria-labelledby', 'tutorial-title'); dialog.setAttribute('aria-describedby', 'tutorial-text');
    const highlight = make('div', 'tutorial-highlight'); highlight.setAttribute('aria-hidden', 'true');
    const bubble = make('section', 'tutorial-bubble');
    const head = make('div', 'tutorial-head'), title = make('h2'), progress = make('span', 'tutorial-progress');
    title.id = 'tutorial-title'; progress.id = 'tutorial-progress'; progress.setAttribute('aria-live', 'polite');
    const close = make('button', 'icon-button', '×'); close.type = 'button'; close.id = 'tutorial-close'; close.setAttribute('aria-label', '关闭教程'); close.title = '关闭教程';
    head.append(title, close);
    const content = make('div', 'tutorial-content'), text = make('p'), sample = make('div', 'tutorial-example');
    text.id = 'tutorial-text'; sample.setAttribute('aria-hidden', 'true'); sample.inert = true;
    const images = make('div', 'tutorial-images');
    images.id = 'tutorial-images';
    content.append(text, sample, images);
    const error = make('p', 'error'); error.setAttribute('role', 'alert'); error.id = 'tutorial-error';
    const actions = make('div', 'tutorial-actions');
    const previous = make('button', '', '上一步'), skip = make('button', '', '跳过'), next = make('button', 'primary', '下一步');
    previous.id = 'tutorial-previous'; skip.id = 'tutorial-skip'; next.id = 'tutorial-next';
    for (const button of [previous, skip, next]) button.type = 'button';
    actions.append(previous, skip, next); bubble.append(head, progress, content, error, actions); dialog.append(highlight, bubble); document.body.append(dialog);
    let state = null, busy = false, wantsSync = false, restoreFocus = null, destroyed = false, liveTarget = null, placeholder = null;
    let quickGeometry = null, geometrySequence = 0;
    async function refreshGeometry() {
      const ticket = ++geometrySequence;
      quickGeometry = null;
      if (destroyed || !dialog.open || steps[state?.step]?.id !== 'quick') return;
      position();
      try {
        const result = await request('tutorial-geometry', {});
        if (ticket !== geometrySequence || destroyed || !dialog.open || steps[state?.step]?.id !== 'quick') return;
        if (result?.ok) quickGeometry = result.geometry;
        position();
      } catch {}
    }
    function releaseTarget() {
      if (!liveTarget) return;
      liveTarget.classList.remove('tutorial-target');
      for (const property of ['left', 'top', 'width', 'height']) liveTarget.style[property] = '';
      placeholder.parentElement?.insertBefore(liveTarget, placeholder); placeholder.remove();
      liveTarget = null; placeholder = null;
    }
    function mountTarget() {
      if (liveTarget || steps[state.step].id !== 'close') return;
      const target = anchor();
      if (!target?.classList.contains('close-tab')) return;
      const box = target.getBoundingClientRect();
      placeholder = make('span'); placeholder.setAttribute('aria-hidden', 'true');
      placeholder.style.width = box.width + 'px'; placeholder.style.height = box.height + 'px'; placeholder.style.flex = 'none';
      target.parentElement.insertBefore(placeholder, target);
      liveTarget = target; liveTarget.classList.add('tutorial-target'); dialog.append(liveTarget);
    }
    const otherDialog = () => ['settings', 'statistics', 'editor'].some(id => get(id)?.open);
    function icon(name) {
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'icon');
      const use = document.createElementNS('http://www.w3.org/2000/svg', 'use'); use.setAttribute('href', '#i-' + name); svg.append(use); return svg;
    }
    function row(label, classes = '', marker = '') {
      const card = make('div', 'bookmark ' + classes), link = make('span', 'bookmark-link');
      const source = make('span', 'source-icon'); source.append(icon('chat'));
      if (marker) source.append(make('span', 'reply-marker' + (marker === '?' ? ' permission-marker' : ''), marker));
      link.append(source, make('span', 'bookmark-title', label)); card.append(link);
      return card;
    }
    function example(type) {
      sample.replaceChildren(); sample.hidden = !type;
      if (type === 'states') sample.append(row('已打开的会话', 'tab-open'), row('当前会话', 'tab-open tab-active'));
      if (type === 'markers') sample.append(row('待你继续回复', '', '!'), row('等待权限确认', '', '?'));
    }
    function anchor() {
      const step = steps[state?.step ?? 0];
      if (step.centered) return null;
      let node = step.anchor ? get(step.anchor) : null;
      if (step.id === 'organize') node = get('category-list')?.closest('.categories');
      if (step.id === 'close') node = liveTarget || get('bookmark-list')?.querySelector('.close-tab');
      if (step.id === 'open') node = get('bookmark-list')?.querySelector('.tab-active, .tab-open');
      if (step.id === 'markers') node = get('bookmark-list')?.querySelector('.source-icon');
      if (step.id === 'remove') node = get('bookmark-list')?.querySelector('[aria-label^="编辑收藏"]');
      if (step.id === 'close' && !node) return null;
      if (!node || node.hidden || !node.getClientRects().length) node = get('list-title')?.parentElement;
      return node;
    }
    function targetBox() {
      const node = anchor();
      const boxes = [(liveTarget ? placeholder : node)?.getBoundingClientRect?.()];
      if (steps[state.step].id === 'organize') {
        const rows = [...(get('bookmark-list')?.querySelectorAll('.bookmark') || [])].slice(0, 2);
        for (const row of rows) if (row.getClientRects().length) boxes.push(row.getBoundingClientRect());
      }
      const visible = boxes.filter(Boolean);
      if (!visible.length) return null;
      const left = Math.min(...visible.map(box => box.left)), top = Math.min(...visible.map(box => box.top));
      const right = Math.max(...visible.map(box => box.right)), bottom = Math.max(...visible.map(box => box.bottom));
      return { left, top, right, bottom, width: right - left, height: bottom - top };
    }
    function position() {
      if (!dialog.open || destroyed) return;
      if (!liveTarget) mountTarget();
      const width = window.innerWidth || document.documentElement.clientWidth || 260;
      const height = window.innerHeight || document.documentElement.clientHeight || 600;
      const margin = 8;
      bubble.style.width = Math.min(320, width - margin * 2) + 'px';
      bubble.style.maxHeight = Math.max(0, height - margin * 2) + 'px';
      const box = targetBox();
      if (liveTarget && box) {
        liveTarget.style.left = box.left + 'px'; liveTarget.style.top = box.top + 'px';
        liveTarget.style.width = box.width + 'px'; liveTarget.style.height = box.height + 'px';
      }
      const clamp = (value, min, max) => Math.max(min, Math.min(value, Math.max(min, max)));
      const visible = box && box.bottom > 0 && box.top < height && box.right > 0 && box.left < width;
      const below = visible ? Math.max(0, height - margin - box.bottom - 12) : 0;
      const above = visible ? Math.max(0, box.top - 12 - margin) : 0;
      if (visible) bubble.style.maxHeight = Math.max(below, above) + 'px';
      const size = bubble.getBoundingClientRect?.() || { width: Math.min(320, width - 16), height: 300 };
      if (steps[state.step].id === 'quick') {
        const current = get('add-current');
        const fallback = current && !current.hidden && current.getClientRects().length ? current.getBoundingClientRect() : null;
        const measured = panelCenterY(quickGeometry, { innerHeight: height, devicePixelRatio: window.devicePixelRatio });
        const ballCenterY = measured ?? (fallback ? fallback.top + fallback.height / 2 : null);
        if (ballCenterY === null || ballCenterY < 0 || ballCenterY > height) {
          highlight.hidden = true; bubble.dataset.pointer = 'none';
          bubble.style.left = margin + 'px'; bubble.style.top = clamp((height - size.height) / 2, margin, height - size.height - margin) + 'px';
          return;
        }
        const top = clamp(ballCenterY - 22, margin, height - size.height - margin);
        highlight.hidden = true;
        bubble.dataset.pointer = 'left';
        bubble.style.left = margin + 'px'; bubble.style.top = top + 'px';
        bubble.style.setProperty('--pointer-top', clamp(ballCenterY - top, 16, size.height - 16) + 'px');
        return;
      }
      highlight.hidden = !visible;
      let top = (height - size.height) / 2, left = (width - size.width) / 2;
      bubble.dataset.pointer = 'none';
      if (visible) {
        highlight.style.left = clamp(box.left - 2, 2, width - 4) + 'px';
        highlight.style.top = clamp(box.top - 2, 2, height - 4) + 'px';
        highlight.style.width = Math.min(box.width + 4, width - Math.max(2, box.left - 2) - 2) + 'px';
        highlight.style.height = Math.min(box.height + 4, height - Math.max(2, box.top - 2) - 2) + 'px';
        left = clamp(box.left + box.width / 2 - size.width / 2, margin, width - size.width - margin);
        if (below >= size.height || below >= above) { top = box.bottom + 12; bubble.dataset.pointer = 'up'; }
        else { top = box.top - 12 - size.height; bubble.dataset.pointer = 'down'; }
        bubble.style.setProperty('--pointer-left', clamp(box.left + box.width / 2 - left, 16, size.width - 16) + 'px');
      }
      bubble.style.left = left + 'px'; bubble.style.top = clamp(top, margin, height - size.height - margin) + 'px';
    }
    function controls() {
      previous.disabled = busy || state?.step === 0;
      for (const node of [skip, next, close]) node.disabled = busy;
    }
    function confirmDots() {
      const runId = state?.runId;
      const visible = () => !destroyed && !document.hidden && dialog.open && state?.runId === runId && state.includeDots && steps[state.step].id === 'dots';
      if (!visible()) return;
      const confirm = () => { if (visible()) void onDotsShown(runId); };
      if (window.requestAnimationFrame) window.requestAnimationFrame(() => window.requestAnimationFrame(confirm));
      else queueMicrotask(confirm);
    }
    function paint(result) {
      releaseTarget();
      if (!result.show) {
        ++geometrySequence; quickGeometry = null;
        state = null;
        if (dialog.open) { dialog.close(); if (restoreFocus?.isConnected) restoreFocus.focus({ preventScroll: true }); }
        onView(null);
        return;
      }
      onView({ ...result, id: steps[result.step].id });
      if (dialog.open && state?.runId === result.runId && state.step === result.step && state.part === result.part) {
        mountTarget(); controls(); position(); confirmDots(); return;
      }
      state = { runId: result.runId, step: result.step, part: result.part ?? 0, includeDots: result.includeDots === true };
      ++geometrySequence; quickGeometry = null;
      const step = steps[state.step];
      const previews = step.id === 'codex' && !state.part ? null : step.images;
      title.textContent = step.title; text.textContent = step.id === 'codex' && state.part ? '' : step.text;
      text.hidden = !text.textContent; progress.textContent = `${state.step + (!state.includeDots && state.step > O.STEP_IDS.indexOf('dots') ? 0 : 1)} / ${steps.length - (state.includeDots ? 0 : 1)}`;
      dialog.setAttribute('aria-describedby', text.hidden ? 'tutorial-images' : 'tutorial-text');
      dialog.dataset.step = step.id; dialog.dataset.part = String(state.part);
      next.textContent = state.step === steps.length - 1 ? '完成' : '下一步'; example(step.sample);
      content.scrollTop = 0;
      images.replaceChildren(); images.hidden = !previews;
      if (step.id === 'quick') { images.hidden = false; images.append(Q.preview(document)); }
      for (const image of previews || []) {
        const figure = make('figure'), preview = make('img');
        const link = step.id === 'quick' ? make('div') : make('a');
        if (step.id !== 'quick') { link.setAttribute('href', image.src); link.setAttribute('target', '_blank'); link.setAttribute('rel', 'noopener noreferrer'); }
        preview.setAttribute('alt', image.alt);
        preview.addEventListener('error', () => { link.hidden = true; position(); });
        preview.addEventListener('load', position);
        preview.setAttribute('src', image.src);
        link.append(preview); figure.append(link);
        if (image.caption) figure.append(make('figcaption', '', image.caption));
        images.append(figure);
      }
      if (!dialog.open) { restoreFocus = document.activeElement; dialog.showModal(); }
      mountTarget();
      controls(); position(); confirmDots();
      if (step.id === 'quick') void refreshGeometry();
    }
    async function operate(action, payload = {}, interactive = false) {
      if (destroyed) return;
      if (busy) { if (action === 'tutorial-open') wantsSync = true; return; }
      if (action === 'tutorial-open' && (otherDialog() || document.hidden)) return;
      const focusBeforeRequest = document.activeElement;
      busy = true; controls(); error.textContent = '';
      try {
        const result = await request(action, payload);
        if (!result?.ok) throw Error(result?.error || '教程读取或保存失败。');
        if (destroyed) return;
        // Do not open over a form that appeared while the initial request was pending.
        if (action === 'tutorial-open' && !dialog.open && otherDialog()) return;
        paint(result);
      } catch (reason) {
        if (dialog.open) error.textContent = reason.message;
        else if (interactive) onError(reason.message);
      } finally {
        busy = false; controls(); position();
        if (dialog.open && (interactive || !dialog.contains(document.activeElement))) {
          const target = !interactive && dialog.contains(focusBeforeRequest) && !focusBeforeRequest.disabled ? focusBeforeRequest : next;
          target.focus({ preventScroll: true });
        }
        if (wantsSync) { wantsSync = false; void operate('tutorial-open'); }
      }
    }
    const move = delta => {
      if (!state) return;
      let step = state.step, part = state.part + delta;
      if (part > O.lastPart(step)) { step++; if (step === O.STEP_IDS.indexOf('dots') && !state.includeDots) step++; part = 0; }
      if (part < 0) { step--; if (step === O.STEP_IDS.indexOf('dots') && !state.includeDots) step--; part = O.lastPart(step); }
      return operate('tutorial-step', { runId: state.runId, expectedStep: state.step, expectedPart: state.part, step, part }, true);
    };
    const stop = () => state && operate('tutorial-skip', { runId: state.runId }, true);
    previous.addEventListener('click', () => move(-1)); skip.addEventListener('click', stop); close.addEventListener('click', stop);
    next.addEventListener('click', () => state?.step === O.LAST_STEP ? operate('tutorial-finish', { ...state, expectedStep: O.LAST_STEP }, true) : move(1));
    dialog.addEventListener('cancel', event => { event.preventDefault(); if (!busy) void stop(); });
    dialog.addEventListener('keydown', event => {
      if (event.key === 'Tab' && !event.altKey && !event.ctrlKey && !event.metaKey) {
        const focusable = [...dialog.querySelectorAll('button, a[href]')].filter(node => !node.disabled && !node.hidden && node.getClientRects().length && !node.closest('[inert]'));
        const index = focusable.indexOf(document.activeElement);
        event.preventDefault();
        focusable[(index + (event.shiftKey ? -1 : 1) + focusable.length) % focusable.length]?.focus();
        return;
      }
      if (busy || event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key === 'ArrowLeft' && state?.step > 0) { event.preventDefault(); void move(-1); }
      if (event.key === 'ArrowRight' && state?.step < O.LAST_STEP) { event.preventDefault(); void move(1); }
    });
    function resize() { position(); void refreshGeometry(); }
    window.addEventListener('resize', resize); document.addEventListener('scroll', position, true);
    return {
      get busy() { return busy; },
      sync: () => operate('tutorial-open'), restart: () => operate('tutorial-restart', {}, true), position, beforeRender: releaseTarget, refreshGeometry,
      destroy() { destroyed = true; ++geometrySequence; releaseTarget(); window.removeEventListener?.('resize', resize); document.removeEventListener?.('scroll', position, true); dialog.remove(); onView(null); }
    };
  }
  // A separate one-time tip for Dots. It never participates in the main walkthrough.
  function createDotsGuide({ document, window, onShown }) {
    const dialog = document.createElement('dialog'); dialog.id = 'dots-guide';
    dialog.className = 'tutorial-dialog dots-guide-dialog';
    const highlight = document.createElement('div'); highlight.className = 'dots-guide-highlight';
    highlight.setAttribute('aria-hidden', 'true');
    const bubble = document.createElement('section'); bubble.className = 'tutorial-bubble';
    bubble.setAttribute('role', 'document');
    const head = document.createElement('div'); head.className = 'tutorial-head';
    const title = document.createElement('h2'); title.id = 'dots-guide-title'; title.textContent = definitions.dots.title;
    const close = document.createElement('button'); close.className = 'icon-button'; close.type = 'button';
    close.textContent = '×'; close.title = '关闭 Dots 教程'; close.setAttribute('aria-label', close.title);
    head.append(title, close);
    const body = document.createElement('div'); body.className = 'tutorial-content';
    const text = document.createElement('p'); text.id = 'dots-guide-text'; text.textContent = definitions.dots.text;
    body.append(text);
    const error = document.createElement('p'); error.className = 'error'; error.id = 'dots-guide-error';
    error.setAttribute('role', 'alert');
    const actions = document.createElement('div'); actions.className = 'tutorial-actions';
    const understood = document.createElement('button'); understood.type = 'button';
    understood.className = 'primary'; understood.textContent = '知道了'; actions.append(understood);
    bubble.append(head, body, error, actions); dialog.append(highlight, bubble); document.body.append(dialog);
    dialog.setAttribute('aria-labelledby', title.id); dialog.setAttribute('aria-describedby', text.id);
    let activeToken = null, confirmed = false, confirming = false, destroyed = false;
    const clamp = (value, min, max) => Math.max(min, Math.min(value, Math.max(min, max)));
    function position() {
      if (!dialog.open || destroyed) return;
      const target = document.getElementById('add-dots'), rect = target?.getBoundingClientRect();
      const width = window.innerWidth || document.documentElement.clientWidth || 320;
      const height = window.innerHeight || document.documentElement.clientHeight || 600;
      const margin = 8;
      bubble.style.width = Math.min(320, width - margin * 2) + 'px';
      bubble.style.maxHeight = Math.max(0, height - margin * 2) + 'px';
      const b = bubble.getBoundingClientRect();
      const visible = target && !target.hidden && !target.disabled && rect && rect.width && rect.height &&
        rect.top < height && rect.bottom > 0 && rect.left < width && rect.right > 0;
      highlight.hidden = !visible;
      let top = (height - b.height) / 2, left = (width - b.width) / 2;
      bubble.dataset.pointer = 'none';
      if (visible) {
        highlight.style.left = clamp(rect.left - 2, 2, width - 4) + 'px';
        highlight.style.top = clamp(rect.top - 2, 2, height - 4) + 'px';
        highlight.style.width = Math.min(rect.width + 4, width - clamp(rect.left - 2, 2, width - 4) - 2) + 'px';
        highlight.style.height = Math.min(rect.height + 4, height - clamp(rect.top - 2, 2, height - 4) - 2) + 'px';
        left = clamp(rect.left + rect.width / 2 - b.width / 2, margin, width - b.width - margin);
        const below = height - margin - rect.bottom - 12, above = rect.top - margin - 12;
        if (below >= b.height || below >= above) { top = rect.bottom + 12; bubble.dataset.pointer = 'up'; }
        else { top = rect.top - b.height - 12; bubble.dataset.pointer = 'down'; }
        bubble.style.setProperty('--pointer-left', clamp(rect.left + rect.width / 2 - left, 16, b.width - 16) + 'px');
      }
      bubble.style.left = clamp(left, margin, width - b.width - margin) + 'px';
      bubble.style.top = clamp(top, margin, height - b.height - margin) + 'px';
    }
    async function confirm() {
      if (confirmed || confirming || !activeToken || destroyed) return;
      confirming = true;
      try {
        const ack = await onShown(activeToken);
        if (ack?.shown !== true) throw Error('Dots 教程保存失败，请点击“知道了”重试。');
        confirmed = true; error.textContent = '';
      } catch (e) { error.textContent = e.message || 'Dots 教程保存失败。'; }
      finally { confirming = false; }
    }
    async function dismiss() {
      if (!confirmed) { await confirm(); if (!confirmed) return; }
      activeToken = null;
      if (dialog.open) dialog.close();
    }
    close.addEventListener('click', () => { void dismiss(); });
    understood.addEventListener('click', () => { void dismiss(); });
    dialog.addEventListener('cancel', event => { event.preventDefault(); void dismiss(); });
    window.addEventListener('resize', position); document.addEventListener('scroll', position, true);
    return {
      present(token) {
        if (!token || destroyed) return false;
        const target = document.getElementById('add-dots');
        if (target?.hidden || target?.disabled || !target?.getClientRects().length) return false;
        if (dialog.open) return activeToken === token;
        activeToken = token; confirmed = false; error.textContent = '';
        dialog.showModal(); position(); void confirm();
        return true;
      },
      get open() { return dialog.open; },
      hide() { if (dialog.open) dialog.close(); activeToken = null; },
      destroy() { destroyed = true; dialog.remove(); window.removeEventListener?.('resize', position);
        document.removeEventListener?.('scroll', position, true); }
    };
  }
  const api = { createTour, createDotsGuide, steps, panelCenterY };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkTutorial = api;
})(globalThis);
