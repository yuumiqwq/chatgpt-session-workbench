[CmdletBinding()]
param(
    [ValidatePattern('^[a-p]{32}$')][string]$ExtensionId,
    [string]$InstallDirectory,
    [string]$ExtensionDirectory,
    [string]$CodexHome,
    [switch]$PlanOnly,
    [string]$PlanDirectory
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$hostName = 'com.chatgpt_session_workbench.codex'
if (-not $InstallDirectory) {
    if (Test-Path -LiteralPath 'E:\' -PathType Container) { $InstallDirectory = 'E:\Apps\ChatGPTSessionWorkbench' }
    else { $InstallDirectory = Join-Path $env:LOCALAPPDATA 'Programs\ChatGPTSessionWorkbench' }
}
function Get-ExtensionPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if ($full.Length -gt [IO.Path]::GetPathRoot($full).Length) { $full = $full.TrimEnd([char[]]'\/') }
    if ($full -cmatch '^[a-z]:') { $full = $full.Substring(0, 1).ToUpperInvariant() + $full.Substring(1) }
    return $full
}
$InstallDirectory = [IO.Path]::GetFullPath($InstallDirectory)
$previous = $null
if (-not $ExtensionDirectory -or -not $CodexHome) {
    $statePath = Join-Path $InstallDirectory 'install-state.json'
    if (Test-Path -LiteralPath $statePath -PathType Leaf) {
        $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.version -ne 1 -or -not $state.installDirectory -or [IO.Path]::GetFullPath($state.installDirectory) -ne $InstallDirectory) {
            throw 'The existing installation record does not match this installation directory.'
        }
        $previous = $state
    }
}
if (-not $CodexHome -and $previous.codexHome) { $CodexHome = $previous.codexHome }
if (-not $CodexHome) {
    if ($env:CODEX_HOME) { $CodexHome = $env:CODEX_HOME }
    else { $CodexHome = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex' }
}
$CodexHome = [IO.Path]::GetFullPath($CodexHome)
if (-not $ExtensionDirectory) {
    if ($previous) { $ExtensionDirectory = $previous.extensionDirectory }
    if (-not $ExtensionDirectory) { $ExtensionDirectory = Join-Path $PSScriptRoot 'extension' }
}
$ExtensionDirectory = Get-ExtensionPath $ExtensionDirectory
if (-not (Test-Path -LiteralPath $CodexHome -PathType Container)) { throw 'CODEX_HOME_MISSING: Run Codex first or select its data directory.' }
$extensionManifestPath = Join-Path $ExtensionDirectory 'manifest.json'
if (-not (Test-Path -LiteralPath $extensionManifestPath -PathType Leaf)) { throw 'EXTENSION_DIRECTORY_MISSING: The extension directory does not contain manifest.json.' }
$idSource = 'explicit'
if (-not $ExtensionId) {
    $extensionManifest = Get-Content -LiteralPath $extensionManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $bytes = [Text.Encoding]::Unicode.GetBytes($ExtensionDirectory)
    $idSource = 'windows-path'
    if ($extensionManifest.PSObject.Properties.Name -contains 'key') {
        $key = $extensionManifest.key
        if ($key -isnot [string] -or -not $key -or $key.Length -gt 102400) { throw 'Invalid manifest.key.' }
        if ($key.StartsWith('-----BEGIN')) {
            $key = $key -replace '\s+', ''
            if ($key -notmatch '^-----BEGIN[^-]*KEY-----(.+)-----END[^-]*KEY-----$') { throw 'Invalid manifest.key PEM.' }
            $key = $Matches[1]
        }
        try { $bytes = [Convert]::FromBase64String($key) } catch { throw 'Invalid manifest.key base64.' }
        if ($bytes.Length -eq 0) { throw 'Invalid empty manifest.key.' }
        $idSource = 'manifest-key'
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $digest = $sha.ComputeHash($bytes) } finally { $sha.Dispose() }
    $ExtensionId = -join (0..15 | ForEach-Object { [char](97 + ($digest[$_] -shr 4)); [char](97 + ($digest[$_] -band 15)) })
}
$native = Join-Path $InstallDirectory 'native-host'
$hostPath = Join-Path $native 'workbench-codex-host.exe'
$manifestPath = Join-Path $native ($hostName + '.json')
$registryPath = 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\' + $hostName
$hostManifest = [ordered]@{
    name = $hostName
    description = 'ChatGPT Session Workbench Codex status'
    path = $hostPath
    type = 'stdio'
    allowed_origins = @('chrome-extension://' + $ExtensionId + '/')
}
$config = [ordered]@{ version = 1; codexHome = $CodexHome; desktopApproval = $true }
$plan = [ordered]@{
    version = 1
    extensionId = $ExtensionId
    extensionIdSource = $idSource
    installDirectory = $InstallDirectory
    codexHome = $CodexHome
    extensionDirectory = $ExtensionDirectory
    executable = $hostPath
    manifestPath = $manifestPath
    registryPath = $registryPath
    registryDefaultValue = $manifestPath
    allowedOrigins = $hostManifest.allowed_origins
    requiresAdministrator = $false
    preservesBrowserStorage = $true
}
$utf8 = New-Object Text.UTF8Encoding($false)
if ($PlanOnly) {
    if ($PlanDirectory) {
        $PlanDirectory = [IO.Path]::GetFullPath($PlanDirectory)
        New-Item -ItemType Directory -Path $PlanDirectory -Force | Out-Null
        [IO.File]::WriteAllText((Join-Path $PlanDirectory 'install-plan.json'), ($plan | ConvertTo-Json -Depth 5), $utf8)
        [IO.File]::WriteAllText((Join-Path $PlanDirectory ($hostName + '.json')), ($hostManifest | ConvertTo-Json -Depth 5), $utf8)
        [IO.File]::WriteAllText((Join-Path $PlanDirectory 'host-config.json'), ($config | ConvertTo-Json -Depth 5), $utf8)
    }
    $plan | ConvertTo-Json -Depth 5
    return
}
$sourceExe = Join-Path $PSScriptRoot 'native-host\workbench-codex-host.exe'
if (-not (Test-Path -LiteralPath $sourceExe -PathType Leaf)) { throw 'MISSING_INSTALL_FILES: The packaged native host executable was not found.' }
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'uninstall.ps1') -PathType Leaf)) { throw 'MISSING_INSTALL_FILES: The uninstall script was not found.' }
New-Item -ItemType Directory -Path $native -Force | Out-Null
if ([IO.Path]::GetFullPath($sourceExe) -ne $hostPath) { Copy-Item -LiteralPath $sourceExe -Destination $hostPath -Force }
foreach ($name in @('install.ps1', 'uninstall.ps1')) {
    $source = Join-Path $PSScriptRoot $name
    $destination = Join-Path $InstallDirectory $name
    if ([IO.Path]::GetFullPath($source) -ne $destination) { Copy-Item -LiteralPath $source -Destination $destination -Force }
}
[IO.File]::WriteAllText((Join-Path $native 'host-config.json'), ($config | ConvertTo-Json -Depth 5), $utf8)
[IO.File]::WriteAllText($manifestPath, ($hostManifest | ConvertTo-Json -Depth 5), $utf8)
[IO.File]::WriteAllText((Join-Path $InstallDirectory 'install-state.json'), ($plan | ConvertTo-Json -Depth 5), $utf8)
New-Item -Path $registryPath -Force | Out-Null
Set-Item -LiteralPath $registryPath -Value $manifestPath
$plan | ConvertTo-Json -Depth 5
