(function (root) {
  'use strict';
  const P = typeof module !== 'undefined' && module.exports ? require('./preferences.js') : root.BookmarkPreferences;
  const CHANNEL = 'session-bookmarks-dots', UNREAD_CHANNEL = 'session-bookmarks-dots-unread', UNREAD_KEY = 'sessionBookmarksDotsUnread', URL = 'https://chatgpt.com/dots/home';
  const badge = unread => Number.isSafeInteger(unread) && unread > 0 ? unread > 99 ? '99+' : String(unread) : '';
  function createService({ browser, repository, groupCreated, ioTimeoutMs = 1000, navigationTimeoutMs = 2500, groupTimeoutMs = 150 }) {
    const preference = P.createManualProStore(browser.storage.local), opening = new Map(), effects = new Map();
    let readings, unreadQueue = Promise.resolve();
    const sampleTickets=new Map();
    const cancelSample=id=>sampleTickets.delete(id);
    function reserveSample(tab,ticket){
      sampleTickets.set(tab.id,{...ticket,tabId:tab.id,windowId:tab.windowId,url:tab.url});
    }
    const serial = work => { const result = unreadQueue.then(work); unreadQueue = result.catch(() => {}); return result; };
    const validCount = n => n === null || Number.isSafeInteger(n) && n >= 0;
    async function loadReadings() {
      if (!readings) {
        const saved = (await browser.storage.session?.get(UNREAD_KEY))?.[UNREAD_KEY];
        const candidates = (Array.isArray(saved) ? saved : []).filter(r => Number.isInteger(r.tabId) && r.tabId >= 0 &&
          Number.isInteger(r.windowId) && r.windowId >= 0 && validCount(r.unread) && Number.isSafeInteger(r.observedAt))
          .slice(-128);
        const current = await Promise.all(candidates.map(async r => {
          try {
            const tab = await bounded(() => browser.tabs.get(r.tabId));
            if (typeof r.url !== 'string' || (tab.pendingUrl || tab.url) !== r.url || tab.discarded || tab.status === 'loading') return null;
            return { tabId:r.tabId, windowId:tab.windowId, url:r.url, unread:r.unread, observedAt:r.observedAt, timed:r.timed===true, active:tab.active===true };
          } catch { return null; }
        }));
        readings = new Map(current.filter(Boolean).map(r => [r.tabId,r]));
        if (JSON.stringify(candidates) !== JSON.stringify([...readings.values()])) await saveReadings(candidates.map(r=>r.windowId).concat(current.filter(Boolean).map(r=>r.windowId)));
      }
      return readings;
    }
    async function saveReadings(windows) {
      while (readings.size > 128) readings.delete(readings.keys().next().value);
      await browser.storage.session?.set({ [UNREAD_KEY]: [...readings.values()] });
      for (const windowId of new Set(windows)) void browser.runtime?.sendMessage?.({ channel: UNREAD_CHANNEL, action: 'changed', windowId }).catch(() => {});
    }
    function observeUnread(tab, unread, isCurrent = () => true, sample = {}) {
      return serial(async () => {
        if (!validCount(unread) || !await preference.load() || !isCurrent()) return false;
        const ticket=sampleTickets.get(tab.id);
        if(sample.requestId&&(!ticket||ticket.requestId!==sample.requestId||ticket.documentId!==sample.documentId||
          ticket.windowId!==tab.windowId||ticket.url!==tab.url||!Number.isSafeInteger(sample.sampledAt)||
          sample.sampledAt<ticket.sentAt||Date.now()>ticket.expiresAt))return false;
        const records = await loadReadings(), previous = records.get(tab.id);
        if (!isCurrent()||sample.requestId&&sampleTickets.get(tab.id)!==ticket) return false;
        const observedAt = Number.isSafeInteger(sample.sampledAt) ? sample.sampledAt : Date.now();
        if (observedAt > Date.now() || observedAt < (previous?.observedAt || 0)) return false;
        const manual=await manualRead(tab.windowId),timed=Number.isSafeInteger(sample.sampledAt);
        if (!isCurrent()||sample.requestId&&sampleTickets.get(tab.id)!==ticket) return false;
        if (!sample.requestId && !(timed&&manual&&observedAt>manual.observedAt&&observedAt>previous?.observedAt) && previous?.unread === unread && previous.windowId === tab.windowId && previous.url === tab.url && previous.active === (tab.active === true) && !previous.detached) return true;
        records.delete(tab.id);
        records.set(tab.id, { tabId: tab.id, windowId: tab.windowId, url: tab.url, unread, observedAt, timed, active: tab.active === true,
          ...(sample.requestId ? { requestId: sample.requestId, documentId: sample.documentId } : {}) });
        await saveReadings([tab.windowId, ...(previous ? [previous.windowId] : [])]); return true;
      });
    }
    function forgetTab(id) { cancelSample(id);return serial(async () => {
      const records = await loadReadings(), previous = records.get(id);
      if (previous) { records.delete(id); await saveReadings([previous.windowId]); }
    }); }
    // A verified manual result belongs only to its initiating window, independently
    // of the temporary source's lifetime. It is never restored as account eligibility.
    const manualKey = 'sessionBookmarksDotsManual';
    async function manualRead(windowId) {
      const saved = (await browser.storage.session?.get(manualKey))?.[manualKey];
      return saved?.[windowId] || null;
    }
    function commitManual(tab, receipt, windowId) { return serial(async () => {
      const record = (await loadReadings()).get(tab.id);
      const ticket=sampleTickets.get(tab.id);
      const current=()=>ticket&&sampleTickets.get(tab.id)===ticket&&ticket.windowId===windowId&&ticket.url===tab.url&&
        ticket.requestId===receipt.requestId&&ticket.documentId===receipt.documentId&&Date.now()<=ticket.expiresAt;
      if (!Number.isInteger(windowId) || tab.windowId !== windowId || !await preference.load() ||
          !current()||
          record?.requestId !== receipt.requestId || record.documentId !== receipt.documentId ||
          record.observedAt !== receipt.sampledAt || record.unread !== receipt.unread ||
          !Number.isSafeInteger(record.unread) || record.unread < 0) return false;
      const saved = (await browser.storage.session?.get(manualKey))?.[manualKey] || {};
      const snapshot = { windowId, unread:record.unread, observedAt:record.observedAt, sourceTabId:tab.id, documentId:record.documentId,requestId:ticket.requestId };
      if (!browser.storage.session?.set||!current()) return false;
      await browser.storage.session.set({ [manualKey]: { ...saved, [windowId]: snapshot } });
      if(!current()){
        // Cancellation is synchronous; undo only this in-flight write before
        // the shared queue allows cleanup or a replacement sample to commit.
        const latest=(await browser.storage.session.get(manualKey))?.[manualKey]||{};
        if(latest[windowId]?.requestId===snapshot.requestId&&latest[windowId]?.documentId===snapshot.documentId&&
            latest[windowId]?.observedAt===snapshot.observedAt){
          if(Object.hasOwn(saved,windowId))latest[windowId]=saved[windowId];else delete latest[windowId];
          await browser.storage.session.set({[manualKey]:latest});
        }
        return false;
      }
      void browser.runtime?.sendMessage?.({channel:UNREAD_CHANNEL,action:'changed',windowId}).catch(()=>{});
      return true;
    }); }
    function forgetWindow(windowId) { return serial(async () => {
      const saved = (await browser.storage.session?.get(manualKey))?.[manualKey] || {};
      if (Object.hasOwn(saved,windowId)) { delete saved[windowId]; await browser.storage.session?.set({[manualKey]:saved}); }
    }); }
    function activateTab(id, windowId) { return serial(async () => {
      const records = await loadReadings(); let changed = false;
      for (const record of records.values()) if (record.windowId === windowId && record.active !== (record.tabId === id)) {
        record.active = record.tabId === id; changed = true;
      }
      if (changed) await saveReadings([windowId]);
    }); }
    function detachTab(id) { cancelSample(id);return serial(async () => {
      const record = (await loadReadings()).get(id);
      if (record && !record.detached) { record.detached = true; await saveReadings([record.windowId]); }
    }); }
    function attachTab(id) { return serial(async () => {
      const records = await loadReadings(), record = records.get(id); if (!record) return;
      const previousWindow = record.windowId;
      try {
        const tab = await bounded(() => browser.tabs.get(id));
        if ((tab.pendingUrl || tab.url) !== record.url || tab.discarded || tab.status === 'loading') records.delete(id);
        else { record.windowId = tab.windowId; record.active = tab.active === true; delete record.detached; }
      } catch { records.delete(id); }
      await saveReadings([previousWindow, record.windowId]);
    }); }
    const timeout = () => Error('Dots 操作超时，请重试。');
    async function bounded(work, ms = ioTimeoutMs) {
      let timer;
      try { return await Promise.race([Promise.resolve().then(work), new Promise((_, reject) => { timer = setTimeout(() => reject(timeout()), Math.max(1, ms)); })]); }
      finally { clearTimeout(timer); }
    }
    // This is a persisted user declaration, never an observed account or plan.
    async function refresh(windowId) {
      const eligible = await bounded(() => preference.load());
      const reading = eligible ? await serial(async () => {
        const records = [...(await loadReadings()).values()].filter(r => r.windowId === windowId && !r.detached);
        const manual = Number.isInteger(windowId) ? await manualRead(windowId) : null;
        if (manual && manual.observedAt <= Date.now()) {
          const latest = records.filter(r=>r.timed&&r.observedAt > manual.observedAt).sort((a,b)=>b.observedAt-a.observedAt)[0];
          return latest || manual;
        }
        return records.sort((a,b)=>Number(b.active)-Number(a.active)||b.observedAt-a.observedAt)[0];
      }) : null;
      return { eligible, qualification: 'manual', binding: null, unread: reading?.unread ?? null,
        unreadObservedAt: reading?.observedAt ?? null, name: 'Dots', url: URL };
    }
    async function authorize() {
      const snapshot = await refresh();
      if (!snapshot.eligible) throw Error('当前 Dots 操作不可用。');
      return snapshot;
    }
    async function open(payload, task) {
      const check = async () => {
        if (task.cancelled || Date.now() >= task.deadline) throw timeout();
        if (!payload.id) await authorize();
      };
      const step = async work => {
        await check();
        const result = await bounded(async () => { await check(); return work(); }, task.deadline - Date.now());
        await check(); return result;
      };
      const effect = work => step(() => {
        const promise = Promise.resolve().then(work);
        effects.set(payload.windowId, promise);
        const done = () => { if (effects.get(payload.windowId) === promise) effects.delete(payload.windowId); };
        void promise.then(done, done); return promise;
      });
      if (payload.id) {
        const { state } = await step(() => repository.dispatch('load'));
        if (!state.bookmarks.some(b => b.id === payload.id && b.kind === 'dots')) throw Error('跟进项已被移除。');
      }
      if (effects.has(payload.windowId)) await step(() => effects.get(payload.windowId));
      const tabs = await step(() => browser.tabs.query({ windowId: payload.windowId }));
      for (const candidate of tabs.filter(t => t.windowId === payload.windowId && (t.pendingUrl || t.url) === URL).sort((a,b) => a.id - b.id)) {
        const tab = await step(() => browser.tabs.get(candidate.id));
        if (tab.windowId !== payload.windowId || (tab.pendingUrl || tab.url) !== URL) continue;
        await effect(() => browser.tabs.update(tab.id, { active: true }));
        await effect(() => browser.windows.update(payload.windowId, { focused: true }));
        return { opened: true, reused: true, grouped: false };
      }
      const tab = await effect(() => browser.tabs.create({ url: URL, windowId: payload.windowId, active: true }));
      let grouped = false;
      try { grouped = Boolean((await bounded(() => groupCreated?.(tab.id, URL), groupTimeoutMs))?.grouped); } catch {}
      return { opened: true, grouped };
    }
    function queueOpen(payload) {
      if (!Number.isInteger(payload.windowId) || payload.windowId < 0) return Promise.reject(Error('窗口无效。'));
      if (opening.has(payload.windowId)) return opening.get(payload.windowId).promise;
      const task = { cancelled: false, deadline: Math.min(Date.now() + navigationTimeoutMs, Number.isFinite(payload.deadline) ? payload.deadline : Infinity) };
      opening.set(payload.windowId, task);
      task.promise = open(payload, task).finally(() => { task.cancelled = true; if (opening.get(payload.windowId) === task) opening.delete(payload.windowId); });
      return task.promise;
    }
    return { refresh, observeUnread, reserveSample, cancelSample, commitManual, forgetWindow, forgetTab, activateTab, detachTab, attachTab, async dispatch(action, payload = {}) {
      if (action === 'dots-get' || action === 'dots-pro-get') return { snapshot: await refresh(payload.windowId) };
      if (action === 'dots-pro-set') {
        await preference.save(payload.enabled);
        if (!payload.enabled) await serial(async () => { const records = await loadReadings(); const windows = [...records.values()].map(r => r.windowId); records.clear(); await browser.storage.session?.set({[manualKey]:{}}); await saveReadings(windows); });
        return { snapshot: await refresh(payload.windowId) };
      }
      if (action === 'dots-add') return repository.dispatch('dots-add', { title: payload.title, categoryId: payload.categoryId }, authorize);
      if (action === 'dots-open') return queueOpen(payload);
      throw Error('Dots 操作不受支持。');
    } };
  }
  const api = { CHANNEL, UNREAD_CHANNEL, UNREAD_KEY, badge, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkDots = Object.freeze(api);
})(globalThis);
