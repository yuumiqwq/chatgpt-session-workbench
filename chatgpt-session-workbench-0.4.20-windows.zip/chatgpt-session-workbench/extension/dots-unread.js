(function (root) {
  'use strict';
  function readableHomeNode(node, nav) {
    if (!node || !nav?.contains(node)) return false;
    // Verified closed peek: nav > div (display:none) > div.group/nav-list > native orbit button.
    // Match that structure without the generated header class; other hidden inner containers stay excluded.
    const button = node.closest('button[data-sidebar-destination="builtin:orbit"][data-sidebar-cycle-item]');
    const list = button?.parentElement, header = list?.parentElement;
    const peekHeader = list?.tagName?.toLowerCase() === 'div' && list.classList.contains('group/nav-list') &&
      header?.tagName?.toLowerCase() === 'div' && header.parentElement === nav ? header : null;
    const navVisibility = root.getComputedStyle?.(nav)?.visibility;
    for (let current = node; current && current !== nav; current = current.parentElement) {
      if (current.hidden || current.getAttribute('inert') !== null || current.getAttribute('aria-hidden') === 'true') return false;
      const style = root.getComputedStyle?.(current);
      if (style?.display === 'none' && current !== peekHeader ||
          ['hidden', 'collapse'].includes(style?.visibility) && style.visibility !== navVisibility) return false;
    }
    return true;
  }
  function orbitButtons(document) {
    if (!document) return [];
    const buttons = [];
    for (const nav of document.querySelectorAll('nav[aria-label="首页"]')) {
      if (nav.getAttribute('role') && nav.getAttribute('role') !== 'navigation') continue;
      for (const button of nav.querySelectorAll('button[data-sidebar-destination="builtin:orbit"][data-sidebar-cycle-item]')) {
        if (readableHomeNode(button, nav) && !button.disabled && button.getAttribute('aria-disabled') !== 'true') buttons.push(button);
      }
    }
    return buttons;
  }
  const entryName = button => button.querySelector('span.text-fade-truncate')?.textContent?.trim();
  function unreadText(node, label) {
    if (node === label) return '';
    if (node.nodeType === 3) return node.textContent;
    if (node.nodeType !== 1) return '';
    const style = root.getComputedStyle?.(node);
    if (node.hidden || style?.display === 'none' || ['hidden', 'collapse'].includes(style?.visibility)) return '';
    // Keep sr-only and aria-hidden count text; only actual hidden subtrees are stale copies.
    return [...node.childNodes].map(child => unreadText(child, label)).join('');
  }
  function readDestination(document) {
    const entries = [];
    for (const button of orbitButtons(document)) {
      const label = button.querySelector('span.text-fade-truncate'), name = entryName(button);
      if (!name || !readableHomeNode(label, button.closest('nav[aria-label="首页"]'))) continue;
      const remainder = unreadText(button, label);
      const matches = [...remainder.matchAll(/未读消息[：:]\s*(\d+)\s*条/gu)];
      const number = matches.length === 1 ? Number(matches[0][1]) : null;
      entries.push({ identity: 'builtin:orbit', url: 'https://chatgpt.com/dots/home', name,
        unread: Number.isSafeInteger(number) && number >= 0 ? number : null });
    }
    return entries.length && entries.every(entry => JSON.stringify(entry) === JSON.stringify(entries[0])) ? entries[0] : null;
  }
  const CHANNEL = 'session-bookmarks-dots-unread', KEY = 'sessionBookmarksManualPro';
  const readUnread = document => readDestination(document)?.unread ?? null;
  function connect({ runtime, storage, document, location, window = root.window, observe = root.MutationObserver }) {
    let enabled = false, closed = false, suspended = false, timer = null, observer = null, discovery = null;
    let signature = '', pendingSignature = '', delivery = 0, preferenceRevision = 0, navs = [], rebind = false;
    const selector = 'nav[aria-label="首页"]';
    function bind() {
      observer?.disconnect(); navs = [...document.querySelectorAll(selector)];
      for (const nav of navs) observer?.observe(nav, { childList: true, subtree: true, characterData: true, attributes: true,
        attributeFilter: ['aria-hidden', 'aria-disabled', 'aria-label', 'hidden', 'inert', 'class', 'style', 'disabled', 'data-sidebar-destination', 'data-sidebar-cycle-item'] });
    }
    function changed() {
      if (closed || !enabled || suspended) return;
      const documentURL = location.href, unread = readUnread(document), next = JSON.stringify([documentURL, unread]);
      if (next === pendingSignature || next === signature && !pendingSignature) return;
      const ticket = ++delivery; pendingSignature = next;
      const sampledAt=Date.now();
      void Promise.resolve().then(() => runtime.sendMessage({ channel: CHANNEL, action: 'observe', unread, documentURL, sampledAt }))
        .then(result => { if (ticket === delivery && result?.accepted === true) signature = next; }, () => {})
        .finally(() => { if (ticket === delivery) pendingSignature = ''; });
    }
    function schedule() { if (!closed && enabled && !suspended && !timer) timer = setTimeout(() => { timer = null; if (rebind) { rebind = false; bind(); } changed(); }, 150); }
    function setEnabled(value) {
      if (closed || enabled === value) return;
      enabled = value; clearTimeout(timer); timer = null; signature = pendingSignature = ''; delivery++;
      observer?.disconnect(); discovery?.disconnect(); observer = discovery = null;
      if (enabled) {
        observer = observe ? new observe(schedule) : null;
        discovery = observe ? new observe(records => {
          // Streaming text outside navigation never rescans the document. Inspect only new/removed element subtrees.
          if (records.some(record => !navs.some(nav => nav.contains(record.target)) &&
            [...(record.addedNodes || []), ...(record.removedNodes || [])].some(node => node.nodeType === 1 &&
              (node.matches?.(selector) || node.querySelector?.(selector))))) { rebind = true; schedule(); }
        }) : null;
        discovery?.observe(document.documentElement, { childList: true, subtree: true });
        bind();
        schedule();
      }
    }
    const preferences = (changes, area) => {
      if (area === 'local' && changes[KEY]) { preferenceRevision++; setEnabled(changes[KEY].newValue === true); }
    };
    storage.onChanged.addListener(preferences);
    const initialRevision = preferenceRevision;
    void storage.local.get(KEY).then(values => { if (initialRevision === preferenceRevision) setEnabled(values[KEY] === true); }).catch(() => {});
    const shown = () => { signature = ''; schedule(); };
    const hidden = () => { suspended = true; delivery++; pendingSignature = ''; observer?.disconnect(); discovery?.disconnect(); clearTimeout(timer); timer = null; };
    const resume = () => { suspended = false; if (enabled) { enabled = false; setEnabled(true); } };
    document.addEventListener('visibilitychange', schedule);
    window?.addEventListener('pagehide', hidden);
    window?.addEventListener('pageshow', resume);
    for (const name of ['popstate', 'hashchange']) window?.addEventListener(name, shown);
    window?.navigation?.addEventListener('currententrychange', shown);
    const stop = () => {
      closed = true; hidden(); storage.onChanged.removeListener(preferences);
      document.removeEventListener('visibilitychange', schedule);
      window?.removeEventListener('pagehide', hidden); window?.removeEventListener('pageshow', resume);
      for (const name of ['popstate', 'hashchange']) window?.removeEventListener(name, shown);
      window?.navigation?.removeEventListener('currententrychange', shown);
    };
    stop.sample = async ({requestId,documentId}) => {
      const documentURL=location.href, sampledAt=Date.now(), unread=readUnread(document);
      if(closed||suspended||!requestId||!documentId||!Number.isSafeInteger(unread))return {unread:null,sampledAt,initialized:false,noData:true};
      const result=await runtime.sendMessage({channel:CHANNEL,action:'observe',unread,documentURL,sampledAt,requestId,documentId});
      return {unread,sampledAt,submitted:result?.accepted===true,initialized:result?.accepted===true&&location.href===documentURL,
        noData:false};
    };
    return stop;
  }
  const api = { CHANNEL, readUnread, connect };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { const connection=connect({ runtime: chrome.runtime, storage: chrome.storage, location: root.location, document: root.document });
    root.BookmarkDotsUnread = Object.freeze({...api,sample:connection.sample}); }
})(globalThis);
