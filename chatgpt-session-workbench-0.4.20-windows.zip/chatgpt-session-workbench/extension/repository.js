(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const KEY = 'sessionBookmarks';
  const BACKUP = 'sessionBookmarksLegacyBackup';
  const DEMO_SEED = 'sessionBookmarksDemoSeed';
  const REMOVED_KEY = 'sessionBookmarksRemoved';
  const PENDING_KEY = 'sessionBookmarksRemovedPending';
  const RECOVERY_KEY = 'sessionBookmarksRecoveryBackup';
  const activeState = state => { const { archive, ...active } = state; return active; };
  const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  function createRepository(storage) {
    let queue = Promise.resolve();
    // storage.local.set has no public cross-key transaction guarantee. Keep an undo
    // record until both values have been saved and the operation can be acknowledged.
    // An interrupted operation restores the original active value; a newer value
    // written externally is preserved. Repeating recovery is safe after any await.
    async function recover(pending, raw) {
      if (pending.version !== 1 || !pending.after || !Array.isArray(pending.addedIds)) throw Error('归档恢复记录无效。');
      const values = {};
      const unchanged = equal(raw ?? null, pending.before) || equal(raw, pending.after);
      if (equal(raw, pending.after)) values[KEY] = pending.before;
      const stored = await storage.get(REMOVED_KEY), removed = stored[REMOVED_KEY];
      if (unchanged && removed?.archiveRevision === pending.revision) {
        const added = new Set(pending.addedIds);
        values[REMOVED_KEY] = Object.hasOwn(pending, 'removedBefore') ? pending.removedBefore : { version: 1, archiveRevision: pending.previousRevision,
          archive: M.normalizeArchive(removed.archive, { strict: true }).archive.filter(item => !added.has(item.id)) };
      }
      if (Object.keys(values).length) await storage.set(values);
      await storage.set({ [PENDING_KEY]: null });
    }
    async function execute(action, payload = {}, authorizeDots, authorizeReply) {
      let stored = await storage.get([KEY, PENDING_KEY]), raw = stored[KEY];
      if (stored[PENDING_KEY]) {
        await recover(stored[PENDING_KEY], raw);
        raw = (await storage.get(KEY))[KEY];
      }
      const legacy = () => raw != null && [undefined, 0, 1].includes(raw.version);
      let backup;
      async function saveValues(values, beforeCommit) {
        if (legacy()) {
          if (!backup) backup = await storage.get(BACKUP);
          if (!Object.hasOwn(backup, BACKUP)) values[BACKUP] = raw;
        }
        if (beforeCommit) await beforeCommit();
        await storage.set(values);
      }
      const save = (state, beforeCommit) => saveValues({ [KEY]: activeState(state) }, beforeCommit);
      let removedRecord;
      let archiveRead = false;
      async function readArchive() {
        removedRecord = (await storage.get(REMOVED_KEY))[REMOVED_KEY];
        archiveRead = true;
        if (removedRecord != null && (removedRecord.version !== 1 || !Array.isArray(removedRecord.archive))) throw Error('归档存储格式无效。');
        return M.mergeArchive(removedRecord?.archive, raw?.archive);
      }
      async function saveArchive(state, archive, repairing = false) {
        const revision = crypto.randomUUID();
        const after = { ...activeState(state), archiveRevision: revision };
        const previousIds = new Set((Array.isArray(removedRecord?.archive) ? removedRecord.archive : []).map(item => item?.id));
        const pending = { version: 1, before: raw ?? null, after, revision,
          previousRevision: removedRecord?.archiveRevision || null,
          addedIds: archive.filter(item => !previousIds.has(item.id)).map(item => item.id),
          ...(repairing ? { removedBefore: removedRecord ?? null } : {}) };
        try {
          await storage.set({ [PENDING_KEY]: pending });
          await saveValues({ [KEY]: after, [REMOVED_KEY]: { version: 1, archiveRevision: revision, archive } });
          await storage.set({ [PENDING_KEY]: null });
        } catch (error) {
          // If storage remains unavailable the durable undo record is retained.
          // The next repository operation recovers before allowing any new write.
          try { await recover(pending, (await storage.get(KEY))[KEY]); } catch {}
          throw error;
        }
        raw = after;
        return after;
      }
      if (action === 'export') {
        const separate = (await storage.get(REMOVED_KEY))[REMOVED_KEY];
        const data = raw ?? M.emptyState();
        if (separate != null && (separate.version !== 1 || !Array.isArray(separate.archive)) ||
            Object.hasOwn(data, 'archive') && !Array.isArray(data.archive))
          return { backup: { recovery: { [KEY]: raw ?? null, [REMOVED_KEY]: separate ?? null } } };
        if (!separate) return { backup: data };
        // Export also preserves malformed records so the user can repair a backup.
        const archive = [...(separate.archive || []), ...(data.archive || [])];
        const seen = new Set();
        return { backup: { ...data, archive: archive.filter(item => {
          const key = JSON.stringify(item); if (seen.has(key)) return false; seen.add(key); return true;
        }) } };
      }
      if (action === 'archive-load') {
        const separate = (await storage.get(REMOVED_KEY))[REMOVED_KEY];
        return { ...M.normalizeArchive([...(separate?.archive || []), ...(raw?.archive || [])]),
          archiveRevision: raw?.archiveRevision || separate?.archiveRevision || null };
      }
      if (action === 'restore') {
        const result = M.normalizeState(payload, { strict: true });
        let previous, repairing = false;
        try { previous = await readArchive(); }
        catch (error) {
          if (!archiveRead) throw error; // Unavailable storage is not a damaged archive.
          repairing = true;
          previous = M.normalizeArchive([...(Array.isArray(removedRecord?.archive) ? removedRecord.archive : []),
            ...(Array.isArray(raw?.archive) ? raw.archive : [])]).archive;
        }
        const archive = M.mergeArchive(previous, result.state.archive);
        if (repairing) {
          // Only explicit replacement can repair corrupt history. Preserve both raw
          // values before the existing undo transaction touches either store.
          const storedRecovery = (await storage.get(RECOVERY_KEY))[RECOVERY_KEY];
          if (storedRecovery != null && !Array.isArray(storedRecovery)) throw Error('恢复备份格式无效。');
          const snapshots = storedRecovery || [], original = { [KEY]: raw ?? null, [REMOVED_KEY]: removedRecord ?? null };
          if (!snapshots.some(item => equal(item, original))) await storage.set({ [RECOVERY_KEY]: [...snapshots, original] });
        }
        result.state = archive.length || raw?.archive !== undefined || removedRecord != null
          ? await saveArchive(result.state, archive, repairing) : (await save(result.state), activeState(result.state));
        return result;
      }
      if (action === 'import') {
        const incoming = M.normalizeState(payload, { strict: true }).state;
        const parsed = M.normalizeState(raw, { includeArchive: false });
        if (parsed.rejected) throw new Error('存储中有无效记录，请先导出备份并修复数据。');
        const archive = M.mergeArchive(await readArchive(), incoming.archive);
        let state = M.mergeImport(activeState(parsed.state), activeState(incoming));
        if (archive.length || raw?.archive !== undefined || removedRecord != null) state = await saveArchive(state, archive);
        else await save(state);
        return { state, rejected: 0, migrated: false };
      }
      // Migrate the already-developed 062 inline schema once, without rewriting
      // user titles/categories or making later reply/refresh operations read history.
      const parsed = M.normalizeState(raw, { includeArchive: false });
      if (raw?.archive !== undefined) {
        if (parsed.rejected) {
          if (action === 'load') return { ...parsed, state: activeState(parsed.state) };
          throw new Error('存储中有无效记录，请先导出备份并修复数据。');
        }
        await saveArchive(raw, await readArchive());
        parsed.state = { ...activeState(parsed.state), archiveRevision: raw.archiveRevision };
      }
      if (action === 'load') return parsed;
      if (action === 'reply-check' || action === 'reply-observe') {
        if (authorizeReply) await authorizeReply();
        const entry = parsed.state.bookmarks.find(b => b.id === payload.id && b.kind === 'chatgpt');
        if (!entry || action === 'reply-check') return { bookmarked: Boolean(entry), revision: entry?.replyState?.revision || 0,
          current: entry?.replyState || null, ...(action === 'reply-observe' ? { accepted: false, synchronized: false } : {}) };
        if (parsed.rejected) throw new Error('存储中有无效记录，请先导出备份并修复数据。');
        let reason;
        const state = M.observeReply(parsed.state, payload, value => { reason = value; });
        if (state !== parsed.state) {
          await save(state, authorizeReply);
        }
        const current = state.bookmarks.find(b => b.id === payload.id).replyState;
        const synchronized = Boolean(current && ['author', 'phase', 'messageId', 'userMessageId'].every(key => current[key] === (payload[key] ?? null)));
        return { bookmarked: true, revision: current?.revision || 0, current: current || null, accepted: state !== parsed.state, synchronized, reason };
      }
      if (action === 'quick-check' || action === 'quick-add') {
        if (authorizeReply) await authorizeReply();
        const link = M.normalizeURL(payload.url);
        if (link.kind !== 'chatgpt') throw new Error('ChatGPT 链接无效。');
        const bookmarked = parsed.state.bookmarks.some(b => b.id === link.id);
        if (action === 'quick-check' || bookmarked) return { bookmarked };
        if (parsed.rejected) throw new Error('存储中有无效记录，请先导出备份并修复数据。');
        const categoryId = parsed.state.categories.some(c => c.id === payload.categoryId) ? payload.categoryId : null;
        await save(M.addBookmark(parsed.state, { url: link.url, title: payload.title, categoryId, projectId: null }), authorizeReply);
        return { bookmarked: true };
      }
      // Recheck inside the queue: another panel or the floating button may have saved while a form was open.
      if (action === 'capture' && parsed.state.bookmarks.some(b => b.id === M.normalizeURL(payload.url).id)) return parsed;
      if (parsed.rejected) throw new Error('存储中有无效记录，请先导出备份并修复数据。');
      let state = parsed.state;
      let categoryId;
      switch (action) {
        case 'dots-add': {
          if (typeof authorizeDots !== 'function') throw Error('Dots 资格尚未确认。');
          // Resolve migration I/O before validating the live destination.
          if (legacy()) backup = await storage.get(BACKUP);
          const destination = await authorizeDots();
          state = M.addBookmark(state, { kind: 'dots', id: `dots:${crypto.randomUUID()}`,
            url: destination.url, binding: destination.binding, title: payload.title, categoryId: payload.categoryId });
          break;
        }
        case 'capture': state = M.addBookmark(state, { ...payload, projectId: null }); break;
        case 'add':
          if (payload.kind === 'dots') throw Error('请使用添加 Dots。');
          state = M.addBookmark(state, payload); break;
        case 'edit': state = M.updateBookmark(state, payload); break;
        case 'move': state = M.moveBookmark(state, payload); break;
        case 'remove':
          if (!state.bookmarks.some(item => item.id === payload.id)) break;
          state = M.removeBookmark({ ...state, archive: await readArchive() }, payload.id);
          state = await saveArchive(state, state.archive);
          return { state, rejected: 0, migrated: false };
        case 'project-create': state = M.createProject(state, { ...payload, id: crypto.randomUUID() }); break;
        case 'project-join': state = M.joinProject(state, payload); break;
        case 'project-rename': state = M.renameProject(state, payload); break;
        case 'project-dissolve': state = M.dissolveProject(state, payload.id); break;
        case 'project-detach': state = M.detachBookmark(state, payload.id); break;
        case 'category-create':
          categoryId = crypto.randomUUID();
          state = M.createCategory(state, { ...payload, id: categoryId }); break;
        case 'category-reorder': state = M.reorderCategory(state, payload); break;
        case 'category-rename': state = M.renameCategory(state, payload); break;
        case 'category-delete': state = M.deleteCategory(state, payload.id); break;
        default: throw new Error('操作不受支持。');
      }
      if (state !== parsed.state) {
        await save(state);
      }
      return { state, rejected: 0, migrated: false, ...(categoryId ? { categoryId } : {}) };
    }
    function serial(operation) {
      const next = queue.then(operation);
      queue = next.catch(() => {});
      return next;
    }
    return { initialize(reason) {
      return serial(async () => {
        if (!['install', 'update'].includes(reason)) return;
        const stored = await storage.get([KEY, DEMO_SEED]);
        if (stored[DEMO_SEED] !== undefined) return;
        // Any existing library, including an empty imported one, belongs to the user.
        await storage.set({ [DEMO_SEED]: true,
          ...(reason === 'install' && stored[KEY] === undefined ? { [KEY]: M.demoState() } : {}) });
      });
    }, dispatch(action, payload, authorizeDots, authorizeReply) {
      return serial(() => execute(action, payload, authorizeDots, authorizeReply));
    } };
  }
  const api = { KEY, BACKUP, DEMO_SEED, REMOVED_KEY, PENDING_KEY, RECOVERY_KEY, createRepository };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkRepository = api;
})(globalThis);
