(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const KEY = 'sessionBookmarksClosedWatch', ALARM = 'session-bookmarks-closed-watch';
  const INTERVAL = 3 * 60 * 1000;
  const generating = reply => ['assistant', 'tool'].includes(reply?.author) && reply.phase === 'generating';
  function pageId(value) {
    try { const link = M.normalizeURL(value); return link.kind === 'chatgpt' ? link.id : null; }
    catch { return null; }
  }
  const markerOf = tab => /#workbench-refresh-[a-z0-9-]+$/.exec(tab?.pendingUrl || tab?.url || '')?.[0];
  const validId = id => typeof id === 'string' && pageId(`https://chatgpt.com/c/${id.slice(8)}`) === id;
  function createService({ browser, repository, isOtherTemporary = () => false, now = Date.now,
    timeoutMs = 20000, pollMs = 250, startupRestoreMs = 3000, startupQuietMs = 1000, startupMaxMs = 10000,
    claim = async () => ({ allowed: true }), preserveStartupDeadline = false }) {
    let state = { schema: 2, jobs: [], live: [], leases: [], history: [], startup: null,
      ...(preserveStartupDeadline ? { policy: 'pending-3m' } : {}) };
    let initialized, serial = Promise.resolve(), ticking = null, manual = 0, startupRequested = false;
    const removed = new Map(), runtimeOwned = new Set();
    const focusedWindows = new Set();
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    const command = operation => {
      const next = serial.catch(() => {}).then(operation); serial = next; return next;
    };
    const save = () => browser.storage.local.set({ [KEY]: JSON.parse(JSON.stringify(state)) });
    const load = async () => (await bounded(() => repository.dispatch('load', { activeOnly: true }))).state.bookmarks.filter(b => b.kind === 'chatgpt' && !b.archived && !b.archivedAt);
    const queryTabs = () => bounded(() => browser.tabs.query({}));
    const leaseFor = id => state.leases.find(l => l.tabId === id);
    function temporary(tab) {
      const lease = leaseFor(tab.id);
      return Boolean(lease && !lease.adopted || state.leases.some(l => l.tabId === null && markerOf(tab) === l.marker) || isOtherTemporary(tab));
    }
    const realTabs = tabs => tabs.filter(t => Number.isInteger(t.id) && !temporary(t) && pageId(t.pendingUrl || t.url));
    const hasReal = (tabs, id) => realTabs(tabs).some(t => pageId(t.pendingUrl || t.url) === id);
    function record(id, reason, extra = {}) {
      state.history.push({ id, at: now(), reason, ...extra }); state.history = state.history.slice(-80);
    }
    async function schedule() {
      const deadlines = state.leases.length || state.startup?.waitingForWindow ? [now() + INTERVAL] : state.jobs.map(j => j.dueAt);
      if (!deadlines.length) { await browser.alarms?.clear(ALARM); return; }
      await browser.alarms?.create(ALARM, { when: Math.max(now() + 1000, Math.min(...deadlines)) });
    }
    function enqueue(id, bookmarks, reason = 'last-generating-tab-closed') {
      const b = bookmarks.find(b => b.id === id);
      if (!b || !generating(b.replyState) || state.jobs.some(j => j.id === id)) return;
      state.jobs.push({ id, dueAt: now() + INTERVAL, revision: b.replyState.revision, attempts: 0 });
      record(id, reason);
    }
    async function bounded(operation, ms = timeoutMs) {
      let timer;
      try { return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
        timer = setTimeout(() => reject(Error('timeout')), Math.max(1, ms));
      })]); } finally { clearTimeout(timer); }
    }
    async function cleanup(lease) {
      let tab;
      try {
        const tabs = await queryTabs();
        const matching = tabs.filter(t => lease.tabId === null ? markerOf(t) === lease.marker : t.id === lease.tabId);
        if (matching.length > 1) { record(lease.id, 'ownership-unverified'); return false; }
        tab = matching[0];
        if (tab && lease.tabId === null) { lease.tabId = tab.id; if (!Number.isInteger(lease.windowId)) lease.windowId = tab.windowId; }
      }
      catch { record(lease.id, 'cleanup-query-failed', { tabId: lease.tabId }); return false; }
      if (!tab && lease.tabId === null && !lease.creationFailed) { record(lease.id, 'creation-pending'); return false; }
      if (tab && lease.kind === 'popup' && tab.windowId !== lease.windowId) lease.adopted = true;
      if (tab && lease.kind === 'popup' && !lease.adopted) {
        let window;
        try { window = await bounded(() => browser.windows.get(lease.windowId, { populate: true })); }
        catch { record(lease.id, 'cleanup-window-unverified'); return false; }
        if (!lease.ready && !window.focused && !focusedWindows.has(lease.windowId) && window.state !== 'minimized') {
          record(lease.id, 'minimize-unconfirmed'); return false;
        }
        if (focusedWindows.has(lease.windowId) || window.focused || window.state !== 'minimized' || window.type !== 'popup' ||
            tab.windowId !== lease.windowId || window.tabs?.length !== 1 || window.tabs[0].id !== tab.id) lease.adopted = true;
        // A popup's sole tab is active even while its window is minimized.
        if (!lease.adopted && !runtimeOwned.has(tab.id) && markerOf(tab) !== lease.marker) { record(lease.id, 'ownership-unverified'); return false; }
      }
      if (!tab) { record(lease.id, 'temporary-closed', { tabId: lease.tabId }); }
      else if (lease.adopted || lease.kind !== 'popup' && tab.active && (runtimeOwned.has(tab.id) || markerOf(tab) === lease.marker)) {
        lease.adopted = true;
        if (pageId(tab.pendingUrl || tab.url) === lease.id) {
          state.live = state.live.filter(t => t.tabId !== tab.id);
          state.live.push({ tabId: tab.id, id: lease.id, adoptedMarker: lease.marker });
          state.jobs = state.jobs.filter(j => j.id !== lease.id);
        }
        record(lease.id, 'temporary-adopted', { tabId: lease.tabId });
      } else if (tab.windowId === lease.windowId && (runtimeOwned.has(tab.id) || markerOf(tab) === lease.marker)) {
        // Persist the lease until removal succeeds; failed cleanup occupies the single slot.
        try {
          if (lease.adopted) return false;
          lease.closing = true;
          // Removing its last owned tab closes the popup. A tab added after the window snapshot
          // survives this API call; windows.remove would also destroy that newly added user tab.
          await bounded(() => browser.tabs.remove(tab.id));
          record(lease.id, 'temporary-closed', { tabId: tab.id });
        }
        catch { lease.closing = false; record(lease.id, 'temporary-close-failed', { tabId: tab.id }); return false; }
      } else { record(lease.id, 'ownership-unverified', { tabId: lease.tabId }); return false; }
      state.leases = state.leases.filter(l => l !== lease); runtimeOwned.delete(lease.tabId);
      return true;
    }
    function recover() {
      if (initialized) return initialized;
      initialized = command(async () => {
        const stored = (await browser.storage.local.get(KEY))[KEY];
        if ([1, 2].includes(stored?.schema)) {
          // Old/partial data grants neither an arbitrary URL nor tab-ID-only removal authority.
          state.jobs = (Array.isArray(stored.jobs) ? stored.jobs : []).filter(j => validId(j?.id) &&
            Number.isSafeInteger(j.dueAt) && j.dueAt >= 0 && Number.isSafeInteger(j.revision) && j.revision > 0)
            .map(j => ({ id: j.id, dueAt: j.dueAt, revision: j.revision, attempts: Number.isSafeInteger(j.attempts) ? j.attempts : 0 }));
          state.live = (Array.isArray(stored.live) ? stored.live : []).filter(t => validId(t?.id) && Number.isInteger(t.tabId))
            .map(t => ({ tabId: t.tabId, id: t.id, ...(typeof t.adoptedMarker === 'string' ? { adoptedMarker: t.adoptedMarker } : {}) }));
          state.leases = (Array.isArray(stored.leases) ? stored.leases : []).filter(l => validId(l?.id) &&
            /^#workbench-refresh-closed-[a-z0-9-]+$/.test(l.marker) && (l.tabId === null || Number.isInteger(l.tabId)))
            .map(l => ({ id: l.id, tabId: l.tabId, windowId: l.windowId, marker: l.marker, adopted: l.adopted === true,
              ...(l.kind === 'popup' ? { kind: 'popup', ready: l.ready === true } : {}),
              ...(l.creationFailed === true ? { creationFailed: true } : {}) }));
          if (stored.startup?.pending === true && Number.isSafeInteger(stored.startup.readyAt) && Number.isSafeInteger(stored.startup.maxAt)) {
            state.startup = { pending: true, readyAt: stored.startup.readyAt, maxAt: stored.startup.maxAt,
              waitingForWindow: stored.startup.waitingForWindow === true };
          }
          state.history = (Array.isArray(stored.history) ? stored.history : []).filter(h => validId(h?.id) &&
            Number.isSafeInteger(h.at) && /^[a-z-]{1,60}$/.test(h.reason)).slice(-80).map(h => ({
              id: h.id, at: h.at, reason: h.reason, ...(Number.isInteger(h.tabId) ? { tabId: h.tabId } : {}),
              ...(typeof h.verified === 'boolean' ? { verified: h.verified } : {}),
              ...(['generating', 'complete'].includes(h.phase) ? { phase: h.phase } : {}),
              ...(Number.isSafeInteger(h.attempts) ? { attempts: h.attempts } : {}) }));
          // Upgrade old catch-up journals before an overdue alarm can use their immediate deadline.
          if (preserveStartupDeadline && stored.policy !== 'pending-3m') {
            for (const job of state.jobs) job.dueAt = Math.max(job.dueAt, now() + INTERVAL);
            state.startup = null;
          }
        }
        let tabs = await queryTabs();
        const bookmarks = state.jobs.length || state.live.length ? await load() : [];
        for (const lease of [...state.leases]) {
          if (lease.tabId === null) {
            const matching = tabs.filter(t => markerOf(t) === lease.marker);
            const tab = matching.length === 1 ? matching[0] : null;
            if (tab) { lease.tabId = tab.id; if (!Number.isInteger(lease.windowId)) lease.windowId = tab.windowId; }
          }
          await cleanup(lease);
        }
        tabs = await queryTabs();
        // Only a persisted real document can supply a missed shutdown/close transition.
        for (const live of state.live) if (!hasReal(tabs, live.id)) enqueue(live.id, bookmarks);
        state.jobs = state.jobs.filter((j, i, all) => all.findIndex(x => x.id === j.id) === i &&
          generating(bookmarks.find(b => b.id === j.id)?.replyState) && !hasReal(tabs, j.id));
        state.live = realTabs(tabs).map(t => ({ tabId: t.id, id: pageId(t.pendingUrl || t.url),
          ...(state.live.find(l => l.tabId === t.id)?.adoptedMarker ? { adoptedMarker: markerOf(t) } : {}) }));
        if (!state.jobs.length) state.startup = null;
        await save(); await schedule();
      });
      initialized.catch(() => { initialized = null; });
      return initialized;
    }
    async function tabSeen(tab) {
      await recover();
      return command(async () => {
        if (!Number.isInteger(tab?.id)) return;
        let id = pageId(tab.pendingUrl || tab.url);
        if (temporary(tab)) return;
        const previous = state.live.find(t => t.tabId === tab.id);
        if (!id && !previous || previous?.id === id && !state.jobs.some(j => j.id === id)) return;
        // Events can queue during a rapid A -> B -> A route change. Reconcile the real
        // document before retiring A, and never give a temporary collector a live identity.
        const tabs = previous && previous.id !== id ? await queryTabs() : null;
        if (tabs) {
          tab = tabs.find(t => t.id === tab.id);
          if (!tab || temporary(tab)) return;
          id = pageId(tab.pendingUrl || tab.url);
          if (previous.id === id && !state.jobs.some(j => j.id === id)) return;
        }
        state.live = state.live.filter(t => t.tabId !== tab.id);
        if (previous && previous.id !== id && !hasReal(tabs, previous.id))
          enqueue(previous.id, await load(), 'last-generating-tab-left');
        if (id) {
          state.live.push({ tabId: tab.id, id, ...(previous?.adoptedMarker && previous.adoptedMarker === markerOf(tab) ? { adoptedMarker: previous.adoptedMarker } : {}) });
          const canceled = state.jobs.some(j => j.id === id);
          state.jobs = state.jobs.filter(j => j.id !== id);
          if (canceled) record(id, 'user-reopened');
        }
        await save(); await schedule();
      });
    }
    function tabRemoved(tabId) {
      // Capture before asynchronous work; this also authorizes a previously validated in-flight generating write.
      const live = state.live.find(t => t.tabId === tabId);
      const lease = leaseFor(tabId);
      if (lease?.kind === 'popup' && !lease.closing && !lease.closed) {
        lease.closed = true; record(lease.id, 'check-window-closed');
      }
      if (live) removed.set(tabId, { id: live.id, at: now() });
      for (const [id, entry] of removed) if (now() - entry.at > 30000) removed.delete(id);
      return recover().then(() => command(async () => {
        const entry = state.live.find(t => t.tabId === tabId);
        if (!entry && !leaseFor(tabId)) return;
        state.live = state.live.filter(t => t.tabId !== tabId);
        if (entry && !leaseFor(tabId)) {
          const tabs = await queryTabs();
          if (!hasReal(tabs, entry.id)) enqueue(entry.id, await load());
        }
        await save(); await schedule();
      }));
    }
    const wasRemoved = (tabId, id) => removed.get(tabId)?.id === id && now() - removed.get(tabId).at <= 30000;
    async function observed(tabId, id, result) {
      if (!wasRemoved(tabId, id)) return;
      await recover();
      return command(async () => {
        if (result?.bookmarked && wasRemoved(tabId, id) && generating(result.current)) {
          if (!hasReal(await queryTabs(), id)) enqueue(id, await load());
        }
        await save(); await schedule();
      });
    }
    async function adopt(tabId, reason = 'trusted-user-takeover') {
      // Mark synchronously so cleanup waiting on a browser API sees a newly delivered claim.
      const pendingLease = leaseFor(tabId);
      if (pendingLease) pendingLease.adopted = true;
      await recover();
      return command(async () => {
        const lease = leaseFor(tabId);
        if (!lease) return false;
        lease.adopted = true;
        const tab = await bounded(() => browser.tabs.get(tabId)).catch(() => null);
        if (pageId(tab?.pendingUrl || tab?.url) === lease.id) {
          state.live = state.live.filter(t => t.tabId !== tabId);
          state.live.push({ tabId, id: lease.id, adoptedMarker: lease.marker });
          state.jobs = state.jobs.filter(j => j.id !== lease.id);
        }
        record(lease.id, reason, { tabId });
        await save(); await schedule(); return true;
      });
    }
    async function tabActivated(tabId) {
      if (!state.leases.length) return false;
      if (leaseFor(tabId)?.kind === 'popup') return windowChanged({ id: leaseFor(tabId).windowId });
      if (leaseFor(tabId)) return adopt(tabId);
      const tab = await bounded(() => browser.tabs.get(tabId));
      const intent = state.leases.find(l => l.tabId === null && markerOf(tab) === l.marker);
      if (!intent) return false;
      intent.tabId = tabId; intent.windowId = tab.windowId;
      return intent.kind === 'popup' ? windowChanged({ id: tab.windowId }) : adopt(tabId);
    }
    function ownsWindow(windowId) { return state.leases.some(l => l.kind === 'popup' && l.windowId === windowId); }
    async function windowChanged(window, focused = false) {
      if (focused) focusedWindows.add(window.id);
      const lease = state.leases.find(l => l.kind === 'popup' && l.windowId === window.id);
      if (!lease) return false;
      if (focused || window.focused || lease.ready && window.state && window.state !== 'minimized') lease.adopted = true;
      if (!lease.ready && !lease.adopted) return false;
      const current = await bounded(() => browser.windows.get(window.id));
      if (lease.adopted || current.focused || current.state !== 'minimized') return adopt(lease.tabId, 'window-takeover');
      return false;
    }
    function windowRemoved(windowId) {
      focusedWindows.delete(windowId);
      const lease = state.leases.find(l => l.kind === 'popup' && l.windowId === windowId);
      if (!lease || lease.closing || lease.closed) return Promise.resolve();
      lease.closed = true;
      return command(async () => { record(lease.id, 'check-window-closed'); await save(); });
    }
    async function startup(source = 'browser') {
      if (startupRequested) return ticking;
      startupRequested = true;
      await recover();
      await command(async () => {
        if (!state.jobs.length) return;
        for (const job of state.jobs) {
          job.dueAt = preserveStartupDeadline ? Math.max(job.dueAt, now() + INTERVAL) : now();
          record(job.id, preserveStartupDeadline ? source === 'install' ? 'install-deferred' : 'startup-deferred' : source === 'install' ? 'install-catchup' : 'browser-startup-catchup');
        }
        state.startup = preserveStartupDeadline ? null : { pending: true, readyAt: now() + startupRestoreMs, maxAt: now() + startupMaxMs, waitingForWindow: false };
        await save(); await schedule();
      });
      if (state.jobs.length) return tick();
    }
    async function settleStartup() {
      const restore = state.startup;
      if (!restore) return true;
      const windows = await bounded(() => browser.windows.getAll({ windowTypes: ['normal'] }));
      if (!windows.some(w => w.type === 'normal' && Number.isInteger(w.id))) {
        restore.waitingForWindow = true; await command(async () => { await save(); await schedule(); }); return false;
      }
      if (restore.waitingForWindow) {
        restore.readyAt = now() + startupRestoreMs; restore.maxAt = now() + startupMaxMs; restore.waitingForWindow = false;
      }
      const end = Date.now() + Math.min(startupMaxMs, Math.max(0, restore.maxAt - now()));
      let ready = Date.now() + Math.max(0, restore.readyAt - now()), signature;
      while (Date.now() < Math.min(end, ready)) {
        const tabs = await queryTabs();
        const next = JSON.stringify(tabs.filter(t => !temporary(t)).map(t => [t.id, t.windowId, t.pendingUrl || t.url, t.status]).sort((a,b) => a[0]-b[0]));
        if (signature !== undefined && signature !== next) ready = Math.max(ready, Date.now() + startupQuietMs);
        signature = next; await pause(Math.min(pollMs, Math.max(1, Math.min(end, ready) - Date.now())));
      }
      await command(async () => { if (state.startup === restore) state.startup = null; await save(); });
      return true;
    }
    function windowCreated(window) {
      if (window.type !== 'normal') return Promise.resolve();
      return recover().then(async () => {
        if (!state.startup) return;
        // A first window can arrive while the no-window query is still resolving.
        if (ticking) await ticking;
        if (state.startup) return tick();
      });
    }
    async function authorizeObservation(tabId, id) {
      const lease = leaseFor(tabId);
      if (!lease || lease.adopted) return;
      if (lease.id !== id || !state.jobs.some(j => j.id === id) || hasReal(await queryTabs(), id)) throw Error('closed-check-canceled');
    }
    async function reconcile() {
      await recover();
      return command(async () => {
        if (!state.jobs.length) return;
        const bookmarks = await load();
        const jobs = state.jobs.filter(j => bookmarks.some(b => b.id === j.id) &&
          (state.leases.some(l => l.id === j.id) || generating(bookmarks.find(b => b.id === j.id).replyState)));
        if (jobs.length === state.jobs.length) return;
        state.jobs = jobs;
        await save(); await schedule();
      });
    }
    // The manual all-sessions refresh can observe a still-generating conversation
    // without an existing real tab. It must enter the same three-minute monitor as
    // a user-closed generating tab, rather than vanishing when its temporary tab closes.
    async function continueAfterManual(result) {
      const ids = [...new Set((result?.details || []).filter(detail => detail.kind === 'chatgpt' &&
        detail.result === 'success' && detail.verification === 'verified-dom' &&
        detail.storageVerified === true && detail.observation?.phase === 'generating').map(detail => detail.id))];
      if (!ids.length) return { scheduled: 0 };
      await recover();
      return command(async () => {
        const [tabs, bookmarks] = await Promise.all([queryTabs(), load()]);
        let scheduled = 0;
        for (const id of ids) {
          if (hasReal(tabs, id)) continue;
          const previous = state.jobs.length;
          enqueue(id, bookmarks, 'manual-refresh-generating');
          if (state.jobs.length > previous) scheduled++;
        }
        if (scheduled) { await save(); await schedule(); }
        return { scheduled };
      });
    }
    async function check(job) {
      let lease, reason = 'timeout', verified = false, phase = null, creationStarted = false;
      try {
        await command(async () => {
          const b = (await load()).find(b => b.id === job.id), tabs = await queryTabs();
          if (!state.jobs.includes(job) || !b || !generating(b.replyState) || hasReal(tabs, job.id)) {
            state.jobs = state.jobs.filter(j => j !== job); reason = 'not-generating-or-reopened'; return;
          }
          const windows = browser.windows?.getAll ? await bounded(() => browser.windows.getAll({ windowTypes: ['normal'] })) :
            tabs.map(t => ({ id: t.windowId }));
          const windowId = windows.find(w => Number.isInteger(w.id) && w.id >= 0)?.id;
          if (windowId === undefined) { reason = 'no-browser-window'; return; }
          const budget = await claim(job.id, 'closed');
          if (!budget.allowed) { job.dueAt = budget.nextAt; reason = 'cadence'; return; }
          // An intent is durable before create, covering worker loss before tabs.create returns.
          lease = { id: job.id, tabId: null, windowId: null, kind: 'popup', ready: false, adopted: false,
            marker: `#workbench-refresh-closed-${now().toString(36)}-${Math.random().toString(36).slice(2)}` };
          state.leases.push(lease); job.attempts++; await save();
          creationStarted = true;
          let creation;
          try { creation = Promise.resolve(browser.windows.create({ url: 'about:blank' + lease.marker, focused: false, state: 'minimized', type: 'popup' })); }
          catch (error) { lease.creationFailed = true; throw error; }
          // A late API result keeps the durable intent and occupies capacity until it can be cleaned.
          creation.then(window => {
            const tab = window?.tabs?.[0];
            if (!Number.isInteger(window?.id) || !Number.isInteger(tab?.id)) return;
            lease.tabId = tab.id; lease.windowId = window.id; runtimeOwned.add(tab.id);
            if (window.focused || focusedWindows.has(window.id)) lease.adopted = true;
          }, () => { lease.creationFailed = true; });
          const window = await bounded(() => creation), tab = window?.tabs?.[0];
          if (!Number.isInteger(window?.id) || !Number.isInteger(tab?.id)) throw Error('create-failed');
          await save();
          let current = await bounded(() => browser.windows.get(window.id, { populate: true }));
          if (lease.adopted || current.focused || current.type !== 'popup' || current.tabs?.length !== 1 || current.tabs[0].id !== tab.id) { lease.adopted = true; return; }
          // Edge may ignore the initial minimized state. Only the marked blank document exists during this fallback.
          if (current.state !== 'minimized') await bounded(() => browser.windows.update(window.id, { state: 'minimized' }));
          current = await bounded(() => browser.windows.get(window.id, { populate: true }));
          if (lease.adopted || current.focused || current.state !== 'minimized' || current.tabs?.length !== 1 || current.tabs[0].id !== tab.id) { lease.adopted = true; return; }
          lease.ready = true; await save();
          // A session-restored real tab can arrive while the window was being prepared.
          if (hasReal(await queryTabs(), job.id) || !state.jobs.includes(job) || manual || lease.adopted) { reason = 'canceled'; return; }
          await bounded(() => browser.tabs.update(tab.id, { url: b.url.split('#')[0] + lease.marker }));
        });
        if (!lease) return;
        const end = Date.now() + timeoutMs;
        while (Date.now() < end) {
          if (manual || lease.adopted || lease.closed || !state.jobs.includes(job) || hasReal(await queryTabs(), job.id)) {
            reason = lease.adopted ? 'temporary-adopted' : 'canceled'; break;
          }
          const tab = await bounded(() => browser.tabs.get(lease.tabId), end - Date.now());
          const window = await bounded(() => browser.windows.get(lease.windowId));
          if (window.focused || window.state !== 'minimized') { await adopt(tab.id); reason = 'temporary-adopted'; break; }
          if (pageId(tab.pendingUrl || tab.url) !== job.id || tab.windowId !== lease.windowId) { reason = 'route-changed'; break; }
          if (tab.status === 'loading') { await pause(pollMs); continue; }
          const requestId = `${lease.marker}:${now()}`, sentAt = now();
          let receipt;
          try { receipt = await bounded(() => browser.tabs.sendMessage(tab.id,
            { channel: 'session-bookmarks-refresh', action: 'rescan', id: job.id, temporary: true, requestId }, { frameId: 0 }), Math.min(1500, end - Date.now())); }
          catch { reason = 'receiver-unavailable'; await pause(pollMs); continue; }
          const current = await bounded(() => browser.tabs.get(tab.id), end - Date.now());
          const currentWindow = await bounded(() => browser.windows.get(lease.windowId));
          if (currentWindow.focused || currentWindow.state !== 'minimized') { await adopt(tab.id); reason = 'temporary-adopted'; break; }
          if (lease.adopted || lease.closed || !state.jobs.includes(job) || hasReal(await queryTabs(), job.id)) { reason = 'canceled'; break; }
          if (pageId(current.url) !== job.id || current.pendingUrl && pageId(current.pendingUrl) !== job.id || current.status === 'loading') { reason = 'route-changed'; break; }
          const r = receipt?.replyState;
          if (receipt?.noData || receipt?.stateConflict || r?.phase === 'unknown') reason = receipt.stateConflict ? 'state-conflict' : 'no-data';
          else if (receipt?.version === browser.runtime.getManifest().version && receipt.id === job.id && pageId(receipt.url) === job.id &&
              receipt.requestId === requestId && Number.isSafeInteger(receipt.sampledAt) && receipt.sampledAt >= sentAt && receipt.sampledAt <= now() + 1000 &&
              receipt.initialized === true && receipt.diagnostic?.stage !== 'candidate' &&
              (generating(r) || r?.author === 'assistant' && r.phase === 'complete')) {
            const saved = (await load()).find(b => b.id === job.id)?.replyState;
            verified = Boolean(saved && Number.isSafeInteger(r.revision) && receipt.storedRevision === r.revision &&
              ['author', 'phase', 'revision', 'messageId', 'userMessageId'].every(k => (saved[k] ?? null) === (r[k] ?? null)));
            if (verified) { phase = r.phase; reason = phase === 'complete' ? 'assistant-complete' : 'still-generating'; break; }
            reason = 'storage-unacknowledged';
          }
          await pause(pollMs);
        }
      } catch (error) {
        if (lease && !creationStarted) lease.creationFailed = true;
        reason = error?.message === 'timeout' ? 'timeout' : 'tab-operation-failed';
      }
      finally {
        await command(async () => {
          if (lease) await cleanup(lease);
          record(job.id, reason, { verified, phase, attempts: job.attempts });
          if (verified && phase === 'complete') state.jobs = state.jobs.filter(j => j !== job);
          else if (state.jobs.includes(job) && reason !== 'cadence') job.dueAt = now() + INTERVAL;
          await save(); await schedule();
        });
      }
    }
    function tick() {
      if (ticking) return ticking;
      ticking = (async () => {
        await recover();
        if (manual) return;
        if (!state.jobs.length && !state.leases.length) return;
        // onStartup may be queued behind recovery while this alarm is delivered in the same turn.
        await command(() => {});
        if (!await settleStartup()) return;
        await command(async () => { for (const lease of [...state.leases]) await cleanup(lease); await save(); });
        // A failed or unverified close occupies capacity; each alarm performs at most two sequential checks.
        for (let count = 0; count < 2 && !manual && !state.leases.length; count++) {
          const job = [...state.jobs].sort((a, b) => a.dueAt - b.dueAt).find(j => j.dueAt <= now());
          if (!job) break;
          await check(job);
        }
        await command(schedule);
      })().catch(async () => {
        await command(async () => {
          for (const job of state.jobs) if (job.dueAt <= now()) job.dueAt = now() + INTERVAL;
          await save(); await schedule();
        });
      }).finally(() => { ticking = null; });
      return ticking;
    }
    async function withManualRun(operation) {
      manual++;
      try { await recover(); if (ticking) await ticking; return await operation(); }
      finally { manual--; await command(schedule); }
    }
    return { recover, startup, tick, tabSeen, tabRemoved, tabActivated, windowChanged, windowRemoved, windowCreated, ownsWindow,
      observed, adopt, wasRemoved, authorizeObservation, reconcile, continueAfterManual, withManualRun, isTemporary: temporary };
  }
  const api = { KEY, ALARM, INTERVAL, pageId, generating, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkClosedWatch = api;
})(globalThis);
