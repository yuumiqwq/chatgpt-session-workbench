(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const KEY = 'sessionBookmarksReceivers', ALARM = 'session-bookmarks-receivers';
  const FILES = ['model.js', 'chatgpt-dom.js', 'statistics.js', 'onboarding.js', 'quick-button.js', 'quick-guide.js', 'diagnostics.js', 'content.js'];
  const pageId = url => { try { const p = M.normalizeURL(url); return p.kind === 'chatgpt' ? p.id : null; } catch { return null; } };
  const missing = error => /receiving end does not exist|could not establish connection/i.test(error?.message || '');
  function createService({ browser, repository, version, now = Date.now, timeoutMs = 6000 }) {
    let running, changedRunning, loaded, lastSaved, serial = 0, saving = Promise.resolve();
    const records = new Map(), epochs = new Map(), pendingTabs = new Set();
    async function load() {
      if (!loaded) loaded = (async () => {
        const raw = (await browser.storage.session?.get?.(KEY))?.[KEY];
        for (const record of Array.isArray(raw) ? raw.slice(-256) : []) if (record && Number.isInteger(record.tabId) && pageId(record.url) === record.id) {
          if (!records.has(record.tabId)) {
            const failed = record.recoveryPending === true || record.status === 'recovering' || record.status === 'unavailable' &&
              !['not-checked', 'worker-restarted', 'document-not-ready'].includes(record.reason);
            records.set(record.tabId, { ...record, history: Array.isArray(record.history) ? record.history.slice(-16) : [],
              recoveryPending: failed || record.recoveryPending === true, status: failed ? 'unavailable' : 'checking', reason: failed ? record.reason : 'worker-restarted', nextAttemptAt: 0 });
          }
        }
      })().catch(error => { loaded = null; throw error; });
      await loaded;
    }
    function persist() {
      const data = [...records.values()].slice(-256).map(r => ({ ...r, history: [...r.history] }));
      saving = saving.catch(() => {}).then(async () => {
        const encoded = JSON.stringify(data);
        if (encoded === lastSaved) return;
        await browser.storage.session?.set?.({ [KEY]: data }); lastSaved = encoded;
      });
      return saving;
    }
    async function bounded(work) {
      let timer;
      try { return await Promise.race([Promise.resolve().then(work), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('receiver-timeout')), timeoutMs); })]); }
      finally { clearTimeout(timer); }
    }
    async function targets() {
      const [{ state }, tabs] = await Promise.all([repository.dispatch('load', { activeOnly: true }), browser.tabs.query({})]);
      const saved = new Set(state.bookmarks.filter(b => b.kind === 'chatgpt').map(b => b.id));
      return tabs.filter(t => saved.has(pageId(t.pendingUrl || t.url)));
    }
    async function snapshot() {
      await load();
      return (await targets()).map(tab => {
        const id = pageId(tab.pendingUrl || tab.url), record = records.get(tab.id);
        return record?.id === id && record.url === tab.url ? { ...record, history: [...record.history] } :
          { tabId: tab.id, id, url: tab.url, status: 'checking', reason: 'not-checked', history: [] };
      });
    }
    async function forget(tabId) {
      epochs.set(tabId, (epochs.get(tabId) || 0) + 1);
      await load(); records.delete(tabId); await persist();
    }
    async function inspect(tab) {
      const id = pageId(tab.url), epoch = epochs.get(tab.id) || 0;
      if (!id || tab.pendingUrl && tab.pendingUrl !== tab.url) return;
      let record = records.get(tab.id);
      if (!record || record.id !== id || record.url !== tab.url) record = { tabId: tab.id, id, url: tab.url, history: [], attempts: 0 };
      if (record.nextAttemptAt > now()) return;
      records.set(tab.id, record);
      const current = async () => {
        const latest = await browser.tabs.get(tab.id);
        if ((epochs.get(tab.id) || 0) !== epoch || latest.url !== tab.url || latest.pendingUrl && latest.pendingUrl !== tab.url) throw Error('document-changed');
        return latest;
      };
      const mark = async (status, reason, extra = {}) => {
        await current();
        Object.assign(record, { status, reason, checkedAt: now() }, extra);
        if (record.history.at(-1)?.reason !== reason) record.history = [...record.history, { at: now(), status, reason }].slice(-16);
        await persist();
      };
      let target = { frameId: 0 }, receipt, injected = false;
      const request = async action => {
        const requestId = `receiver:${tab.id}:${now()}:${++serial}:${action}`;
        const result = await bounded(() => browser.tabs.sendMessage(tab.id, { channel: 'session-bookmarks-refresh', action, id, requestId }, target));
        if (result?.requestId !== requestId) throw Error('invalid-receipt');
        return result;
      };
      try {
        await current();
        if (tab.discarded || tab.frozen || tab.status === 'loading') {
          await mark('suspended', 'document-not-ready', { confirmed: null, nextAttemptAt: now() + 2000 }); return;
        }
        try { receipt = await request('health'); }
        catch (error) {
          if (!missing(error)) throw error;
          await mark('unavailable', 'receiver-unavailable', { recoveryPending: true, confirmed: null });
          record.attempts++;
          // The first injection only reads identity. Chrome's documentId then pins
          // the file injection and receipts to this document, including navigation races.
          let identity;
          try {
            identity = await bounded(() => browser.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] },
              func: expectedURL => {
                if (location.href === expectedURL) globalThis.__workbenchRecoveryURL = expectedURL;
                return { url: location.href };
              }, args: [tab.url] }));
          } catch { throw Error('injection-failed'); }
          await current();
          const document = identity?.find(item => item.frameId === 0);
          if (!document?.documentId || document.result?.url !== tab.url) throw Error('document-changed');
          target = { documentId: document.documentId };
          await mark('recovering', 'injecting', { browserDocumentId: document.documentId, recoveryPending: true });
          try {
            await bounded(() => browser.scripting.executeScript({ target: { tabId: tab.id, documentIds: [document.documentId] }, files: FILES }));
          } catch { throw Error('injection-failed'); }
          await current();
          receipt = await request('health'); injected = true;
        }
        const compatible = r => r && [version, '0.4.24', '0.4.25', '0.4.26', '0.4.27'].includes(r.version) && r.url === tab.url && r.id === id &&
          typeof r.documentId === 'string' && r.documentId && Number.isSafeInteger(r.routeEpoch);
        if (!compatible(receipt)) throw Error('invalid-receipt');
        const contentDocument = receipt.documentId, routeEpoch = receipt.routeEpoch;
        record.contentVersion = receipt.version;
        if (record.documentId !== contentDocument || record.routeEpoch !== routeEpoch) record.confirmed = null;
        const saved = async () => (await repository.dispatch('load', { activeOnly: true })).state.bookmarks.find(b => b.id === id)?.replyState;
        let stored = await saved();
        const same = value => value && stored && ['author','phase','revision','messageId','userMessageId'].every(key => (value[key] ?? null) === (stored[key] ?? null));
        const invalidate = packet => {
          const evidence = packet.observed || packet.health?.observed;
          const revision = packet.storedRevision ?? packet.health?.storedRevision;
          if (evidence && revision === stored?.revision &&
              (evidence.author === 'user' || ['generating','awaiting_permission'].includes(evidence.phase)) &&
              ['author','phase','messageId','userMessageId'].some(key => (evidence[key] ?? null) !== (stored[key] ?? null))) {
            record.invalidation = { revision, observed: { ...evidence } }; record.confirmed = null;
          }
        };
        invalidate(receipt);
        const evidence = receipt.observed;
        if (evidence && ['user','assistant','tool'].includes(evidence.author) &&
          ['author','phase','messageId','userMessageId'].some(key => evidence[key] !== record.confirmed?.[key])) record.confirmed = null;
        if (record.confirmed && !same(record.confirmed)) record.confirmed = null;
        if (!injected && (receipt.pending === true || record.invalidation?.revision === stored?.revision) && !receipt.noData && !receipt.stateConflict && record.pendingSince == null) {
          record.pendingSince = now();
          await mark(record.recoveryPending ? 'recovering' : 'checking', 'read-pending', {
            documentId: contentDocument, routeEpoch, nextAttemptAt: now() + 2000 });
          return;
        }
        if (injected || (!record.confirmed && !same(receipt.replyState)) || !receipt.currentValid || !Number.isSafeInteger(receipt.lastValidReadAt) || now() - receipt.lastValidReadAt >= 180000) {
          // A routine recheck is not a receiver failure. Retain a verified state
          // only while this same document still confirms that state is current.
          const retained = !record.recoveryPending && same(record.confirmed) && record.documentId === contentDocument;
          const checkingStatus = injected || record.recoveryPending ? 'recovering' : 'checking';
          await mark(retained ? 'available' : checkingStatus, 'rescan');
          receipt = await request('rescan');
          if (!compatible(receipt) || receipt.documentId !== contentDocument || receipt.routeEpoch !== routeEpoch) throw Error('invalid-receipt');
          stored = await saved(); invalidate(receipt);
          if (!receipt?.initialized) {
            if (receipt?.pending === true && !receipt.noData && !receipt.stateConflict) {
              const observed = receipt.health?.observed;
              const unchanged = !observed || ['author','phase','messageId','userMessageId'].every(key => observed[key] === record.confirmed?.[key]);
              record.pendingSince ??= now();
              if (now() - record.pendingSince >= 30000) throw Error('unconfirmed-read');
              if (!unchanged || !same(record.confirmed)) record.confirmed = null;
              await mark(checkingStatus, 'read-pending', { documentId: contentDocument, routeEpoch, nextAttemptAt: now() + 2000 });
              return;
            }
            throw Error(receipt?.stateConflict ? 'state-conflict' : 'unconfirmed-read');
          }
        }
        await current();
        if (!compatible(receipt) || receipt.documentId !== contentDocument || receipt.routeEpoch !== routeEpoch) throw Error('document-changed');
        stored = await saved();
        const confirmed = receipt.replyState || record.confirmed;
        if (!same(confirmed)) throw Error('state-conflict');
        await mark('available', injected || record.recoveryPending ? 'recovered' : 'verified', { documentId: contentDocument, routeEpoch, confirmed: { ...confirmed }, invalidation: null, contentVersion: receipt.version, pendingSince: null,
          phase: receipt.replyState?.phase || receipt.phase || record.phase || null, nextAttemptAt: now() + 15000, attempts: 0, recoveryPending: false });
      } catch (error) {
        if (error.message === 'document-changed') { if ((epochs.get(tab.id) || 0) === epoch) await forget(tab.id); return; }
        const reason = ['injection-failed', 'receiver-timeout', 'state-conflict', 'unconfirmed-read', 'invalid-receipt'].includes(error.message) ? error.message : 'receiver-unavailable';
        try { await mark('unavailable', reason, { recoveryPending: true, confirmed: null, nextAttemptAt: now() + Math.min(60000, 2000 * 2 ** Math.min(record.attempts || 1, 5)) }); } catch { /* A closed/replaced document has no result to publish. */ }
      }
    }
    function scan(only) {
      if (running) return running;
      running = (async () => {
        await load();
        const available = await targets(), tabs = only ? available.filter(t => only.includes(t.id)) : available;
        const ids = new Set(available.map(t => t.id));
        for (const id of records.keys()) if (!ids.has(id)) records.delete(id);
        let cursor = 0;
        await Promise.all(Array.from({ length: Math.min(4, tabs.length) }, async () => { while (cursor < tabs.length) await inspect(tabs[cursor++]); }));
        await persist();
      })().finally(() => { running = null; });
      return running;
    }
    function changed(tabId) {
      pendingTabs.add(tabId);
      if (changedRunning) return changedRunning;
      changedRunning = (async () => {
        await load(); if (running) await running.catch(() => {});
        for (let pass = 0; pass < 2 && pendingTabs.size; pass++) {
          const ids = [...pendingTabs]; pendingTabs.clear();
          for (const id of ids) { const record = records.get(id); if (record) record.nextAttemptAt = 0; }
          await scan(ids);
        }
      })().finally(() => {
        changedRunning = null;
        if (pendingTabs.size) setTimeout(() => { void changed(pendingTabs.values().next().value).catch(() => {}); }, 1000);
      });
      return changedRunning;
    }
    return { scan, snapshot, forget, changed, async health(tabId) { await load(); return records.get(tabId) || null; },
      async start() { await browser.alarms?.create?.(ALARM, { delayInMinutes: 1, periodInMinutes: 1 }); await scan(); } };
  }
  const api = { KEY, ALARM, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkReceiverRecovery = api;
})(globalThis);
