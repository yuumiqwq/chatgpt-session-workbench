'use strict';
importScripts('model.js', 'repository.js', 'statistics.js', 'preferences.js', 'tab-groups.js', 'onboarding.js', 'tutorial-tabs.js', 'dots-guide.js', 'dots.js', 'codex-status.js', 'diagnostics.js', 'session-refresh.js', 'refresh-cadence.js', 'closed-watch.js', 'opened-refresh.js');
const BACKGROUND_VERSION = '0.4.22';
const repository = BookmarkRepository.createRepository(chrome.storage.local);
const refreshCadence = BookmarkRefreshCadence.createStore(chrome.storage.local);
void refreshCadence.initialize().catch(() => {});
const tutorialTabs = BookmarkTutorialTabs.createService({ browser: chrome, repository });
void tutorialTabs.releaseWindow().catch(() => {});
const activeRepository = { dispatch(action, payload, ...args) {
  return repository.dispatch(action, action === 'load' ? { ...payload, activeOnly: true } : payload, ...args);
} };
const codexStatus = BookmarkCodexStatus.createService({ browser: chrome, repository: activeRepository,
  onDisconnect() {
    void chrome.runtime.sendMessage?.({ channel: BookmarkCodexStatus.CHANNEL, action: 'disconnected' }).catch(() => {});
  }
});
// Demo rows are tutorial objects; status collectors only receive real saved destinations.
const sessionRefresh = BookmarkSessionRefresh.createService({ browser: chrome, repository: {
  async dispatch(action, ...args) {
    const result = await activeRepository.dispatch(action, ...args);
    return action === 'load' ? { ...result, state: { ...result.state, bookmarks: result.state.bookmarks.filter(b => b.kind !== 'demo') } } : result;
  }
}, codexStatus, commitDots: (tab,receipt,windowId)=>dots.commitManual(tab,receipt,windowId),
  reserveDots:(tab,ticket)=>dots.reserveSample(tab,ticket),cancelDots:id=>dots.cancelSample(id),isOtherTemporary: tab => closedWatch.isTemporary(tab) });
const closedWatch = BookmarkClosedWatch.createService({ browser: chrome, repository: activeRepository, isOtherTemporary: tab => sessionRefresh.isTemporary(tab),
  claim: refreshCadence.claim, preserveStartupDeadline: true });
void sessionRefresh.recover().then(() => closedWatch.recover()).catch(() => {});
chrome.alarms?.onAlarm.addListener(alarm => {
  if (alarm.name === BookmarkClosedWatch.ALARM) void closedWatch.tick().catch(() => {});
  if (alarm.name === BookmarkOpenedRefresh.ALARM) void closedWatch.withManualRun(() => openedRefresh.tick()).catch(() => {});
});
chrome.storage.onChanged?.addListener((changes, area) => {
  if (area === 'local' && changes.sessionBookmarks) void closedWatch.reconcile().catch(() => {});
});
chrome.tabs.onCreated?.addListener(tab => { void closedWatch.tabSeen(tab).catch(() => {}); });
const statistics = BookmarkStatistics.createRepository(chrome.storage.local);
const tabGroups = BookmarkTabGroups.createManager(chrome);
const openedRefresh = BookmarkOpenedRefresh.createService({ browser: chrome, repository: activeRepository,
  isTemporary: tab => sessionRefresh.isTemporary(tab) || closedWatch.isTemporary(tab), claim: refreshCadence.claim });
void openedRefresh.recover().catch(() => {});
const dotsGuide = BookmarkDotsGuide.createService(chrome.storage.local, { hasPanel: windowId => hasVisiblePanel(windowId) });
const dots = BookmarkDots.createService({ browser: chrome, repository: activeRepository,
  groupCreated: (id, url) => tabGroups.groupCreatedTab(id, url) });
const unreadTickets = new Map();
// Only live, authenticated panel ports can supply a quick-save destination.
const panels = new Map();
// Track every live document separately; a connected side panel can be hidden.
const panelVisibility = new Map();
const hasVisiblePanel = windowId => [...panelVisibility.values()].some(p => p.windowId === windowId && p.visible);
const onboarding = BookmarkOnboarding.createStore(chrome.storage.local, {
  hasPanel: hasVisiblePanel, getTab: id => chrome.tabs.get(id)
});
async function notifyTutorial(windowId) {
  try {
    const owner = await onboarding.ownerWindow();
    if (owner === null || windowId !== undefined && owner !== windowId) return;
    const tabs = await chrome.tabs.query({ active: true, windowId: owner });
    const tab = tabs.find(t => t.active && t.windowId === owner);
    if (!tab || BookmarkModel.normalizeURL(tab.pendingUrl || tab.url).kind !== 'chatgpt') return;
    await chrome.tabs.sendMessage(tab.id, { channel: BookmarkOnboarding.CHANNEL, action: 'hint-probe' });
  } catch { /* A page without a content script has no prompt to update. */ }
}
let panelSequence = 0;
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'session-bookmarks-panel' || port.sender?.id !== chrome.runtime.id ||
      port.sender.url !== chrome.runtime.getURL('panel.html')) return;
  const order = ++panelSequence;
  let windowId;
  let disconnected = false;
  port.onMessage.addListener(message => {
    if (disconnected || !Number.isInteger(message?.windowId) || message.windowId < 0 ||
        (windowId !== undefined && windowId !== message.windowId)) return;
    windowId = message.windowId;
    const previous = panelVisibility.get(port);
    const visible = message.visible === true;
    panelVisibility.set(port, { windowId, visible });
    if (!previous || previous.visible !== visible) void notifyTutorial(windowId);
    if (!previous) {
      try { port.postMessage?.({ channel: 'session-bookmarks-panel', action: 'ready', windowId }); }
      catch { /* A disconnected document will register again through its replacement port. */ }
    }
    if ((panels.get(windowId)?.order ?? 0) > order) return;
    const categoryId = typeof message.categoryId === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(message.categoryId) &&
      !['all', 'unfiled'].includes(message.categoryId) ? message.categoryId : null;
    panels.set(windowId, { port, categoryId, order });
  });
  port.onDisconnect.addListener(() => {
    disconnected = true;
    panelVisibility.delete(port);
    if (windowId !== undefined && ![...panelVisibility.values()].some(panel => panel.windowId === windowId)) void tutorialTabs.releaseWindow(windowId).catch(() => {});
    if (windowId !== undefined) void notifyTutorial(windowId);
    // An old document disconnecting after a refresh must not remove its replacement.
    if (panels.get(windowId)?.port === port) panels.delete(windowId);
  });
});
async function configurePanel() {
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); }
  catch (error) { console.error('侧栏初始化失败', error); }
}
chrome.runtime.onInstalled.addListener(async details => {
  await refreshCadence.defer();
  await configurePanel(); await repository.initialize(details?.reason); await onboarding.initialize(details?.reason);
  await openedRefresh.recover().catch(() => {});
  // Installation/update defers old pending jobs by a full cadence; it never catches up with a burst.
  await closedWatch.startup('install').catch(() => {});
});
chrome.runtime.onStartup.addListener(async () => {
  await refreshCadence.defer();
  const catchup = closedWatch.startup();
  await openedRefresh.recover().catch(() => {});
  await configurePanel(); await catchup;
});
configurePanel();
chrome.tabs.onActivated?.addListener(info => {
  void dots.activateTab(info.tabId, info.windowId).catch(() => {});
  void closedWatch.tabActivated(info.tabId).catch(() => {});
  if (closedWatch.ownsWindow(info.windowId)) return;
  void notifyTutorial(info.windowId);
});
chrome.tabs.onUpdated?.addListener((id, changes, tab) => {
  if (changes.url || changes.status === 'loading') {
    void openedRefresh.forgetTab(id).catch(()=>{});
    if (unreadTickets.has(id)) unreadTickets.set(id, unreadTickets.get(id) + 1);
    void dots.forgetTab(id).catch(() => {});
  }
  if (changes.url || changes.status === 'loading' || changes.status === 'complete') void closedWatch.tabSeen(tab).catch(() => {});
  if (closedWatch.isTemporary(tab)) return;
  if (tab?.active && (changes.url || changes.status === 'complete')) void notifyTutorial(tab.windowId);
});
chrome.tabs.onRemoved?.addListener((id, info) => {
  void openedRefresh.forgetTab(id).catch(()=>{});
  unreadTickets.delete(id); void dots.forgetTab(id).catch(() => {});
  void closedWatch.tabRemoved(id).catch(() => {});
});
chrome.tabs.onDetached?.addListener(id => {
  void openedRefresh.forgetTab(id).catch(()=>{});
  void closedWatch.adopt(id, 'tab-moved').catch(()=>{});
  if (unreadTickets.has(id)) unreadTickets.set(id, unreadTickets.get(id) + 1);
  void dots.detachTab(id).catch(() => {});
});
chrome.tabs.onAttached?.addListener(id => {
  void openedRefresh.forgetTab(id).catch(()=>{});
  if (unreadTickets.has(id)) unreadTickets.set(id, unreadTickets.get(id) + 1);
  void dots.attachTab(id).catch(() => {});
});
chrome.windows?.onCreated?.addListener(window => { void closedWatch.windowCreated(window).catch(() => {}); });
chrome.windows?.onBoundsChanged?.addListener(window => { void closedWatch.windowChanged(window).catch(() => {}); });
chrome.windows?.onRemoved?.addListener(windowId => {
  void dots.forgetWindow(windowId).catch(()=>{});
  void closedWatch.windowRemoved(windowId).catch(() => {});
});
chrome.windows?.onFocusChanged?.addListener(windowId => {
  if (windowId < 0) return;
  void closedWatch.windowChanged({ id: windowId }, true).catch(() => {});
  if (!closedWatch.ownsWindow(windowId)) void notifyTutorial(windowId);
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (message?.channel === BookmarkSessionRefresh.CHANNEL && message.action === 'claim') {
    if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) ||
        !(BookmarkSessionRefresh.pageId(sender.url)||/^https:\/\/chatgpt\.com\/(?:#workbench-refresh-[a-z0-9-]+)?$/.test(sender.url||''))) return false;
    Promise.all([sessionRefresh.adopt(sender.tab.id), closedWatch.adopt(sender.tab.id)])
      .then(results => {
        const adopted = results.some(Boolean);
        if (adopted) void chrome.tabs.get(sender.tab.id).then(tab => closedWatch.tabSeen(tab)).catch(() => {});
        respond({ adopted });
      }, () => respond({ adopted: false }));
    return true;
  }
  if (message?.channel === BookmarkDots.CHANNEL) {
    // Retired account/plan invalidations never start a probe.
    return false;
  }
  if (message?.channel === BookmarkDots.UNREAD_CHANNEL) {
    if (message.action !== 'observe' || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) ||
        sender.documentLifecycle && sender.documentLifecycle !== 'active' ||
        !(message.unread === null || Number.isSafeInteger(message.unread) && message.unread >= 0)) return false;
    const page = value => { try { const u = new URL(value); return u.origin === 'https://chatgpt.com' && !u.pathname.startsWith('/settings') && !u.username && !u.password; } catch { return false; } };
    if (!page(sender.url) || sender.url !== message.documentURL || sender.tab.url !== sender.url) return false;
    const ticket = (unreadTickets.get(sender.tab.id) || 0) + 1; unreadTickets.set(sender.tab.id, ticket);
    void chrome.tabs.get(sender.tab.id).then(tab => {
      if (unreadTickets.get(tab.id) !== ticket || (tab.pendingUrl || tab.url) !== sender.url) return false;
      return dots.observeUnread(tab, message.unread, () => unreadTickets.get(tab.id) === ticket,
        {sampledAt:message.sampledAt,requestId:typeof message.requestId==='string'?message.requestId:null,
          documentId:typeof message.documentId==='string'?message.documentId:null});
    }).then(accepted => respond({ accepted: accepted === true }), () => respond({ accepted: false }));
    return true;
  }
  if (message?.channel === BookmarkOnboarding.CHANNEL) {
    if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !Number.isInteger(sender.tab.windowId) ||
        !['hint-claim', 'hint-status', 'hint-shown', 'hint-dismiss', 'hint-return'].includes(message.action)) return false;
    let link;
    try {
      link = BookmarkModel.normalizeURL(sender.url);
      if (link.kind !== 'chatgpt' || BookmarkModel.normalizeURL(sender.tab.url).id !== link.id ||
          BookmarkModel.normalizeURL(message.url).id !== link.id) return false;
    } catch { return false; }
    // Start opening during the click's message dispatch so Chrome retains the user gesture.
    const opening = message.action === 'hint-return' && !hasVisiblePanel(sender.tab.windowId) ?
      chrome.sidePanel.open({ windowId: sender.tab.windowId }) : Promise.resolve();
    opening.then(() => onboarding.dispatch(message.action, { token: message.token, runId: message.runId, step: message.step },
      { tabId: sender.tab.id, windowId: sender.tab.windowId, id: link.id }))
      .then(result => respond({ ok: true, ...result }), () => respond({ ok: false, error: '返回侧栏失败，请重试。' }));
    return true;
  }
  if (message?.channel === 'session-bookmarks-statistics') {
    if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !['stats-start', 'stats-record'].includes(message.action)) return false;
    const chatOrigin = value => {
      try { const url = new URL(value); return url.origin === 'https://chatgpt.com' && !url.username && !url.password; }
      catch { return false; }
    };
    if (!chatOrigin(sender.url) || !chatOrigin(sender.tab.url)) return false;
    (async () => {
      const tab = await chrome.tabs.get(sender.tab.id);
      if (!chatOrigin(tab.pendingUrl || tab.url)) throw Error();
      if (message.action === 'stats-start') return statistics.dispatch('stats-start', { startedAt: message.startedAt });
      const event = message.event || {};
      if (Object.keys(event).some(key => !['transactionId', 'messageId', 'sentAt', 'characters'].includes(key))) throw Error();
      return statistics.dispatch('stats-record', { transactionId: event.transactionId, messageId: event.messageId,
        sentAt: event.sentAt, characters: event.characters });
    })().then(result => respond({ ok: true, ...result }), () => respond({ ok: false }));
    return true;
  }
  if (message?.channel === 'session-bookmarks-reply') {
    if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) ||
        !['reply-check', 'reply-observe'].includes(message.action)) return false;
    let link;
    try {
      link = BookmarkModel.normalizeURL(sender.url);
      if (link.kind !== 'chatgpt' || BookmarkModel.normalizeURL(sender.tab.url).id !== link.id || message.id !== link.id) return false;
    } catch { return false; }
    // Resolve the live tab too: sender.tab can describe the page before a pending SPA/navigation update.
    (async () => {
      const p = message.observation || {};
      let authorized = false;
      const authorizeReply = async () => {
        let tab;
        try { tab = await chrome.tabs.get(sender.tab.id); }
        catch (error) {
          // Only a generating write already validated against this live document may finish after onRemoved.
          if (authorized && message.action === 'reply-observe' && BookmarkClosedWatch.generating(p) &&
              closedWatch.wasRemoved(sender.tab.id, link.id)) return;
          throw error;
        }
        if (BookmarkModel.normalizeURL(tab.pendingUrl || tab.url).id !== link.id) throw new Error();
        await closedWatch.authorizeObservation(tab.id, link.id);
        authorized = true;
      };
      await authorizeReply();
      if (message.action === 'reply-observe' && (!Number.isSafeInteger(p.observedAt) || p.observedAt > Date.now() + 1000)) throw new Error();
      const result = await repository.dispatch(message.action, { id: link.id, author: p.author, phase: p.phase,
        messageId: p.messageId, userMessageId: p.userMessageId, userMessageIds: p.userMessageIds,
        precedingMessageIds: p.precedingMessageIds,
        completedTurn: p.completedTurn && { route: p.completedTurn.route, turnId: p.completedTurn.turnId },
        activeTurn: p.activeTurn && { route: p.activeTurn.route, turnId: p.activeTurn.turnId },
        observedAt: p.observedAt, baseRevision: p.baseRevision, permissionCleared: p.permissionCleared === true,
        initialBaseline: p.initialBaseline && { author: p.initialBaseline.author, phase: p.initialBaseline.phase,
          messageId: p.initialBaseline.messageId, userMessageId: p.initialBaseline.userMessageId, revision: p.initialBaseline.revision },
        prior: p.prior && { author: p.prior.author, phase: p.prior.phase, messageId: p.prior.messageId,
          userMessageId: p.prior.userMessageId, revision: p.prior.revision } }, undefined, authorizeReply);
      if (message.action === 'reply-observe') void closedWatch.observed(sender.tab.id, link.id, result).catch(() => {});
      return result;
    })().then(result => respond({ ok: true, ...result }), () => respond({ ok: false }));
    return true;
  }
  if (message?.channel === 'session-bookmarks-quick') {
    if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !Number.isInteger(sender.tab?.windowId) || !['quick-check', 'quick-add'].includes(message.action)) return false;
    let link;
    try {
      if (new URL(sender.url).origin !== 'https://chatgpt.com' || new URL(sender.tab.url).origin !== 'https://chatgpt.com') return false;
      link = BookmarkModel.normalizeURL(message.url);
      if (link.kind !== 'chatgpt') return false;
    } catch { return false; }
    (async () => {
      const authorize = async () => {
        const tab = await chrome.tabs.get(sender.tab.id);
        let same = false;
        try { same = tab.windowId === sender.tab.windowId && BookmarkModel.normalizeURL(tab.pendingUrl || tab.url).id === link.id; } catch {}
        if (!same) throw Object.assign(Error('当前页面已切换，请在当前会话重试'), { code: 'QUICK_ROUTE_CHANGED' });
        return tab;
      };
      const tab = await authorize();
      const title = typeof tab.title === 'string' ? tab.title.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 200) : '';
      const panel = panels.get(tab.windowId);
      const categoryId = panel && panelVisibility.get(panel.port)?.visible ? panel.categoryId : null;
      return repository.dispatch(message.action, { url: link.url, title: title || 'ChatGPT', categoryId }, undefined, authorize);
    })().then(result => respond({ ok: true, bookmarked: result.bookmarked }),
      error => respond({ ok: false, code: error.code || 'QUICK_STORAGE_FAILED', error: error.message || '收藏读取或保存失败，请在侧栏检查' }));
    return true;
  }
  if (sender.url !== chrome.runtime.getURL('panel.html') || message?.channel !== 'session-bookmarks') return false;
  if (message.action === 'refresh-sessions') {
    const windowId = message.payload?.windowId;
    const matchesPanel = [...panelVisibility.entries()].some(([port, panel]) => panel.windowId === windowId &&
      (!sender.documentId || port.sender.documentId === sender.documentId));
    if (!matchesPanel || sender.tab && sender.tab.windowId !== windowId) return false;
    openedRefresh.withManualRun(() => closedWatch.withManualRun(() => sessionRefresh.run(message.payload))).then(async result => {
      let tracking;
      try { tracking = await closedWatch.continueAfterManual(result); }
      catch { tracking = { scheduled: 0, warning: '后台复查安排失败' }; }
      respond({ ok: true, ...result, tracking });
      void chrome.runtime.sendMessage?.({ channel: BookmarkCodexStatus.CHANNEL, action: 'refreshed' }).catch(() => {});
    },
      () => respond({ ok: false, error: '刷新失败，请重试。' }));
    return true;
  }
  if (message.action === 'collect-diagnostics') {
    BookmarkDiagnostics.collect({ browser: chrome, repository, codexStatus, model: BookmarkModel, backgroundVersion: BACKGROUND_VERSION,
      collectionHealth:id=>openedRefresh.health(id),
      targetId: message.payload?.targetId, windowId: message.payload?.windowId }).then(
      diagnostic => respond({ ok: true, diagnostic }), () => respond({ ok: false, error: '状态诊断读取失败。' }));
    return true;
  }
  if (message.action === 'codex-status') {
    codexStatus.read().then(snapshot => respond({ ok: true, snapshot }), () => respond({ ok: true, snapshot: BookmarkCodexStatus.emptySnapshot() }));
    return true;
  }
  if (['dots-get', 'dots-add', 'dots-open', 'dots-pro-get', 'dots-pro-set'].includes(message.action)) {
    const windowId = message.payload?.windowId;
    const matchesPanel = [...panelVisibility.entries()].some(([port, panel]) => panel.windowId === windowId &&
      (!sender.documentId || port.sender.documentId === sender.documentId));
    if (!matchesPanel || sender.tab && sender.tab.windowId !== windowId) return false;
    const operation = async () => {
      // Reserve for the explicit opt-in window before the preference storage event reaches other panels.
      let guide;
      if (message.action === 'dots-pro-set' && message.payload.enabled === true && hasVisiblePanel(windowId))
        guide = await dotsGuide.claim(windowId, true).catch(() => ({ show: false }));
      try {
        const result = await dots.dispatch(message.action, message.payload);
        if (message.action === 'dots-pro-set' && message.payload.enabled === false) await dotsGuide.release();
        if (message.action === 'dots-get' && result.snapshot?.eligible && hasVisiblePanel(windowId))
          guide = await dotsGuide.claim(windowId, true).catch(() => ({ show: false }));
        return { ...result, ...(guide ? { guide } : {}) };
      } catch (error) {
        if (guide?.show) await dotsGuide.release(windowId, guide.token).catch(() => {});
        throw error;
      }
    };
    operation().then(result => respond({ ok: true, ...result }),
      error => respond({ ok: false, error: error.message }));
    return true;
  }
  if (message.action === 'dots-guide-shown') {
    const windowId = message.payload?.windowId;
    const matchesPanel = [...panelVisibility.entries()].some(([port, panel]) => panel.windowId === windowId &&
      (!sender.documentId || port.sender.documentId === sender.documentId));
    if (!matchesPanel || sender.tab && sender.tab.windowId !== windowId) return false;
    const acknowledge = async () => {
      if (!hasVisiblePanel(windowId)) return { shown: false };
      if (typeof message.payload?.runId === 'string') return await onboarding.dotsPresented(windowId, message.payload.runId) ?
        dotsGuide.shownInTour() : { shown: false };
      return dotsGuide.shown(windowId, message.payload?.token);
    };
    acknowledge().then(result => respond({ ok: true, ...result }),
      () => respond({ ok: false, error: 'Dots 教程状态保存失败。' }));
    return true;
  }
  if (typeof message.action === 'string' && message.action.startsWith('tutorial-')) {
    const windowId = message.payload?.windowId;
    // Bind requests to a live panel document when Chrome provides documentId.
    const matchesPanel = [...panelVisibility.entries()].some(([port, panel]) => panel.windowId === windowId &&
      (!sender.documentId || port.sender.documentId === sender.documentId));
    if (!matchesPanel || sender.tab && sender.tab.windowId !== windowId) return false;
    const operation = async () => {
      if (message.action === 'tutorial-geometry') {
        const [tab] = await chrome.tabs.query({ active: true, windowId });
        if (!tab?.active || tab.windowId !== windowId || tab.pendingUrl && tab.pendingUrl !== tab.url) return { geometry: null };
        try { if (BookmarkModel.normalizeURL(tab.url).kind !== 'chatgpt') return { geometry: null }; } catch { return { geometry: null }; }
        const response = await chrome.tabs.sendMessage(tab.id, { channel: BookmarkOnboarding.CHANNEL, action: 'quick-geometry' }, { frameId: 0 });
        const [current] = await chrome.tabs.query({ active: true, windowId });
        if (current?.id !== tab.id || current.windowId !== windowId || !current.active || current.url !== tab.url ||
            current.pendingUrl && current.pendingUrl !== current.url) return { geometry: null };
        const geometry = response?.geometry;
        return { geometry: geometry && [geometry.centerY, geometry.innerHeight, geometry.devicePixelRatio].every(Number.isFinite) &&
          geometry.innerHeight > 0 && geometry.devicePixelRatio > 0 && geometry.centerY >= 0 && geometry.centerY <= geometry.innerHeight ?
          { centerY: geometry.centerY, innerHeight: geometry.innerHeight, devicePixelRatio: geometry.devicePixelRatio } : null };
      }
      if (message.action !== 'tutorial-handoff') return onboarding.dispatch(message.action, message.payload);
      const tabs = await chrome.tabs.query({ active: true, windowId });
      const tab = tabs.find(t => t.active && t.windowId === windowId);
      if (!tab) throw Error('请先打开 ChatGPT 会话页。');
      const ready = await chrome.tabs.sendMessage(tab.id, { channel: BookmarkOnboarding.CHANNEL, action: 'hint-ready' });
      if (!ready?.ready) throw Error('当前网页没有可用的悬浮球。');
      return onboarding.dispatch(message.action, { ...message.payload, tabId: tab.id });
    };
    operation().then(async result => {
      if (message.action === 'tutorial-geometry') return result;
      const current = await onboarding.dispatch('tutorial-open', { windowId });
      const visible = await tutorialTabs.sync(current, windowId);
      return result.handoff ? result : visible;
    }).then(result => {
      respond({ ok: true, ...result }); if (message.action !== 'tutorial-geometry') void notifyTutorial(windowId);
      if (result.handoff && chrome.sidePanel.close) void chrome.sidePanel.close({ windowId }).catch(() => {});
    }, error => respond({ ok: false, error: error.message || '教程读取或保存失败。' }));
    return true;
  }
  if (['auto-group-get', 'auto-group-set', 'group-created-tab'].includes(message.action)) {
    const operation = message.action === 'auto-group-get' ? tabGroups.getEnabled().then(enabled => ({ enabled })) :
      message.action === 'auto-group-set' ? tabGroups.setEnabled(message.payload?.enabled).then(() => ({ enabled: message.payload.enabled })) :
      tabGroups.groupCreatedTab(message.payload?.tabId, message.payload?.createdURL);
    operation.then(result => respond({ ok: true, ...result }), () => respond({ ok: false,
      error: message.action === 'group-created-tab' ? '页面已打开，自动分组失败。' : '自动分组选项保存或读取失败。' }));
    return true;
  }
  if (message.action === 'stats-today') {
    statistics.dispatch('stats-today').then(result => respond({ ok: true, ...result }), () => respond({ ok: false, error: '统计读取失败。' }));
    return true;
  }
  if (['reply-check', 'reply-observe', 'stats-start', 'stats-record'].includes(message.action)) return false;
  repository.dispatch(message.action, message.payload).then(
    result => respond({ ok: true, ...result }),
    error => respond({ ok: false, error: error.message })
  );
  return true;
});
