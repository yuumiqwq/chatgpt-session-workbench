(function(root){
  'use strict';
  const M=typeof module!=='undefined'&&module.exports?require('./model.js'):root.BookmarkModel;
  const ALARM='session-bookmarks-open-refresh',KEY='sessionBookmarksOpenRefresh',INTERVAL=180000;
  const HEALTH_KEY='sessionBookmarksCollectionHealth';
  const pending=b=>b.kind==='chatgpt'&&['assistant','tool'].includes(b.replyState?.author)&&['generating','awaiting_permission'].includes(b.replyState.phase);
  function pageId(url){try{const link=M.normalizeURL(url);return link.kind==='chatgpt'?link.id:null;}catch{return null;}}
  function createService({browser,repository,isTemporary=()=>false,now=Date.now,timeoutMs=1500,claim=async()=>({allowed:true})}){
    let running=null,paused=0,recovering=null;
    let healthRecords=null,loadingHealth=null,savingHealth=Promise.resolve();
    const generations=new Map();
    const unverifiedRestores=new Set();
    async function loadHealth(){if(healthRecords)return healthRecords;if(!loadingHealth)loadingHealth=(async()=>{
      const raw=(await browser.storage.session?.get?.(HEALTH_KEY))?.[HEALTH_KEY];
      return healthRecords=new Map((Array.isArray(raw)?raw:[]).filter(r=>Number.isInteger(r.tabId)&&pageId(r.url)===r.id).slice(-128).map(r=>{
        unverifiedRestores.add(r.tabId);
        const times=Object.fromEntries(['lastAttemptAt','lastRespondedAt','lastValidReadAt','failureSince'].map(k=>[k,Number.isSafeInteger(r[k])&&r[k]>=0&&r[k]<=now()?r[k]:null]));
        return [r.tabId,{...r,...times,currentValid:false}];
      }));
    })().finally(()=>{loadingHealth=null;});return loadingHealth;}
    function saveHealth(){const work=savingHealth.then(async()=>browser.storage.session?.set?.({[HEALTH_KEY]:[...(await loadHealth()).values()].slice(-128)}));savingHealth=work.catch(()=>{});return work;}
    async function forgetTab(id){generations.set(id,(generations.get(id)||0)+1);if((await loadHealth()).delete(id))await saveHealth();}
    async function health(id){const record=(await loadHealth()).get(id);if(!record)return null;
      const age=Number.isSafeInteger(record.lastValidReadAt)?now()-record.lastValidReadAt:null;
      return {...record,validAgeMs:age!==null&&age>=0?age:null,failureAgeMs:Number.isSafeInteger(record.failureSince)&&record.failureSince<=now()?now()-record.failureSince:null,
        decision:record.pending?'pending':record.currentValid===true&&age!==null&&age>=0&&age<INTERVAL?'fresh':record.failureSince!=null?'failing':'unknown'};}
    const missingReceiver=error=>/receiving end does not exist|could not establish connection|no tab with id/i.test(error?.message||'');
    async function pendingIds(){const {state}=await repository.dispatch('load',{activeOnly:true});return new Set(state.bookmarks.filter(pending).map(b=>pageId(b.url)).filter(Boolean));}
    function recover(){
      if(recovering)return recovering;
      recovering=(async()=>{
        if(!browser.alarms?.get||!browser.alarms?.create)return false;
        if((await browser.alarms.get(ALARM))?.periodInMinutes!==3)await browser.alarms.create(ALARM,{delayInMinutes:3,periodInMinutes:3});
        return true;
      })().finally(()=>{recovering=null;});return recovering;
    }
    async function bounded(work){let timer;try{return await Promise.race([Promise.resolve().then(work),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('timeout')),timeoutMs);})]);}finally{clearTimeout(timer);}}
    async function cycle(){
      if(paused)return {skipped:true,reason:'manual-refresh-running'};
      const report={schema:2,startedAt:now(),refreshed:0,foreground:0,skipped:0,failed:0,items:[]};
      const protectedTabs=new Set(),changedTabs=new Set();
      let focusChanged=false;
      const activated=info=>protectedTabs.add(info.tabId),focused=()=>{focusChanged=true;};
      const changed=id=>changedTabs.add(id),updated=(id,change)=>{if(change.url||change.status==='loading')changed(id);};
      const listeners=[[browser.tabs.onActivated,activated],[browser.windows?.onFocusChanged,focused],
        [browser.tabs.onUpdated,updated],[browser.tabs.onRemoved,changed],[browser.tabs.onDetached,changed],[browser.tabs.onAttached,changed]];
      // Observe interaction before any storage/query wait, including a switch away
      // and back while the first tab snapshot is still in flight.
      for(const [event,listener] of listeners)event?.addListener(listener);
      try{
      const previous=(await browser.storage.local.get?.(KEY))?.[KEY];
      report.lastNavigation=previous?.lastNavigation||null;
      const records=await loadHealth();
      const ids=await pendingIds(),tabs=await browser.tabs.query({});
      const candidates=[...new Map(tabs.filter(t=>Number.isInteger(t.id)&&!isTemporary(t)&&ids.has(pageId(t.url))).map(t=>[pageId(t.url),t])).values()];
      const record=(tab,result,reason,phase,extra)=>{report[result]++;if(report.items.length<30)report.items.push({id:pageId(tab.url),tabId:tab.id,at:now(),result,reason,...extra,...(phase?{phase}:{})});};
      let cursor=0;
      async function one(candidate){
        const id=pageId(candidate.url);
        const generation=generations.get(candidate.id)||0;
        const isCurrent=()=>generation===(generations.get(candidate.id)||0);
        const interrupted=()=>!isCurrent()||changedTabs.has(candidate.id)?'document-changed':paused?'manual-refresh-running':
          protectedTabs.has(candidate.id)?'foreground':focusChanged?'window-interaction':null;
        let action='none',protection=null;
        const finish=(result,reason,phase)=>record(candidate,result,reason,phase,{action,guard:protection});
        let claimed=false;
        let status=records.get(candidate.id);
        if(!status||status.id!==id||status.url!==candidate.url)status={tabId:candidate.id,id,url:candidate.url,documentId:null,routeEpoch:null,
          lastAttemptAt:null,lastRespondedAt:null,lastValidReadAt:null,failureSince:null,lastFailureReason:null,currentValid:false};
        function identity(receipt){
          if(!isCurrent()||receipt?.id!==id||pageId(receipt.url)!==id)return false;
          if(receipt.documentId&&Number.isSafeInteger(receipt.routeEpoch)){
            unverifiedRestores.delete(candidate.id);
            if(status.documentId!==receipt.documentId||status.routeEpoch!==receipt.routeEpoch){
              Object.assign(status,{documentId:receipt.documentId,routeEpoch:receipt.routeEpoch,lastValidReadAt:null,failureSince:null,lastFailureReason:null,currentValid:false});
            }
            return true;
          }
          return false;
        }
        function failure(reason){
          if(unverifiedRestores.delete(candidate.id))status.failureSince=null;
          status.currentValid=false;status.pending=false;status.lastFailureReason=reason;
          if(!Number.isSafeInteger(status.failureSince)||status.failureSince>now())status.failureSince=now();
          return now()-status.failureSince>=INTERVAL;
        }
        function valid(at){Object.assign(status,{currentValid:true,pending:false,lastValidReadAt:at,failureSince:null,lastFailureReason:null});}
        function historicalValid(receipt){
          const at=receipt?.lastValidReadAt;
          if(!Number.isSafeInteger(at)||at<0||at>now()||Number.isFinite(receipt.documentStartedAt)&&at<receipt.documentStartedAt)return;
          if(status.lastValidReadAt===null||at>status.lastValidReadAt)status.lastValidReadAt=at;
          // A confirmed recovery separates failure intervals even if this page has
          // since become unreadable again. Historical validity never grants reuse.
          if(status.failureSince!==null&&at>status.failureSince){status.failureSince=null;status.lastFailureReason=null;}
        }
        const current=async()=>{
          let tab,window;
          const result=skip=>{
            protection={at:now(),active:typeof tab?.active==='boolean'?tab.active:null,
              windowFocused:typeof window?.focused==='boolean'?window.focused:null,windowId:tab?.windowId??candidate.windowId,
              decision:skip||'background',interaction:interrupted()!==null};
            return {tab,skip};
          };
          try{
            tab=await bounded(()=>browser.tabs.get(candidate.id));
            if(interrupted())return result(interrupted());
            if(tab.active===true)return result('foreground');
            window=await bounded(()=>browser.windows?.get?browser.windows.get(tab.windowId):null);
            tab=await bounded(()=>browser.tabs.get(candidate.id));
            if(interrupted())return result(interrupted());
            if(tab.active===true)return result('foreground');
            if(tab.active!==false||typeof window?.focused!=='boolean')return result('guard-unavailable');
            if(tab.windowId!==candidate.windowId||tab.url!==candidate.url||tab.pendingUrl&&tab.pendingUrl!==candidate.url||
              pageId(tab.url)!==id||isTemporary(tab)||tab.discarded||tab.frozen||tab.status==='loading')return result('not-readable');
            return result(null);
          }catch{return result('guard-unavailable');}
        };
        const recoverReceiver=async allowMissing=>{
          const generating=async()=>{const {state}=await repository.dispatch('load',{activeOnly:true});return state.bookmarks.some(b=>b.id===id&&pending(b)&&b.replyState.phase==='generating');};
          if(!claimed||!await generating())return false;
          let safe=false;
          try{const p=await bounded(()=>browser.tabs.sendMessage(candidate.id,{channel:'session-bookmarks-refresh',action:'version',id},{frameId:0}));safe=p?.safeToReload===true&&pageId(p.url)===id;}
          catch(error){safe=allowMissing&&missingReceiver(error);}
          if(!safe||!await generating())return false;
          const reason=allowMissing?'receiver-reload-requested':'unverified-reload-requested';
          // Persist intent first. Any interaction during this write is included in
          // the final guard; a pending intent is not evidence of a reload request.
          report.recovery={id,tabId:candidate.id,at:now(),action:'reload-pending',reason};
          await browser.storage.local.set({[KEY]:report});
          const checked=await current();
          const invoked=await bounded(()=>{
            const skip=interrupted()||checked.skip;
            if(skip){
              action='reload-blocked';protection={...protection,at:now(),decision:skip,interaction:interrupted()!==null};
              report.recovery={id,tabId:candidate.id,at:now(),action,reason:skip,guard:protection};
              finish(skip==='foreground'?'foreground':'skipped',skip);return false;
            }
            // No promise continuation between the interaction latch and the API call.
            action='reload-requested';
            report.lastNavigation=report.recovery={id,tabId:candidate.id,at:now(),action,reason,guard:protection};
            return Promise.resolve(browser.tabs.reload(candidate.id)).then(()=>true);
          });
          if(invoked)finish('skipped',reason);return true;
        };
        try{
          let checked=await current();
          if(checked.skip){finish(checked.skip==='foreground'?'foreground':'skipped',checked.skip);return;}
          if(!(await pendingIds()).has(id)){finish('skipped','no-longer-pending');return;}
          if(!isCurrent()){finish('skipped','document-changed');return;}
          records.set(candidate.id,status);
          status.lastAttemptAt=now();
          let cached;
          try{
            const requestId=`health:${now()}:${candidate.id}:${Math.random().toString(36).slice(2)}`;
            action='health';cached=await bounded(()=>browser.tabs.sendMessage(candidate.id,{channel:'session-bookmarks-refresh',action:'health',id,requestId},{frameId:0}));
            status.lastRespondedAt=now();
            const after=await current();
            if(after.skip){finish(after.skip==='foreground'?'foreground':'skipped',after.skip);return;}
            if(cached?.requestId!==requestId||cached.version!==browser.runtime?.getManifest?.().version||!identity(cached))cached=null;
            if(cached)historicalValid(cached);
            if(cached?.currentValid===true&&
              Number.isSafeInteger(cached.lastValidReadAt)&&now()-cached.lastValidReadAt>=0&&now()-cached.lastValidReadAt<INTERVAL){
              valid(cached.lastValidReadAt);finish('skipped','recent-valid');return;
            }
            status.currentValid=false;
          }catch{/* A missing health endpoint on a legacy document still gets its reliable rescan. */}
          const budget=await claim(id,'opened');
          if(!budget.allowed){finish('skipped','cadence');return;}
          claimed=true;
          // Recheck after asynchronous storage/window reads immediately before messaging.
          checked=await current();
          if(checked.skip){finish(checked.skip==='foreground'?'foreground':'skipped',checked.skip);return;}
          const sentAt=now(),requestId=`auto:${sentAt}:${candidate.id}:${Math.random().toString(36).slice(2)}`;
          action='rescan';const receipt=await bounded(()=>browser.tabs.sendMessage(candidate.id,{channel:'session-bookmarks-refresh',action:'rescan',id,requestId},{frameId:0}));
          status.lastRespondedAt=now();
          const after=await bounded(()=>browser.tabs.get(candidate.id));
          const matches=isCurrent()&&receipt?.id===id&&pageId(receipt.url)===id&&pageId(after.pendingUrl||after.url)===id&&after.windowId===candidate.windowId&&after.status!=='loading'&&
            receipt.requestId===requestId&&
            (receipt.version===browser.runtime?.getManifest?.().version||/^0\.4\.(?:1[4-9]|2[01])$/.test(receipt.version||''));
          if(!matches){failure('invalid-receipt');finish('skipped','invalid-receipt');return;}
          const sameDocument=!cached?.documentId||receipt.documentId===cached.documentId&&receipt.routeEpoch===cached.routeEpoch;
          if(!sameDocument){failure('document-changed');finish('skipped','document-changed');return;}
          const identified=identity(receipt);
          if(receipt.pending===true&&identified){
            Object.assign(status,{currentValid:false,pending:true,failureSince:null,lastFailureReason:null});
            finish('skipped','confirmation-pending');return;
          }
          if(!Number.isSafeInteger(receipt.sampledAt)||receipt.sampledAt<sentAt||receipt.sampledAt>now()){
            failure('invalid-receipt');finish('skipped','invalid-receipt');return;
          }
          const loaded=await repository.dispatch('load',{activeOnly:true}),saved=loaded.state.bookmarks.find(b=>b.id===id)?.replyState;
          if(!isCurrent()){finish('skipped','document-changed');return;}
          const verified=receipt.initialized===true&&receipt.storedRevision===saved?.revision&&receipt.replyState?.revision===saved?.revision&&
            ['author','phase','messageId','userMessageId'].every(k=>(receipt.replyState?.[k]??null)===(saved?.[k]??null))&&saved?.phase!=='unknown';
          if(verified){valid(receipt.sampledAt);finish('refreshed','rescanned',receipt.replyState.phase);return;}
          const reason=receipt.noData?'no-data':receipt.stateConflict?'state-conflict':'unacknowledged';
          if(failure(reason)&&receipt.replyState?.phase!=='awaiting_permission'&&await recoverReceiver(false))return;
          finish('skipped',reason,receipt.replyState?.phase);
        }catch(error){
          const reason=error?.message==='timeout'?'receiver-timeout':'receiver-unavailable';
          if(failure(reason)&&claimed&&missingReceiver(error)){
            // A timeout may be a live or busy permission UI; it never authorizes navigation.
            try{if(await recoverReceiver(true))return;}catch{}
          }
          finish('failed',reason);
        }
      }
      const worker=async()=>{while(cursor<candidates.length)await one(candidates[cursor++]);};
      await Promise.all([worker(),worker()]);
      report.finishedAt=now();
      try{await saveHealth();}catch{healthRecords=null;report.healthPersistence='unavailable';}
      await browser.storage.local.set({[KEY]:report}).catch(()=>{});return report;
      }finally{for(const [event,listener] of listeners)event?.removeListener?.(listener);}
    }
    function tick(){if(running)return running;running=cycle().finally(()=>{running=null;});return running;}
    async function withManualRun(operation){paused++;try{if(running)await running;return await operation();}finally{paused--;}}
    return {recover,tick,withManualRun,health,forgetTab};
  }
  const api={ALARM,KEY,HEALTH_KEY,INTERVAL,pageId,pending,createService};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.BookmarkOpenedRefresh=api;
})(globalThis);
