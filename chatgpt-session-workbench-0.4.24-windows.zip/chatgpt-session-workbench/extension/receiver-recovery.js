(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const KEY = 'sessionBookmarksReceivers', ALARM = 'session-bookmarks-receivers';
  const FILES = ['model.js', 'chatgpt-dom.js', 'statistics.js', 'onboarding.js', 'quick-button.js', 'quick-guide.js', 'diagnostics.js', 'content.js'];
  const pageId = url => { try { const p = M.normalizeURL(url); return p.kind === 'chatgpt' ? p.id : null; } catch { return null; } };
  const missing = error => /receiving end does not exist|could not establish connection/i.test(error?.message || '');
  function createService({ browser, repository, version, now = Date.now, timeoutMs = 2000 }) {
    let running, loaded, lastSaved, saving = Promise.resolve();
    const records = new Map(), epochs = new Map();
    async function load() {
      if (!loaded) loaded = (async () => {
        const raw = (await browser.storage.session?.get?.(KEY))?.[KEY];
        for (const record of Array.isArray(raw) ? raw.slice(-256) : []) if (record && Number.isInteger(record.tabId) && pageId(record.url) === record.id) {
          if (!records.has(record.tabId)) records.set(record.tabId, { ...record, history: Array.isArray(record.history) ? record.history.slice(-16) : [],
            status: 'unavailable', reason: 'worker-restarted', nextAttemptAt: 0 });
        }
      })().catch(error => { loaded = null; throw error; });
      await loaded;
    }
    function persist() {
      const data = [...records.values()].slice(-256).map(r => ({ ...r, history: [...r.history] }));
      saving = saving.catch(() => {}).then(async () => {
        const encoded = JSON.stringify(data);
        if (encoded === lastSaved) return;
        await browser.storage.session?.set?.({ [KEY]: data }); lastSaved = encoded;
      });
      return saving;
    }
    async function bounded(work) {
      let timer;
      try { return await Promise.race([Promise.resolve().then(work), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('receiver-timeout')), timeoutMs); })]); }
      finally { clearTimeout(timer); }
    }
    async function targets() {
      const [{ state }, tabs] = await Promise.all([repository.dispatch('load', { activeOnly: true }), browser.tabs.query({})]);
      const saved = new Set(state.bookmarks.filter(b => b.kind === 'chatgpt').map(b => b.id));
      return tabs.filter(t => saved.has(pageId(t.pendingUrl || t.url)));
    }
    async function snapshot() {
      await load();
      return (await targets()).map(tab => {
        const id = pageId(tab.pendingUrl || tab.url), record = records.get(tab.id);
        return record?.id === id && record.url === tab.url ? { ...record, history: [...record.history] } :
          { tabId: tab.id, id, url: tab.url, status: 'unavailable', reason: 'not-checked', history: [] };
      });
    }
    async function forget(tabId) {
      epochs.set(tabId, (epochs.get(tabId) || 0) + 1);
      await load(); records.delete(tabId); await persist();
    }
    async function inspect(tab) {
      const id = pageId(tab.url), epoch = epochs.get(tab.id) || 0;
      if (!id || tab.pendingUrl && tab.pendingUrl !== tab.url) return;
      let record = records.get(tab.id);
      if (!record || record.id !== id || record.url !== tab.url) record = { tabId: tab.id, id, url: tab.url, history: [], attempts: 0 };
      if (record.nextAttemptAt > now()) return;
      records.set(tab.id, record);
      const current = async () => {
        const latest = await browser.tabs.get(tab.id);
        if ((epochs.get(tab.id) || 0) !== epoch || latest.url !== tab.url || latest.pendingUrl && latest.pendingUrl !== tab.url) throw Error('document-changed');
        return latest;
      };
      const mark = async (status, reason, extra = {}) => {
        await current();
        Object.assign(record, { status, reason, checkedAt: now() }, extra);
        if (record.history.at(-1)?.reason !== reason) record.history = [...record.history, { at: now(), status, reason }].slice(-16);
        await persist();
      };
      let target = { frameId: 0 }, receipt, injected = false;
      const request = async action => {
        const requestId = `receiver:${tab.id}:${now()}:${action}`;
        const result = await bounded(() => browser.tabs.sendMessage(tab.id, { channel: 'session-bookmarks-refresh', action, id, requestId }, target));
        if (result?.requestId !== requestId) throw Error('invalid-receipt');
        return result;
      };
      try {
        await current();
        if (tab.discarded || tab.frozen || tab.status === 'loading') {
          await mark('unavailable', 'document-not-ready', { nextAttemptAt: now() + 2000 }); return;
        }
        try { receipt = await request('health'); }
        catch (error) {
          if (!missing(error)) throw error;
          await mark('unavailable', 'receiver-unavailable');
          record.attempts++;
          // The first injection only reads identity. Chrome's documentId then pins
          // the file injection and receipts to this document, including navigation races.
          let identity;
          try {
            identity = await bounded(() => browser.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] },
              func: expectedURL => {
                if (location.href === expectedURL) globalThis.__workbenchRecoveryURL = expectedURL;
                return { url: location.href };
              }, args: [tab.url] }));
          } catch { throw Error('injection-failed'); }
          await current();
          const document = identity?.find(item => item.frameId === 0);
          if (!document?.documentId || document.result?.url !== tab.url) throw Error('document-changed');
          target = { documentId: document.documentId };
          await mark('recovering', 'injecting', { browserDocumentId: document.documentId, recoveryPending: true });
          try {
            await bounded(() => browser.scripting.executeScript({ target: { tabId: tab.id, documentIds: [document.documentId] }, files: FILES }));
          } catch { throw Error('injection-failed'); }
          await current();
          receipt = await request('health'); injected = true;
        }
        if (!receipt || receipt.version !== version || receipt.url !== tab.url || receipt.id !== id || !receipt.documentId) throw Error('invalid-receipt');
        const contentDocument = receipt.documentId;
        if (injected || !receipt.currentValid || !Number.isSafeInteger(receipt.lastValidReadAt) || now() - receipt.lastValidReadAt >= 180000) {
          await mark('recovering', 'rescan');
          receipt = await request('rescan');
          if (!receipt?.initialized) throw Error(receipt?.stateConflict ? 'state-conflict' : 'unconfirmed-read');
        }
        await current();
        if (receipt.version !== version || receipt.url !== tab.url || receipt.id !== id || receipt.documentId !== contentDocument) throw Error('document-changed');
        await mark('available', injected || record.recoveryPending ? 'recovered' : 'verified', { documentId: contentDocument,
          phase: receipt.replyState?.phase || receipt.phase || record.phase || null, nextAttemptAt: now() + 2000, attempts: 0, recoveryPending: false });
      } catch (error) {
        if (error.message === 'document-changed') { if ((epochs.get(tab.id) || 0) === epoch) await forget(tab.id); return; }
        const reason = ['injection-failed', 'receiver-timeout', 'state-conflict', 'unconfirmed-read', 'invalid-receipt'].includes(error.message) ? error.message : 'receiver-unavailable';
        try { await mark('unavailable', reason, { nextAttemptAt: now() + Math.min(60000, 2000 * 2 ** Math.min(record.attempts || 1, 5)) }); } catch { /* A closed/replaced document has no result to publish. */ }
      }
    }
    function scan() {
      if (running) return running;
      running = (async () => {
        await load();
        const tabs = await targets(), ids = new Set(tabs.map(t => t.id));
        for (const id of records.keys()) if (!ids.has(id)) records.delete(id);
        let cursor = 0;
        await Promise.all(Array.from({ length: Math.min(4, tabs.length) }, async () => { while (cursor < tabs.length) await inspect(tabs[cursor++]); }));
        await persist();
      })().finally(() => { running = null; });
      return running;
    }
    async function changed(tabId) {
      await load();
      if (running) await running.catch(() => {});
      const record = records.get(tabId); if (record) record.nextAttemptAt = 0;
      await scan();
    }
    return { scan, snapshot, forget, changed, async health(tabId) { await load(); return records.get(tabId) || null; },
      async start() { await browser.alarms?.create?.(ALARM, { delayInMinutes: 1, periodInMinutes: 1 }); await scan(); } };
  }
  const api = { KEY, ALARM, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkReceiverRecovery = api;
})(globalThis);
