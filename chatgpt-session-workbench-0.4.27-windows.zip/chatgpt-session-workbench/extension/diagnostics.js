(function (root) {
  'use strict';
  const CHANNEL = 'session-bookmarks-diagnostics';
  const INCIDENT_LIMIT = 20, INCIDENT_MAX_LENGTH = 24000, INCIDENT_STALE_MS = 15 * 60 * 1000;
  const stages = new Set(['initializing', 'observing', 'idle', 'generating', 'candidate', 'completed', 'awaiting_permission', 'init-error', 'optional-error', 'check-error', 'send-error']);
  const reasons = new Set(['script-start', 'observer-registered', 'context-invalidated', 'runtime-disconnected', 'reply-init-failed',
    'quick-guide-init-failed', 'statistics-init-failed', 'background-check-rejected', 'reply-check-failed', 'unsupported-route',
    'no-valid-tail', 'background-observation-rejected', 'reply-observe-failed', 'storage-accepted', 'storage-synchronized',
    'stale-observation-rejected', 'user-committed', 'permission-controls', 'generation-signal', 'completion-signal-quiet',
    'generation-ended-quiet', 'no-active-signal', 'dots-native-entry', 'unproven-history-tail','unread-sampled']);
  const version = value => typeof value === 'string' && /^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value) ? value : null;
  const code = value => {
    if (typeof value !== 'string') return null;
    const [v, reason] = value.split(':');
    return version(v) && reasons.has(reason) ? `${v}:${reason}` : null;
  };
  const identifier = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(value) ? value : null;
  const MARKER_MAX_LENGTH = 48000;
  const decisions = new Set(['accepted', 'unchanged', 'not-bookmarked', 'retired-identity', 'unknown-unproven', 'older-observation',
    'answered-user', 'missing-user-ancestry', 'unwitnessed-continuation', 'unwitnessed-restart', 'stale-revision', 'uninitialized-revision']);
  const choose = (value, allowed) => allowed.includes(value) ? value : null;
  const booleans = (value, keys) => Object.fromEntries(keys.map(key => [key, value?.[key] === true]));
  function tail(value) {
    if (!value) return null;
    return { author: ['user', 'assistant', 'tool'].includes(value.author) ? value.author : null,
      phase: ['complete', 'generating', 'unknown', 'awaiting_permission'].includes(value.phase) ? value.phase : 'unknown',
      messageId: identifier(value.messageId), userMessageId: identifier(value.userMessageId) };
  }
  function page(value) {
    return { version: version(value.version), collector: ['running', 'failed'].includes(value.collector) ? value.collector : null,
      stage: stages.has(value.stage) ? value.stage : null, reason: code(value.reason), result: code(value.result), tail: tail(value.tail),
      sampledAt: integer(value.sampledAt), visibility: choose(value.visibility, ['visible', 'hidden']),
      evidence: evidence(value.evidence), collection: collection(value.collection) };
  }
  function evidence(value) {
    if (!value) return null;
    const p = value.permission;
    return { messages: integer(value.messages), permission: p ? { detected: p.detected === true,
      state: p.detected ? 'present' : p.reason === 'no-tail' || p.reason === 'unbounded-action-pair' || p.allow || p.deny ? 'unknown' : 'absent',
      reason: choose(p.reason, ['no-tail','not-assistant','completed-turn','action-pair','no-action-pair','unbounded-action-pair']),
      scope: choose(p.scope, ['message-turn','work-turn']), controls: integer(p.controls), allow: integer(p.allow), deny: integer(p.deny), depth: integer(p.depth) } : null,
      generation: booleans(value.generation, ['active','turn','message','streaming','stop','ariaBusy']),
      completion: booleans(value.completion, ['turn','message','streamingEnded','actions']) };
  }
  function collection(value) {
    if (!value) return null;
    return { route: refreshId(value.route), epoch: integer(value.epoch), documentStartedAt: integer(value.documentStartedAt),
      observedAt: integer(value.observedAt), observed: tail(value.observed), stored: tail(value.stored), acknowledged: tail(value.acknowledged),
      health: health(value.health),
      ...booleans(value, ['checked','enabled','checking','sending','suspended']),
      baseRevision: integer(value.baseRevision), storedRevision: integer(value.storedRevision), lastCheckAt: integer(value.lastCheckAt),
      snapshotReason: choose(value.snapshotReason, ['not-sampled','valid','no-messages','retained-route','empty-user','known-user-replay','message-user-conflict']),
      decision: value.decision ? { at: integer(value.decision.at), status: choose(value.decision.status, ['sending','accepted','synchronized','rejected','timeout','transport-error']),
        reason: decisions.has(value.decision.reason) ? value.decision.reason : null, revision: integer(value.decision.revision) } : null,
      attempt: value.attempt ? { observedAt: integer(value.attempt.observedAt), revision: integer(value.attempt.revision),
        tries: integer(value.attempt.tries), blocked: value.attempt.blocked === true } : null,
      history: (Array.isArray(value.history) ? value.history : []).slice(-16).map(event => ({ at: integer(event.at),
        stage: stages.has(event.stage) ? event.stage : null, reason: code(event.reason), phase: tail(event).phase, revision: integer(event.revision) })) };
  }
  function health(value) {
    if(!value)return null;
    const at=Date.now(), validAt=integer(value.lastValidReadAt), failureAt=integer(value.failureSince);
    return {documentId:identifier(value.documentId),routeEpoch:integer(value.routeEpoch),currentValid:value.currentValid===true,pending:value.pending===true,
      lastAttemptAt:integer(value.lastAttemptAt),lastRespondedAt:integer(value.lastRespondedAt),lastValidReadAt:validAt,
      failureSince:failureAt,lastFailureReason:choose(value.lastFailureReason,['no-data','state-conflict','unacknowledged','candidate',
        'unproven-history-tail','invalid-receipt','document-changed','receiver-timeout','receiver-unavailable']),
      validAgeMs:validAt===null||validAt>at?null:at-validAt,failureAgeMs:failureAt===null||failureAt>at?null:at-failureAt,
      decision:choose(value.decision,['fresh','failing','unknown','pending'])};
  }
  function marker(value, kind) {
    return kind === 'dots' || kind === 'demo' ? 'not-applicable' :
      ['assistant','tool'].includes(value?.author) && value.phase === 'awaiting_permission' ? 'green' :
      value?.author === 'assistant' && value.phase === 'complete' ? 'red' :
      value && value.phase !== 'unknown' ? 'none' : 'unknown';
  }
  const autoReasons = new Set(['foreground','guard-unavailable','window-interaction','document-changed','not-readable',
    'manual-refresh-running','no-longer-pending','recent-valid','cadence','confirmation-pending','invalid-receipt','rescanned',
    'no-data','state-conflict','unacknowledged','receiver-timeout','receiver-unavailable','receiver-repaired','receiver-reload-requested','unverified-reload-requested',
    'opened-recovery-check','opened-recovery-queued','opened-recovery-pending','frozen','discarded','source-changed','awaiting-permission','closed-generating-check','navigation-pending','navigation-blocked','navigation-requested','still-generating','assistant-complete',
    'timeout','temporary-adopted','canceled','no-browser-window','not-generating-or-reopened','tab-operation-failed']);
  function automaticEvent(value) {
    if(!value)return null;
    const g=value.guard, bool=v=>typeof v==='boolean'?v:null;
    return {id:refreshId(value.id),tabId:integer(value.tabId),at:integer(value.at),
      action:choose(value.action,['none','health','rescan','reload-pending','reload-blocked','reload-requested','navigate-requested']),
      result:choose(value.result,['refreshed','foreground','skipped','failed']),reason:autoReasons.has(value.reason)?value.reason:null,
      guard:g?{at:integer(g.at),active:bool(g.active),windowFocused:bool(g.windowFocused),windowId:integer(g.windowId),interaction:bool(g.interaction),
        decision:choose(g.decision,['background','foreground','guard-unavailable','window-interaction','document-changed','not-readable',
          'manual-refresh-running','owned-minimized-blank','interaction-or-ownership-changed'])}:null};
  }
  function automaticRefresh(stored,targetId,at) {
    if(!stored)return {status:'unavailable'};
    const opened=stored.sessionBookmarksOpenRefresh,closed=stored.sessionBookmarksClosedWatch;
    const items=(Array.isArray(opened?.items)?opened.items:[]).map(automaticEvent).filter(Boolean)
      .sort((a,b)=>Number(b.id===targetId)-Number(a.id===targetId));
    const history=(Array.isArray(closed?.history)?closed.history:[]).filter(e=>autoReasons.has(e.reason)).slice(-10).map(automaticEvent);
    return {status:opened||closed?'recorded':'no-record',collectedAt:at,
      opened:opened?{startedAt:integer(opened.startedAt),finishedAt:integer(opened.finishedAt),
        summary:Object.fromEntries(['refreshed','foreground','skipped','failed'].map(k=>[k,integer(opened[k])])),
        lastNavigation:automaticEvent(opened.lastNavigation),recovery:automaticEvent(opened.recovery),items:items.slice(0,16),omittedItems:Math.max(0,items.length-16)}:null,
      closed:closed?{lastNavigation:automaticEvent(closed.lastNavigation),history,
        recoveryJobs:(closed.jobs||[]).filter(j=>j.mode==='opened-recovery').slice(0,16).map(j=>({id:refreshId(j.id),sourceTabId:integer(j.source?.tabId),
          documentId:identifier(j.source?.documentId),routeEpoch:integer(j.source?.routeEpoch),revision:integer(j.revision),dueAt:integer(j.dueAt)})),
        temporaryConfirmations:(closed.confirmations||[]).filter(c=>!targetId||c.id===targetId).slice(0,16).map(c=>({id:refreshId(c.id),source:'temporary-page',
          sourceTabId:integer(c.source?.tabId),checkedAt:integer(c.checkedAt),contentVersion:version(c.version),confirmed:{...tail(c.confirmed),revision:integer(c.confirmed?.revision)}}))}:null};
  }
  function refreshObservation(value = {}) {
    return { stage: stages.has(value?.stage) ? value.stage : null, reason: code(value?.reason), result: code(value?.result) };
  }
  const refreshCodes = new Set(['queued', 'loaded', 'reloaded', 'rescanned', 'native-reread', 'native-disconnected',
    'native-thread-missing', 'native-state-unknown', 'unsupported', 'temporary-capacity-exhausted', 'temporary-adopted',
    'temporary-close-failed', 'route-changed', 'no-data', 'state-conflict', 'receiver-unavailable-or-unsafe-reload',
    'initialization-timeout', 'tab-operation-failed', 'task-interrupted', 'dots-binding-unverified', 'receiver-version-mismatch', 'manual-only', 'assistant-not-hydrated',
    'unread-sampled','unverified-unread','document-changed','window-unavailable','receiver-timeout']);
  const integer = x => Number.isSafeInteger(x) && x >= 0 ? x : null;
  const refreshId = x => typeof x === 'string' && /^(chatgpt|codex|dots):[a-zA-Z0-9_-]{1,128}$/.test(x) ? x : null;
  const refreshStage = x => stages.has(x) || ['navigation', 'hydration', 'no-data', 'receiver-unavailable', 'receiver-timeout'].includes(x) ? x : null;
  function refresh(value) {
    if (!value || value.schema !== 1) return null;
    const codes = refreshCodes;
    const detail = d => ({ id: typeof d.id === 'string' && /^(chatgpt|codex|dots):[a-zA-Z0-9_-]{1,128}$/.test(d.id) ? d.id : null,
      kind: ['chatgpt', 'codex', 'dots'].includes(d.kind) ? d.kind : null,
      ...(Array.isArray(d.aliases)?{aliases:d.aliases.map(refreshId).filter(Boolean).slice(0,200),omittedAliases:Math.max(0,d.aliases.length-200)}:{}),
      result: ['pending','success','failed','skipped'].includes(d.result) ? d.result : null,
      reason: codes.has(d.reason) ? d.reason : null,
      collectionResult: ['success','failed','skipped'].includes(d.collectionResult) ? d.collectionResult : null,
      collectionReason: codes.has(d.collectionReason) ? d.collectionReason : null,
      originalTabId: integer(d.originalTabId), createdTabId: integer(d.createdTabId),
      cleanup: ['not-created','closed','retained','failed','ownership-unverified'].includes(d.cleanup) ? d.cleanup : null,
      closeAttempts: integer(d.closeAttempts), elapsedMs: integer(d.elapsedMs),
      navigationMs: integer(d.navigationMs), budgetMs: integer(d.budgetMs), lastResponseAtMs: integer(d.lastResponseAtMs),
      verification: ['verified-dom','verified-unread','native-entry','saved-unverified','unknown'].includes(d.verification) ? d.verification : null,
      unread:integer(d.unread),sampledAt:integer(d.sampledAt),
      storageVerified: d.storageVerified === true,
      scope: d.scope === 'entry-unread' ? d.scope : null, unreadAvailable: d.unreadAvailable === true,
      transport: d.transport ? Object.fromEntries(['attempts','responses','timeouts','unavailable','errors','maxResponseMs'].map(key => [key, integer(d.transport[key])])) : null,
      timeline: (Array.isArray(d.timeline) ? d.timeline : []).slice(0,16).map(t => ({ atMs: integer(t.atMs),
        stage: stages.has(t.stage) || ['navigation','hydration','no-data','receiver-unavailable','receiver-timeout'].includes(t.stage) ? t.stage : null })),
      receiver: ['responded','unavailable','timeout-or-error'].includes(d.receiver) ? d.receiver : null,
      observation: d.observation ? { ...refreshObservation(d.observation), initialized: d.observation.initialized === true,
        stateConflict: d.observation.stateConflict === true, storedRevision: integer(d.observation.storedRevision),
        noData: d.observation.noData === true, version: version(d.observation.version),
        phase: tail({ phase: d.observation.phase }).phase, revision: integer(d.observation.revision) } : null,
      source: d.source ? detail({ ...d.source, source: null, pages: [] }) : null,
      pages: (Array.isArray(d.pages) ? d.pages : []).slice(0, 32).map(p => detail({ ...p, source: null, pages: [] })) });
    return { schema: 1, status: ['running','complete','interrupted'].includes(value.status) ? value.status : null,
      startedAt: integer(value.startedAt), completedAt: integer(value.completedAt), recoveredAt: integer(value.recoveredAt),
      total: value.details?.length || 0, success: integer(value.success), failed: integer(value.failed), skipped: integer(value.skipped),
      details: (value.details || []).slice(0, 200).map(detail), omittedDetails: Math.max(0, (value.details?.length || 0) - 200),
      recovery: (value.recovery || []).slice(0, 200).map(detail) };
  }
  // Refresh incidents remain a timestamped auxiliary snapshot in the marker report.
  async function collectIncident({ browser, now = Date.now, timeoutMs = 2000 }) {
    const report = { schema: 1, type: 'refresh-incident', version: version(browser.runtime.getManifest?.().version),
      collectedAt: now(), status: 'no-record', message: '无可用记录' };
    let stored;
    try {
      stored = await deadline(() => browser.storage.local.get('sessionBookmarksRefresh'), timeoutMs, null);
      if (stored === null) throw Error();
    } catch { return { ...report, status: 'unavailable', message: '刷新记录读取失败' }; }
    const value = stored?.sessionBookmarksRefresh;
    if (!value || value.schema !== 1 || !['running', 'complete', 'interrupted'].includes(value.status) || !Array.isArray(value.details)) return report;
    const startedAt = integer(value.startedAt), completedAt = integer(value.completedAt);
    // Recovery time is separate: reopening the browser does not make an old refresh recent.
    const eventAt = completedAt ?? startedAt, ageMs = eventAt === null ? null : report.collectedAt - eventAt;
    Object.assign(report, { refreshStatus: value.status, startedAt, completedAt, recoveredAt: integer(value.recoveredAt), eventAt, ageMs,
      stale: ageMs === null || ageMs < 0 || ageMs > INCIDENT_STALE_MS,
      summary: { total: value.details.length, success: 0, failed: 0, skipped: 0 }, details: [], omittedDetails: 0,
      expectedSkips: [], omittedExpectedSkips: 0 });
    const expectedSkip = d => d.result === 'skipped' && d.reason === 'manual-only' &&
      refreshId(d.id)?.startsWith('dots:') && (d.kind == null || d.kind === 'dots');
    const abnormal = d => d && (d.result === 'failed' || d.result === 'skipped' && !expectedSkip(d) ||
      ['failed', 'skipped'].includes(d.collectionResult) ||
      ['failed', 'ownership-unverified'].includes(d.cleanup));
    function visit(d, parentId, depth = 0) {
      if (!d || typeof d !== 'object') return;
      const id = refreshId(d.id) || parentId;
      if (abnormal(d)) {
        if (report.details.length >= INCIDENT_LIMIT) report.omittedDetails++;
        else {
          const timeline = Array.isArray(d.timeline) ? d.timeline : [];
          report.details.push({ id, result: ['failed', 'skipped'].includes(d.result) ? d.result :
            ['failed', 'ownership-unverified'].includes(d.cleanup) ? 'failed' : d.collectionResult,
            ...(Array.isArray(d.aliases)?{aliases:d.aliases.map(refreshId).filter(Boolean).slice(0,200),omittedAliases:Math.max(0,d.aliases.length-200)}:{}),
            reason: refreshCodes.has(d.reason) ? d.reason : null,
            ...(['failed', 'skipped'].includes(d.collectionResult) ? { collectionResult: d.collectionResult,
              collectionReason: refreshCodes.has(d.collectionReason) ? d.collectionReason : null } : {}),
            receiver: ['responded', 'unavailable', 'timeout-or-error'].includes(d.receiver) ? d.receiver : null,
            cleanup: ['not-created', 'closed', 'retained', 'failed', 'ownership-unverified'].includes(d.cleanup) ? d.cleanup : null,
            originalTabId: integer(d.originalTabId), createdTabId: integer(d.createdTabId), elapsedMs: integer(d.elapsedMs),
            stage: refreshStage(d.observation?.stage), stages: timeline.slice(-3).map(t => ({ atMs: integer(t?.atMs), stage: refreshStage(t?.stage) })) });
        }
      } else if (expectedSkip(d)) {
        if (report.expectedSkips.length >= INCIDENT_LIMIT) report.omittedExpectedSkips++;
        else report.expectedSkips.push({ id, reason: 'manual-only' });
      }
      // Journal page/source records have at most two nested levels; do not serialize their successful siblings.
      if (depth < 2) {
        visit(d.source, id, depth + 1);
        for (const page of Array.isArray(d.pages) ? d.pages : []) visit(page, id, depth + 1);
      }
    }
    for (const d of value.details) {
      if (['success', 'failed', 'skipped'].includes(d?.result)) report.summary[d.result]++;
      visit(d, null);
    }
    const hasAnomalies = report.details.length + report.omittedDetails > 0;
    report.status = hasAnomalies ? 'anomalies' : value.status === 'complete' ? 'no-anomalies' : value.status === 'running' ? 'in-progress' : 'interrupted';
    report.message = hasAnomalies ? '最近一次刷新异常快照' : value.status === 'complete' ? '最近一次刷新无异常' :
      value.status === 'running' ? '最近一次刷新尚未完成' : '最近一次刷新已中断';
    while (JSON.stringify(report, null, 2).length > INCIDENT_MAX_LENGTH && report.expectedSkips.length) { report.expectedSkips.pop(); report.omittedExpectedSkips++; }
    while (JSON.stringify(report, null, 2).length > INCIDENT_MAX_LENGTH && report.details.length) { report.details.pop(); report.omittedDetails++; }
    return report;
  }
  function readPage(document, adapter, id, scriptVersion, collectorState) {
    const element = document.documentElement;
    const result = { schema: 1, id, status: 'ok', ...page({ version: scriptVersion,
      collector: element.getAttribute('data-workbench-collector'), stage: element.getAttribute('data-workbench-stage'),
      reason: element.getAttribute('data-workbench-reason'), result: element.getAttribute('data-workbench-result') }) };
    result.sampledAt = Date.now();
    result.visibility = document.hidden ? 'hidden' : 'visible';
    result.collection = collection(collectorState);
    try {
      const entries = adapter.messages(document);
      result.tail = tail(adapter.reply(document, entries));
      result.evidence = evidence(adapter.replyEvidence?.(document, entries));
    }
    catch { result.status = 'dom-read-failed'; }
    return result;
  }
  function deadline(task, ms, fallback) {
    return new Promise(resolve => {
      const timer = setTimeout(() => resolve(fallback), ms);
      Promise.resolve().then(task).then(value => { clearTimeout(timer); resolve(value); }, () => { clearTimeout(timer); resolve(fallback); });
    });
  }
  async function collect({ browser, repository, codexStatus, model, backgroundVersion, collectionHealth=async()=>null, receiverHealth=async()=>null, timeoutMs = 2000, targetId, windowId, now = Date.now }) {
    const startedAt = now();
    const automatic = deadline(()=>browser.storage.local.get(['sessionBookmarksOpenRefresh','sessionBookmarksClosedWatch']),timeoutMs,null);
    let loaded = await deadline(() => repository.dispatch('load'), timeoutMs, null);
    let state = loaded?.state || { bookmarks: [] }, storageReadAt = now();
    const parse = url => { try { const link = model.normalizeURL(url); return link.kind === 'chatgpt' ? link.id : null; } catch { return null; } };
    const queried = await deadline(() => browser.tabs.query({ url: 'https://chatgpt.com/*' }), timeoutMs, null);
    targetId = refreshId(targetId) || parse((queried || []).find(t => t.active && (windowId == null || t.windowId === windowId))?.url);
    const prioritize = values => values.sort((a,b) => Number(b.id === targetId) - Number(a.id === targetId) || Number(b.active === true) - Number(a.active === true));
    const candidates = prioritize((queried || []).map(t => ({ tabId: t.id, id: parse(t.pendingUrl || t.url),
      active: t.active === true, windowId: integer(t.windowId), discarded: t.discarded === true, frozen: t.frozen === true })).filter(t => Number.isInteger(t.tabId) && t.id));
    const targets = candidates.slice(0, 32), tabs = new Array(targets.length);
    let cursor = 0;
    async function read(target) {
      try {
        if (parse((await browser.tabs.get(target.tabId)).url) !== target.id) return { ...target, status: 'route-changed' };
        const reply = await browser.tabs.sendMessage(target.tabId, { channel: CHANNEL, action: 'read' }, { frameId: 0 });
        if (!reply) return { ...target, status: 'receiver-unavailable' };
        if (reply.schema !== 1 || !['ok', 'dom-read-failed'].includes(reply.status)) return { ...target, status: 'invalid-response' };
        const current = await browser.tabs.get(target.tabId);
        if (reply.id !== target.id || parse(current.pendingUrl || current.url) !== target.id) return { ...target, status: 'route-changed' };
        return { ...target, status: reply.status, ...page(reply), protocol: reply.collection ? 'markers' : 'legacy' };
      } catch (error) {
        return { ...target, status: /receiving end|establish connection|message port|context invalidated/i.test(error?.message || '') ? 'receiver-unavailable' : 'page-request-failed' };
      }
    }
    const native = state.bookmarks.some(b => b.kind === 'codex') ?
      deadline(() => codexStatus.read(), 6000, null) : Promise.resolve(null);
    await Promise.all(Array.from({ length: Math.min(4, targets.length) }, async () => {
      while (cursor < targets.length) {
        const index = cursor++, target = targets[index];
        const [pageResult,record,recovery]=await Promise.all([deadline(() => read(target), timeoutMs, { ...target, status: 'timeout' }),
          deadline(()=>collectionHealth(target.tabId),timeoutMs,null), deadline(()=>receiverHealth(target.tabId),timeoutMs,null)]);
        const recoveryReasons = ['not-checked','worker-restarted','document-not-ready','receiver-unavailable','injecting','rescan',
          'recovered','verified','injection-failed','receiver-timeout','state-conflict','unconfirmed-read','invalid-receipt','read-pending'];
        tabs[index]={...pageResult,health:health(record),recovery:recovery ? {
          status: choose(recovery.status, ['available','unavailable','recovering','checking','suspended']), reason: choose(recovery.reason, recoveryReasons),
          contentVersion: version(recovery.contentVersion), routeEpoch: integer(recovery.routeEpoch), recoveryPending: recovery.recoveryPending === true,
          invalidation: recovery.invalidation ? { revision: integer(recovery.invalidation.revision), ...tail(recovery.invalidation.observed) } : null,
          confirmed: recovery.confirmed ? { ...tail(recovery.confirmed), revision: integer(recovery.confirmed.revision) } : null,
          checkedAt: integer(recovery.checkedAt), documentId: identifier(recovery.documentId), browserDocumentId: identifier(recovery.browserDocumentId),
          history: (Array.isArray(recovery.history) ? recovery.history : []).slice(-16).map(e => ({ at: integer(e.at),
            status: choose(e.status, ['available','unavailable','recovering','checking','suspended']), reason: choose(e.reason, recoveryReasons) })) } : null};
      }
    }));
    const snapshot = await native;
    const latest = await deadline(() => repository.dispatch('load'), timeoutMs, null);
    if (latest?.state) { state = latest.state; storageReadAt = now(); }
    const bookmarks = prioritize(state.bookmarks.filter(b => b.kind !== 'demo').map(b => ({ id: b.id, kind: b.kind,
      saved: b.replyState ? { ...tail(b.replyState), revision: integer(b.replyState.revision), observedAt: integer(b.replyState.observedAt) } : null,
      expected: marker(b.replyState, b.kind) }))).slice(0, 200);
    const nativeModel = root.BookmarkCodexStatus || (typeof module !== 'undefined' && module.exports ? require('./codex-status.js') : null);
    const projectedAt = now();
    const displayed = nativeModel?.applyToState(state, snapshot || undefined, projectedAt);
    for (const b of bookmarks.filter(b => b.kind === 'codex')) b.expected = marker(displayed?.bookmarks.find(t => t.id === b.id)?.replyState, b.kind);
    for (const t of tabs) {
      const saved = bookmarks.find(b => b.id === t.id)?.saved;
      const compare = value => !value || !saved || value.phase === 'unknown' ? 'unknown' :
        ['author','phase','messageId','userMessageId'].every(key => value[key] === saved[key]) ? 'matched' : 'different';
      t.domVsSaved = compare(t.tail); t.collectorVsSaved = compare(t.collection?.stored);
      t.expectedFromDOM = marker(t.tail, 'chatgpt');
    }
    const wanted = new Set(bookmarks.filter(b => b.kind === 'codex').map(b => b.id.slice(6)));
    const refreshIncident = await collectIncident({ browser, now, timeoutMs });
    return fit({ schema: 2, type: 'marker-state', version: version(browser.runtime.getManifest?.().version), startedAt, collectedAt: now(),
      targetId, versions: { background: version(backgroundVersion), manifest: version(browser.runtime.getManifest?.().version) },
      evidenceStatus: 'current-sampled', storageReadAt, storageStatus: latest?.state ? 'ok' : loaded?.state ? 'stale-read' : 'unavailable', refreshIncident,
      automaticRefresh:automaticRefresh(await automatic,targetId,now()),
      bookmarks, tabs, tabQuery: queried ? 'ok' : 'tab-query-unavailable',
      omittedBookmarks: Math.max(0, state.bookmarks.length - bookmarks.length), omittedTabs: Math.max(0, candidates.length - targets.length),
      codex: { status: !state.bookmarks.some(b => b.kind === 'codex') ? 'not-requested' : snapshot ? 'ok' : 'timeout-or-unavailable',
        connected: snapshot?.connected === true,
        observedAt: integer(snapshot?.observedAt), sampledAt: projectedAt,
        ageMs: integer(snapshot?.observedAt) === null ? null : Math.max(0, projectedAt - snapshot.observedAt),
        stale: snapshot ? !nativeModel?.isFresh(snapshot, projectedAt) : null,
        capabilities: Object.fromEntries(['completion', 'activeThread', 'approval'].map(k => [k, snapshot?.capabilities?.[k] === true])),
        activeThreadId: snapshot?.capabilities?.activeThread && wanted.has(snapshot.activeThreadId) ? snapshot.activeThreadId : null,
        threads: (snapshot?.threads || []).filter(t => wanted.has(t.threadId)).map(t => ({ threadId: t.threadId, ...tail(t) })) } });
  }
  function fit(report) {
    report.omittedForSize ||= 0;
    const nonTarget = items => (items || []).findLastIndex(item => item.id !== report.targetId);
    while (JSON.stringify(report, null, 2).length > MARKER_MAX_LENGTH) {
      const history = [...(report.tabs || [])].reverse().find(t => t.id !== report.targetId && t.collection?.history?.length);
      if (report.refreshIncident?.expectedSkips?.length) { report.refreshIncident.expectedSkips.pop(); report.refreshIncident.omittedExpectedSkips++; }
      else if (nonTarget(report.automaticRefresh?.opened?.items) >= 0) { report.automaticRefresh.opened.items.splice(nonTarget(report.automaticRefresh.opened.items),1); report.automaticRefresh.opened.omittedItems++; }
      else if (nonTarget(report.automaticRefresh?.closed?.history) >= 0) report.automaticRefresh.closed.history.splice(nonTarget(report.automaticRefresh.closed.history),1);
      else if (history) history.collection.history.shift();
      else if (nonTarget(report.panel?.rows) >= 0) { report.panel.rows.splice(nonTarget(report.panel.rows), 1); report.panel.omittedRows++; }
      else if (nonTarget(report.tabs) >= 0) { report.tabs.splice(nonTarget(report.tabs), 1); report.omittedTabs++; }
      else if (nonTarget(report.bookmarks) >= 0) { report.bookmarks.splice(nonTarget(report.bookmarks), 1); report.omittedBookmarks++; }
      else if (report.refreshIncident?.details?.length) { report.refreshIncident.details.pop(); report.refreshIncident.omittedDetails++; }
      else if (report.tabs?.length > 1) { report.tabs.pop(); report.omittedTabs++; }
      else if (report.tabs?.[0]?.collection?.history?.length) report.tabs[0].collection.history.shift();
      else break;
      report.omittedForSize++;
    }
    return report;
  }
  function fromBackground(value, { panelVersion, manifestVersion, targetId, now = Date.now }) {
    const current = value?.schema === 2 && value?.type === 'marker-state';
    // Old workers return only a historical incident. Keep that snapshot auxiliary,
    // and explicitly mark all missing live evidence instead of implying a current collection.
    const report = current ? value : { schema: 2, type: 'marker-state', collectedAt: now(), targetId: refreshId(targetId),
      evidenceStatus: 'partial-legacy-background', missing: ['current-storage','page-observations','acceptance-decisions'],
      storageStatus: 'unavailable', tabQuery: 'not-collected', bookmarks: [], tabs: [], omittedBookmarks: 0, omittedTabs: 0,
      refreshIncident: value?.type === 'refresh-incident' ? {
        type: 'refresh-incident', version: version(value.version), collectedAt: integer(value.collectedAt),
        startedAt: integer(value.startedAt), completedAt: integer(value.completedAt), eventAt: integer(value.eventAt),
        ageMs: integer(value.ageMs), stale: value.stale === true,
        summary: Object.fromEntries(['total','success','failed','skipped'].map(k => [k,integer(value.summary?.[k])])),
        details: refresh({schema:1,details:value.details || []}).details.slice(0,20) } : null };
    report.versions = { ...report.versions, panel: version(panelVersion), manifest: version(manifestVersion),
      background: current ? version(report.versions?.background) : version(value?.version),
      backgroundSource: current && report.versions?.background ? 'script' : 'legacy-reported',
      content: [...new Set((report.tabs || []).map(t => version(t.version)).filter(Boolean))] };
    const known = [report.versions.panel,report.versions.background,report.versions.manifest,...report.versions.content].filter(Boolean);
    report.versions.consistency = !current ? 'legacy-incomplete' : known.some(v => v !== report.versions.panel) ? 'mixed' :
      !report.versions.background ? 'unknown' : 'matched';
    return report;
  }
  const api = { CHANNEL, readPage, collect, collectIncident, refreshObservation, refresh, marker, fit, fromBackground,
    MARKER_MAX_LENGTH, INCIDENT_LIMIT, INCIDENT_MAX_LENGTH, INCIDENT_STALE_MS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkDiagnostics = Object.freeze(api);
})(globalThis);
