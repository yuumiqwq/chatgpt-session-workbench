(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const D = typeof module !== 'undefined' && module.exports ? require('./diagnostics.js') : root.BookmarkDiagnostics;
  const CHANNEL = 'session-bookmarks-refresh';
  const JOURNAL = 'sessionBookmarksRefresh';
  function pageId(value) {
    if (typeof value !== 'string' || /#settings(?:[/?]|$)/i.test(value)) return null;
    try {
      const link = M.normalizeURL(value);
      if (link.kind === 'chatgpt') return link.id;
    } catch { /* Only the native Dots destination is supported in addition to saved chats. */ }
    return /^https:\/\/chatgpt\.com\/dots\/home\/?(?:[?#][^\s\\]*)?$/.test(value) ? 'dots:home' : null;
  }
  function createService({ browser, repository, codexStatus, commitDots=async()=>false, reserveDots=()=>{}, cancelDots=()=>{}, timeoutMs = 20000, pollMs = 250, settleMs = 2500, stableMs = 750, isOtherTemporary = () => false, beginConfirmation = async()=>null, confirmReceipt = async()=>true, endConfirmation = ()=>{} }) {
    let running = false, temporaryCount = 0, journal = null, recovery = null, serial = Promise.resolve();
    // Writes are serialized with snapshots so parallel tabs cannot restore stale ownership.
    function persist() {
      if (!journal) return Promise.resolve();
      const snapshot = JSON.parse(JSON.stringify(journal));
      const write = serial.catch(() => {}).then(() => browser.storage.local.set({ [JOURNAL]: snapshot }));
      serial = write; return write;
    }
    const leases = new Map();
    async function adopt(id) {
      if (running) interacted.add(id);
      if (!owned.has(id)) return false;
      adopted.add(id);
      const lease = leases.get(id);
      if (lease) lease.adopted = true;
      if (journal) { journal.leases = [...leases.values()]; await persist(); }
      return true;
    }
    function checkpoint(group, detail) {
      if (!journal) return Promise.resolve();
      for (const bookmark of group.bookmarks) {
        const index = journal.details.findIndex(d => d.id === bookmark.id);
          journal.details[index] = { id: bookmark.id, kind: bookmark.kind, ...(bookmark.aliases?{aliases:bookmark.aliases}:{}), ...detail };
      }
      journal.leases = [...leases.values()];
      return persist();
    }
    function recover() {
      if (running) return Promise.resolve();
      if (recovery) return recovery;
      recovery = (async () => {
        const stored = (await browser.storage.local.get?.(JOURNAL))?.[JOURNAL];
        if (!stored || stored.schema !== 1 || !['running', 'interrupted', 'complete'].includes(stored.status)) return;
        if (!(stored.leases?.length || stored.intents?.length) && stored.status !== 'running') return;
        journal = stored;
        const tabs = await browser.tabs.query({});
        const session = (await browser.storage.session?.get?.(JOURNAL))?.[JOURNAL];
        const recoveryDetails = [];
        for (const intent of stored.intents || []) {
          for (const tab of tabs.filter(t => (t.pendingUrl || t.url)?.endsWith(intent.marker))) {
            if (!(stored.leases || []).some(l => l.tabId === tab.id))
              (stored.leases ||= []).push({ tabId: tab.id,
                windowId: intent.scope==='entry-unread' ? Number.isInteger(intent.windowId)&&intent.windowId>=0?intent.windowId:null : tab.windowId,
                marker: intent.marker,...(intent.scope==='entry-unread'?{scope:intent.scope}:{}) });
            for (const entry of stored.details || []) if (intent.ids?.includes(entry.id)) entry.createdTabId = tab.id;
          }
        }
        for (const lease of stored.leases || []) {
          const tab = tabs.find(t => t.id === lease.tabId);
          const detail = { createdTabId: lease.tabId, result: 'failed', reason: 'task-interrupted' };
          if (!tab) { detail.cleanup = 'closed'; detail.closed = true; }
          else if (lease.adopted) { detail.cleanup = 'retained'; detail.closed = false; }
          else if (tab.windowId === lease.windowId &&
            (session?.runId === stored.runId || (tab.pendingUrl || tab.url)?.endsWith(lease.marker))) {
            owned.add(tab.id); leases.set(tab.id, lease); temporaryCount++;
            await cleanup(detail);
          } else { detail.cleanup = 'ownership-unverified'; detail.closed = false; }
          recoveryDetails.push(detail);
          for (const entry of stored.details || []) if (entry.createdTabId === lease.tabId) Object.assign(entry, detail);
        }
        for (const entry of stored.details || []) if (entry.result === 'pending') {
          entry.result = 'failed'; entry.reason = 'task-interrupted';
        }
        stored.status = stored.status === 'complete' ? 'complete' : 'interrupted';
        for (const result of ['success', 'failed', 'skipped']) stored[result] = (stored.details || []).filter(d => d.result === result).length;
        stored.recoveredAt = Date.now(); stored.recovery = recoveryDetails;
        stored.leases = (stored.leases || []).filter(l => recoveryDetails.some(d => d.createdTabId === l.tabId &&
          (d.cleanup==='failed'||d.cleanup==='ownership-unverified'&&l.scope!=='entry-unread')));
        stored.intents = []; journal = stored; await persist();
      })().finally(() => { recovery = null; });
      return recovery;
    }
    const owned = new Set(), adopted = new Set(), removed = new Set(), interacted = new Set(), reloading = new Set(), epochs = new Map();
    let focusChanged=false;
    const changed=id=>{epochs.set(id,(epochs.get(id)||0)+1);};
    const activated=info=>{interacted.add(info.tabId);void adopt(info.tabId);};
    const moved=id=>{changed(id);void adopt(id);};
    const updated=(id,info)=>{if(info.url||info.status==='loading')changed(id);};
    const focused=()=>{focusChanged=true;};
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    async function bounded(operation, remaining = timeoutMs) {
      let timer;
      try {
        return await Promise.race([Promise.resolve().then(operation),
          new Promise((_, reject) => { timer = setTimeout(() => reject(Error('timeout')), Math.max(1, remaining)); })]);
      } finally { clearTimeout(timer); }
    }
    const message = (id, payload, remaining,limit=1500) => bounded(() => browser.tabs.sendMessage(id, payload, { frameId: 0 }), Math.min(limit, remaining));
    const missingReceiver = error => /receiving end does not exist|receiver unavailable|no receiver|extension context invalidated/i.test(error?.message || '');
    const tabRemoved = id => {removed.add(id);changed(id);};
    const unchanged = (tab, original) => tab?.id === original.id && tab.windowId === original.windowId &&
      pageId(tab.url) === pageId(original.url) && (!tab.pendingUrl || pageId(tab.pendingUrl) === pageId(original.url));
    async function cleanup(detail) {
      const id = detail.createdTabId;
      if (!owned.has(id)) return;
      delete detail.cleanup;
      detail.collectionResult = detail.result; detail.collectionReason = detail.reason;
      detail.closeAttempts = 0;
      try {
        for (let attempt = 0; attempt < 3; attempt++) {
          // A get failure is ambiguous. Only an observed removal or an absent query result proves closure.
          if (removed.has(id)) { detail.cleanup = 'closed'; break; }
          if (adopted.has(id)) { detail.cleanup = 'retained'; break; }
          let tab;
          try { tab = await bounded(() => browser.tabs.get(id)); }
          catch {
            try { tab = (await bounded(() => browser.tabs.query({}))).find(t => t.id === id); }
            catch { if (attempt < 2) await pause(pollMs); continue; }
          }
          if (!tab) { detail.cleanup = 'closed'; break; }
          if (adopted.has(id)) { detail.cleanup = 'retained'; break; }
          const lease=leases.get(id);
          if(lease?.scope==='entry-unread'&&(tab.windowId!==lease.windowId||tab.active||
            !home(tab.pendingUrl||tab.url)||!(tab.pendingUrl||tab.url)?.endsWith(lease.marker))){
            await adopt(id);detail.cleanup='retained';break;
          }
          detail.closeAttempts++;
          try {
            await bounded(() => browser.tabs.remove(id)); detail.cleanup = 'closed'; break;
          } catch { if (attempt < 2) await pause(pollMs); }
        }
        if (!detail.cleanup) {
          if (removed.has(id)) detail.cleanup = 'closed';
          else if (adopted.has(id)) detail.cleanup = 'retained';
          else {
            try {
              const tab = (await bounded(() => browser.tabs.query({}))).find(t => t.id === id);
              if (!tab) detail.cleanup = 'closed';
              else if (adopted.has(id)) detail.cleanup = 'retained';
            } catch { /* Unverified cleanup is reported as failed, with the owned ID. */ }
          }
        }
        detail.cleanup ||= 'failed';
        detail.closed = detail.cleanup === 'closed';
        if (detail.cleanup === 'retained') { detail.result = 'skipped'; detail.reason = 'temporary-adopted'; }
        if (detail.cleanup === 'failed') { detail.result = 'failed'; detail.reason = 'temporary-close-failed'; }
      } finally {
        if (detail.cleanup !== 'failed') temporaryCount--;
        owned.delete(id);
        if (detail.cleanup !== 'failed') leases.delete(id);
      }
    }
    async function web(group, windowId, existing, isolated = false, context) {
      const detail = { originalTabId: null, createdTabId: null, cleanup: 'not-created', result: 'failed', reason: 'initialization-timeout' };
      const startedAt = Date.now();
      let original, temporary = false,ticket=null;
      context ||= {startedAt,primaryEnd:startedAt+timeoutMs*2,hardEnd:startedAt+timeoutMs*4,sources:[]};
      try {
        // Query again immediately before creation: a user may have opened the bookmark while it was queued.
        const tabs = isolated ? [] : existing ? [existing] : await bounded(() => browser.tabs.query({}));
        const matching = tabs.filter(t => !owned.has(t.id) && !isOtherTemporary(t) && Number.isInteger(t.id) && pageId(t.url) === group.key);
        if(!isolated&&!existing)context.sources=matching.map(t=>({...t,epoch:epochs.get(t.id)||0}));
        if (matching.length > 1) {
          const pages = [];
          for (const tab of matching) pages.push(await web(group, windowId, tab,false,context));
          const summary = pages.find(p => p.result === 'success') || pages.find(p => p.result === 'failed') || pages[0];
          Object.assign(detail, summary, { originalTabIds: matching.map(t => t.id), pages });
          return detail;
        }
        original = matching[0];
        if (original) { detail.originalTabId = original.id; await checkpoint(group, { ...detail, result: 'pending' }); }
        else {
          // Failed closes still occupy capacity; a faulty browser must not accumulate new leaked pages.
          if (temporaryCount >= 4) { detail.result = 'skipped'; detail.reason = 'temporary-capacity-exhausted'; return detail; }
          temporaryCount++;
          ticket=await beginConfirmation({id:group.key,runId:journal.runId,sources:context.sources,baseline:group.bookmarks[0]?.replyState});
          const marker = `#workbench-refresh-${journal.runId}-${journal.nextTemporary++}`;
          journal.intents.push({ marker, ids: group.bookmarks.map(b => b.id) }); await persist();
          try {
            original = await browser.tabs.create({ url: group.url.split('#')[0] + marker, active: false,
              ...(Number.isInteger(windowId) && windowId >= 0 ? { windowId } : {}) });
          } catch (error) { temporaryCount--; throw error; }
          if (!Number.isInteger(original?.id)) { temporaryCount--; throw Error('create-failed'); }
          detail.createdTabId = original.id; owned.add(original.id); temporary = true;
          leases.set(original.id, { tabId: original.id, windowId: original.windowId, marker, adopted: false });
          journal.intents = journal.intents.filter(intent => intent.marker !== marker);
          await checkpoint(group, { ...detail, result: 'pending' });
          // Chrome may initially expose only pendingUrl for a just-created document.
          original = { ...original, url: group.url };
        }
        const collectionStartedAt = Date.now(), hardEnd = isolated?context.hardEnd:Math.min(context.primaryEnd,collectionStartedAt+timeoutMs*2);
        let end = Math.min(hardEnd,collectionStartedAt + timeoutMs), loadedAt = null, progressKey = '', requestSequence = 0;
        let verifiedTailKey = '', verifiedTailAt = 0;
        detail.transport = { attempts: 0, responses: 0, timeouts: 0, unavailable: 0, errors: 0, maxResponseMs: 0 };
        detail.timeline = [];
        const note = (stage, extra = {}) => {
          if (detail.timeline.at(-1)?.stage === stage) return;
          if (detail.timeline.length >= 16) detail.timeline.splice(1, 1);
          detail.timeline.push({ atMs: Date.now() - collectionStartedAt, stage, ...extra });
        };
        const advance = key => {
          if (key === progressKey) return;
          progressKey = key;
          end = Math.min(hardEnd, Math.max(end, Date.now() + timeoutMs));
        };
        let preflight = temporary, reloaded = false, lastReceipt = null, versionUnavailable = false, documentToken=null, routeToken=null;
        do {
          const tab = await bounded(() => browser.tabs.get(original.id), end - Date.now());
          if (temporary && (adopted.has(tab.id))) { detail.result = 'skipped'; detail.reason = 'temporary-adopted'; break; }
          if (!unchanged(tab, original)) {
            if (temporary && (!tab.url || tab.url === 'about:blank' || tab.url === 'chrome://newtab/') && pageId(tab.pendingUrl) === group.key) { await pause(pollMs); continue; }
            detail.result = temporary ? 'failed' : 'skipped'; detail.reason = 'route-changed'; break;
          }
          if (tab.status === 'loading') { note('navigation'); await pause(pollMs); continue; }
          if(reloading.delete(tab.id)){const source=context.sources.find(s=>s.id===tab.id);if(source)source.epoch=epochs.get(tab.id)||0;}
          if (loadedAt === null) {
            loadedAt = Date.now(); detail.navigationMs = loadedAt - collectionStartedAt;
            end = Math.min(hardEnd, Math.max(end, loadedAt + timeoutMs)); note('hydration');
          }
          if (!preflight) {
            preflight = true;
            let receipt;
            try { receipt = await message(tab.id, { channel: CHANNEL, action: 'version' }, end - Date.now()); }
            catch (error) { versionUnavailable = missingReceiver(error); }
            const current = await bounded(() => browser.tabs.get(tab.id), end - Date.now());
            if (!unchanged(current, original)) { detail.result = 'skipped'; detail.reason = 'route-changed'; break; }
            const busy = ['generating', 'awaiting_permission'].includes(receipt?.replyState?.phase);
            const window=await bounded(()=>browser.windows?.get?.(tab.windowId),end-Date.now());
            const finalTab=await bounded(()=>browser.tabs.get(tab.id),end-Date.now());
            if (typeof receipt?.version === 'string' && pageId(receipt.url) === group.key && receipt.safeToReload === true && !busy &&
                unchanged(finalTab,original)&&finalTab.active===false&&!finalTab.frozen&&!finalTab.discarded&&typeof window?.focused==='boolean'&&finalTab.status!=='loading'&&!interacted.has(tab.id)&&!focusChanged) {
              await bounded(() => {if(interacted.has(tab.id)||focusChanged)throw Error('interaction-changed');reloading.add(tab.id);return browser.tabs.reload(tab.id);}, end - Date.now());
              reloaded = true; detail.method = 'reload';
              await pause(pollMs); continue;
            }
            detail.method = 'rescan';
          }
          if(ticket===null&&!temporary)ticket=await beginConfirmation({id:group.key,runId:journal.runId,sources:context.sources,baseline:group.bookmarks[0]?.replyState});
          let receipt, rescanUnavailable = false;
          const requestId = `${journal.runId}:${tab.id}:${++requestSequence}`, sentAt = Date.now(),requestEpoch=epochs.get(tab.id)||0;
          detail.transport.attempts++;
          try { receipt = await message(tab.id, { channel: CHANNEL, action: 'rescan', id: group.key, temporary, requestId }, end - Date.now(),5000); }
          catch (error) {
            rescanUnavailable = missingReceiver(error); detail.receiver = rescanUnavailable ? 'unavailable' : 'timeout-or-error';
            detail.transport[rescanUnavailable ? 'unavailable' : error?.message === 'timeout' ? 'timeouts' : 'errors']++;
            note(rescanUnavailable ? 'receiver-unavailable' : 'receiver-timeout');
          }
          detail.transport.maxResponseMs = Math.max(detail.transport.maxResponseMs, Date.now() - sentAt);
          if (Date.now() >= end) break;
          const current = await bounded(() => browser.tabs.get(tab.id), end - Date.now());
          if (!unchanged(current, original)) { detail.result = temporary ? 'failed' : 'skipped'; detail.reason = 'route-changed'; break; }
          if((epochs.get(tab.id)||0)!==requestEpoch){detail.result='skipped';detail.reason='document-changed';break;}
          const currentVersion = receipt?.version === browser.runtime.getManifest().version;
          const legacy = !temporary && !reloaded && /^0\.4\.2[4-9]$/.test(receipt?.version || '');
          if ((currentVersion || legacy) && pageId(receipt.url) === group.key && receipt.id === group.key) {
            lastReceipt = receipt;
            detail.transport.responses++; detail.lastResponseAtMs = Date.now() - collectionStartedAt;
            detail.receiver = 'responded';
            detail.observation = { initialized: receipt.initialized === true, noData: receipt.noData === true,
              stateConflict: receipt.stateConflict === true, storedRevision: Number.isSafeInteger(receipt.storedRevision) ? receipt.storedRevision : null,
              version: typeof receipt.version === 'string' && /^\d+\.\d+\.\d+$/.test(receipt.version) ? receipt.version : null,
              phase: ['complete','generating','awaiting_permission','unknown'].includes(receipt.replyState?.phase) ? receipt.replyState.phase : null,
              revision: Number.isSafeInteger(receipt.replyState?.revision) ? receipt.replyState.revision : null,
              ...D.refreshObservation(receipt.diagnostic) };
            const stage = detail.observation.stage || (receipt.noData ? 'no-data' : 'observing');
            note(stage);
            advance(JSON.stringify([stage, receipt.replyState?.messageId, receipt.replyState?.phase,
              receipt.progress?.resources, receipt.progress?.lastResourceAt]));
            // Compatible collectors still prove this request, document and acknowledged revision.
            const modern=/^0\.4\.(?:2[4-9]|[3-9][0-9])$/.test(receipt.version);
            const packetValid=modern&&receipt.requestId===requestId&&Boolean(receipt.documentId)&&Number.isSafeInteger(receipt.routeEpoch)&&
              Number.isSafeInteger(receipt.sampledAt)&&receipt.sampledAt>=sentAt&&receipt.sampledAt<=Date.now();
            if(modern&&packetValid){
              if(documentToken&&(receipt.documentId!==documentToken||receipt.routeEpoch!==routeToken)){detail.reason='document-changed';detail.result='skipped';break;}
              documentToken=receipt.documentId;routeToken=receipt.routeEpoch;
            }
            let confirmed = packetValid && (receipt.requestId == null || receipt.requestId === requestId) && receipt.initialized === true && stage !== 'candidate' && !receipt.noData && !receipt.stateConflict;
            if (confirmed) {
              const { state } = await bounded(() => repository.dispatch('load'), end - Date.now());
              const saved = state.bookmarks.find(b => b.id === group.key)?.replyState, observed = receipt.replyState;
              confirmed = Boolean(saved && observed && Number.isSafeInteger(observed.revision) &&
                ['author','phase','revision'].every(key => saved[key] === observed[key]) &&
                ['messageId','userMessageId'].every(key => modern?(saved[key]??null)===(observed[key]??null):observed[key]==null||saved[key]===observed[key]) &&
                receipt.storedRevision === saved.revision);
              detail.storageVerified = confirmed;
            }
            if (confirmed && current.status !== 'loading') {
              const verifiedTab = await bounded(() => browser.tabs.get(tab.id), end - Date.now());
              if (!unchanged(verifiedTab, original)||(epochs.get(tab.id)||0)!==requestEpoch) { detail.result = temporary ? 'failed' : 'skipped'; detail.reason = 'route-changed'; break; }
              if (verifiedTab.status === 'loading') { await pause(pollMs); continue; }
              {
                const state = receipt.replyState;
                // A hydrated user message is not proof that the subsequent assistant reply
                // has mounted. A cold page may first render the prompt and only later its answer.
                if (state?.author === 'user' || state?.phase === 'unknown' ||
                    !['assistant', 'tool'].includes(state?.author) ||
                    !['generating', 'complete', 'awaiting_permission'].includes(state?.phase)) {
                  note(state?.author === 'user' ? 'awaiting-assistant-hydration' : 'no-data');
                  verifiedTailKey = ''; verifiedTailAt = 0;
                  await pause(pollMs); continue;
                }
                // A confirmed historical assistant can precede a later turn during async
                // history hydration. Require the same verified tail across a quiet window,
                // including resource activity, before closing the temporary document.
                const tailKey = JSON.stringify([state.author, state.phase, state.messageId,
                  state.userMessageId, state.revision, receipt.progress?.resources,
                  receipt.progress?.lastResourceAt]);
                if (tailKey !== verifiedTailKey) { verifiedTailKey = tailKey; verifiedTailAt = Date.now(); }
                if (Date.now() - loadedAt < settleMs || Date.now() - verifiedTailAt < stableMs) {
                  note('settling-reply-hydration');
                  await pause(pollMs); continue;
                }
              }
              if(!await confirmReceipt(ticket,{receipt,requestId,sentAt,collectorTabId:tab.id})){detail.reason='receipt-invalidated';detail.result='skipped';break;}
              detail.result = 'success'; detail.reason = temporary ? 'loaded' : reloaded ? 'reloaded' : 'rescanned';
              detail.verification = 'verified-dom';
              detail.method ||= 'load';
              break;
            }
          } else if (!temporary && !reloaded) {
            detail.result = 'skipped'; detail.reason = typeof receipt?.version === 'string' && !currentVersion ? 'receiver-version-mismatch' : 'receiver-unavailable-or-unsafe-reload'; break;
          }
          await pause(pollMs);
        } while (Date.now() < end);
        if (detail.reason === 'initialization-timeout' && lastReceipt?.replyState?.author === 'user') {
          detail.result = 'skipped'; detail.reason = 'assistant-not-hydrated';
        } else if (detail.reason === 'initialization-timeout' && lastReceipt?.stateConflict === true) {
          detail.result = 'skipped'; detail.reason = 'state-conflict';
        } else if (detail.reason === 'initialization-timeout' && lastReceipt?.noData === true) {
          detail.result = 'skipped'; detail.reason = 'no-data';
        } else if (detail.reason === 'initialization-timeout' && detail.observation?.result?.endsWith(':stale-observation-rejected')) {
          detail.result = 'skipped'; detail.reason = 'state-conflict';
        }
        detail.budgetMs = end - collectionStartedAt;

      } catch (error) { detail.result = 'failed'; detail.reason = error?.message === 'timeout' ? 'initialization-timeout' : 'tab-operation-failed'; }
      finally {
        // An unresponsive old document may contain a draft. Collect in an owned background page.
        if (!temporary && !existing && !isolated && detail.result !== 'success' &&
            ['receiver-unavailable-or-unsafe-reload', 'receiver-version-mismatch', 'no-data', 'state-conflict', 'initialization-timeout', 'tab-operation-failed'].includes(detail.reason)) {
          const current=await bounded(()=>browser.tabs.query({}));
          const safe=context.sources.every(source=>current.some(t=>unchanged(t,source))&&(epochs.get(source.id)||0)===source.epoch&&!interacted.has(source.id))&&!focusChanged;
          if(!safe){detail.reason='source-changed';detail.result='skipped';}
          else {
          const source = { ...detail };
          const fallback = await web(group, windowId, null, true,context);
          Object.assign(detail, fallback, { originalTabId: source.originalTabId, method: 'isolated-rescan', source });
          }
        }
        if (detail.reason === 'initialization-timeout' && (detail.observation?.stateConflict || detail.observation?.noData)) {
          detail.result = 'skipped'; detail.reason = detail.observation.stateConflict ? 'state-conflict' : 'no-data';
        }
        if (detail.result !== 'success') detail.verification = group.bookmarks.some(b => b.replyState) ? 'saved-unverified' : 'unknown';
        endConfirmation(ticket);
        await cleanup(detail); detail.elapsedMs = Date.now() - startedAt; await checkpoint(group, detail);
      }
      return detail;
    }
    const home = value => {try{const u=new URL(value);return u.origin==='https://chatgpt.com'&&u.pathname==='/'&&!u.hash.startsWith('#settings')&&!u.username&&!u.password;}catch{return false;}};
    async function dotsWeb(group,windowId){
      const detail={originalTabId:null,createdTabId:null,cleanup:'not-created',result:'failed',reason:'initialization-timeout',scope:'entry-unread'};
      const startedAt=Date.now();let original, previousDocument=null;
      const safeTab=tab=>tab&&tab.windowId===windowId&&home(tab.pendingUrl||tab.url)&&(owned.has(tab.id)||!isOtherTemporary(tab));
      try{
        if(!Number.isInteger(windowId)||windowId<0){detail.reason='window-unavailable';return detail;}
        const tabs=await bounded(()=>browser.tabs.query({windowId}));
        for(const candidate of tabs.filter(t=>safeTab(t)&&!t.active&&!t.discarded&&!t.frozen&&t.status!=='loading'&&!owned.has(t.id)&&
          !/#workbench-refresh-[a-z0-9-]+$/.test(t.pendingUrl||t.url)).sort((a,b)=>a.id-b.id)){
          let receipt;try{receipt=await message(candidate.id,{channel:CHANNEL,action:'version'},timeoutMs);}catch{continue;}
          if(receipt?.version!==browser.runtime.getManifest().version||!receipt.documentId||!home(receipt.url)||receipt.safeToReload!==true)continue;
          const current=await bounded(()=>browser.tabs.get(candidate.id));
          if(!safeTab(current)||current.active||current.status==='loading')continue;
          original=current;previousDocument=receipt.documentId;detail.originalTabId=current.id;
          await bounded(()=>browser.tabs.reload(current.id));break;
        }
        if(!original){
          if(temporaryCount>=4){detail.reason='temporary-capacity-exhausted';detail.result='skipped';return detail;}
          temporaryCount++;
          const marker=`#workbench-refresh-${journal.runId}-${journal.nextTemporary++}`;
          journal.intents.push({marker,ids:['dots:home'],scope:'entry-unread',windowId});await persist();
          try{original=await browser.tabs.create({url:'https://chatgpt.com/'+marker,windowId,active:false});}
          catch(error){temporaryCount--;throw error;}
          if(!Number.isInteger(original?.id)){temporaryCount--;throw Error('create-failed');}
          detail.createdTabId=original.id;owned.add(original.id);
          leases.set(original.id,{tabId:original.id,windowId:original.windowId,marker,adopted:false,scope:'entry-unread'});
          journal.intents=journal.intents.filter(i=>i.marker!==marker);
          await checkpoint(group,{...detail,result:'pending'});
        }
        const end=Date.now()+timeoutMs;let requestSequence=0,documentToken=null;
        while(Date.now()<end){
          let tab=await bounded(()=>browser.tabs.get(original.id),end-Date.now());
          if(adopted.has(tab.id)){detail.result='skipped';detail.reason='temporary-adopted';break;}
          if(!safeTab(tab)){detail.reason='route-changed';break;}
          if(tab.status==='loading'){await pause(pollMs);continue;}
          let version;
          try{version=await message(tab.id,{channel:CHANNEL,action:'version'},end-Date.now());}catch{await pause(pollMs);continue;}
          if(version?.version!==browser.runtime.getManifest().version||!version.documentId||version.documentId===previousDocument||!home(version.url)){await pause(pollMs);continue;}
          if(documentToken&&documentToken!==version.documentId){detail.reason='document-changed';break;}
          documentToken=version.documentId;
          const requestId=`${journal.runId}:dots:${++requestSequence}`,sentAt=Date.now();
          reserveDots(tab,{requestId,documentId:documentToken,sentAt,expiresAt:end});
          let receipt;try{receipt=await message(tab.id,{channel:CHANNEL,action:'rescan',id:'dots:home',requestId,temporary:detail.createdTabId!==null},end-Date.now());}
          catch{detail.reason='receiver-timeout';await pause(pollMs);continue;}
          tab=await bounded(()=>browser.tabs.get(original.id),end-Date.now());
          if(!safeTab(tab)||adopted.has(tab.id)){detail.reason=adopted.has(tab.id)?'temporary-adopted':'route-changed';break;}
          const valid=receipt?.requestId===requestId&&receipt.id==='dots:home'&&receipt.version===version.version&&receipt.documentId===documentToken&&
            home(receipt.url)&&receipt.url===tab.url&&Number.isSafeInteger(receipt.sampledAt)&&receipt.sampledAt>=sentAt&&receipt.sampledAt<=Date.now()&&
            receipt.initialized===true&&receipt.submitted===true&&Number.isSafeInteger(receipt.unread)&&receipt.unread>=0;
          const currentDocument=valid?await message(tab.id,{channel:CHANNEL,action:'version'},end-Date.now()):null;
          if(valid&&currentDocument?.documentId===documentToken&&currentDocument.url===tab.url&&await commitDots(tab,receipt,windowId)){
            Object.assign(detail,{result:'success',reason:'unread-sampled',unread:receipt.unread,unreadAvailable:true,sampledAt:receipt.sampledAt,
              documentId:documentToken,verification:'verified-unread',storageVerified:true,receiver:'responded'});break;
          }
          detail.receiver='responded';detail.reason=receipt?.noData?'no-data':'unverified-unread';
          await pause(pollMs);
        }
      }catch(error){detail.reason=error?.message==='timeout'?'initialization-timeout':'tab-operation-failed';}
      finally{if(original)cancelDots(original.id);await cleanup(detail);detail.elapsedMs=Date.now()-startedAt;await checkpoint(group,detail);}
      return detail;
    }
    async function run({ scope = 'all', windowId } = {}) {
      if (scope !== 'all') throw Error('刷新范围无效。');
      if (running) return { busy: true };
      interacted.clear();reloading.clear();epochs.clear();focusChanged=false;
      const listeners=[[browser.tabs.onActivated,activated],[browser.tabs.onUpdated,updated],[browser.tabs.onDetached,moved],[browser.tabs.onAttached,moved],[browser.windows?.onFocusChanged,focused]];
      for(const [event,fn] of listeners)event?.addListener(fn);
      const pendingRecovery = recover();
      running = true;
      temporaryCount = 0;
      adopted.clear(); removed.clear();
      browser.tabs.onRemoved?.addListener(tabRemoved);
      try {
        await pendingRecovery;
        const { state } = await bounded(() => repository.dispatch('load'));
        const aliases=state.bookmarks.filter(b=>b.kind==='dots').map(b=>b.id);
        const targets=state.bookmarks.filter(b=>b.kind!=='dots');
        if(aliases.length)targets.push({id:'dots:home',kind:'dots',url:'https://chatgpt.com/',aliases});
        if (journal?.leases?.length) throw Error('cleanup-pending');
        leases.clear();
        journal = { schema: 1, runId: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`, startedAt: Date.now(),
          status: 'running', nextTemporary: 0, intents: [], leases: [], total:targets.length,details: targets.map(b => ({ id: b.id, kind: b.kind, ...(b.aliases?{aliases:b.aliases}:{}),
            originalTabId: null, createdTabId: null, result: 'pending', reason: 'queued', cleanup: 'not-created' })) };
        await persist();
        await browser.storage.session?.set?.({ [JOURNAL]: { runId: journal.runId } });
        const groups = new Map(), details = new Map();
        for (const bookmark of targets.filter(b => b.kind !== 'codex')) {
          if(bookmark.kind==='dots'){groups.set('dots:home',{key:'dots:home',bookmarks:[bookmark]});continue;}
          const key = pageId(bookmark.url);
          if (!key) { details.set(bookmark.id, { result: 'skipped', reason: 'unsupported', originalTabId: null, createdTabId: null }); continue; }
          if (!groups.has(key)) groups.set(key, { key, url: bookmark.url, bookmarks: [] });
          groups.get(key).bookmarks.push(bookmark);
        }
        const native = (async () => {
          const bookmarks = state.bookmarks.filter(b => b.kind === 'codex');
          if (!bookmarks.length) return;
          let snapshot;
          try { snapshot = await bounded(() => codexStatus.refresh()); } catch { /* Count a disconnected host as failed. */ }
          for (const b of bookmarks) {
            const item = snapshot?.threads?.find(t => `codex:${t.threadId}` === b.id);
            const result = !snapshot?.connected ? 'failed' : !item?.author || item.phase === 'unknown' ? 'skipped' : 'success';
            details.set(b.id, { originalTabId: null, createdTabId: null, result, reason: result === 'success' ? 'native-reread' : !snapshot?.connected ? 'native-disconnected' : !item ? 'native-thread-missing' : 'native-state-unknown', cleanup: 'not-created' });
          }
          for (const b of bookmarks) await checkpoint({ bookmarks: [b] }, details.get(b.id));
        })();
        const queue = [...groups.values()];
        const settled = await Promise.allSettled([native, ...Array.from({ length: Math.min(4, queue.length) }, async () => {
          while (queue.length) {
            const group = queue.shift(), detail = await (group.key==='dots:home'?dotsWeb(group,windowId):web(group, windowId));
            for (const b of group.bookmarks) details.set(b.id, detail);
          }
        })]);
        const rejected = settled.find(item => item.status === 'rejected');
        if (rejected) throw rejected.reason;
        const cleanup = { created: 0, closed: 0, retained: 0, failed: 0, leakedTabIds: [] };
        const created = new Map([...details.values()].filter(d => Number.isInteger(d.createdTabId)).map(d => [d.createdTabId, d]));
        for (const [id, detail] of created) {
          cleanup.created++; cleanup[detail.cleanup]++;
          if (detail.cleanup === 'failed') cleanup.leakedTabIds.push(id);
        }
        const result = { total:targets.length,success: 0, failed: 0, skipped: 0, cleanup, details: targets.map(b => ({ id: b.id, kind: b.kind, ...(b.aliases?{aliases:b.aliases}:{}),...details.get(b.id) })) };
        for (const detail of result.details) result[detail.result]++;
        journal = { ...journal, ...result, status: 'complete', completedAt: Date.now(), leases: [...leases.values()], intents: [] };
        await persist();
        return result;
      } finally {
        browser.tabs.onRemoved?.removeListener?.(tabRemoved);
        for(const [event,fn] of listeners)event?.removeListener?.(fn);
        adopted.clear(); removed.clear(); running = false;
      }
    }
    return { run, recover, adopt, isTemporary: tab => !adopted.has(tab.id) && !leases.get(tab.id)?.adopted &&
      (owned.has(tab.id) || leases.has(tab.id) || Boolean(journal?.intents?.some(intent => (tab.pendingUrl || tab.url)?.endsWith(intent.marker)))) };
  }
  const api = { CHANNEL, JOURNAL, pageId, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkSessionRefresh = api;
})(globalThis);
