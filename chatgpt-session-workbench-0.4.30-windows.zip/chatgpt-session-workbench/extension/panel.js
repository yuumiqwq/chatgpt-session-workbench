'use strict';
(() => {
  const M = globalThis.BookmarkModel;
  const Dots = globalThis.BookmarkDots;
  const PANEL_VERSION = '0.4.30';
  const CodexStatus = globalThis.BookmarkCodexStatus;
  const $ = id => document.getElementById(id);
  const live = Boolean(globalThis.chrome?.runtime?.id && chrome.runtime.sendMessage && chrome.storage?.local);
  const onCreated = async (tab, createdURL) => {
    const result = await chrome.runtime.sendMessage({ channel: 'session-bookmarks', action: 'group-created-tab', payload: { tabId: tab.id, createdURL } });
    if (!result?.ok) throw Error('自动分组失败。');
  };
  const openChat = globalThis.BookmarkNavigation.createNavigator(globalThis.chrome, { onCreated });
  const closeChat = globalThis.BookmarkNavigation.createCloser(globalThis.chrome);
  let state = M.emptyState();
  let markerRenderAt = 0;
  let receiverRecords = [], receiverTimer, receiverReading = false, receiverAgain = false;
  function receiverState(b) {
    if (b.kind !== 'chatgpt' || !tabState.openIds.has(b.id)) return 'available';
    const records = receiverRecords.filter(r => r.id === b.id);
    if (!records.length) return 'checking';
    // A witnessed new turn awaiting storage acknowledgement vetoes other tabs'
    // matching but older confirmations. A transport failure alone has no veto.
    const matching = r => r.confirmed && ['author','phase','revision','messageId','userMessageId'].every(key => (r.confirmed[key] ?? null) === (b.replyState?.[key] ?? null));
    const superseded=r=>records.some(c=>['temporary-page','manual-receipt'].includes(c.source)&&matching(c)&&c.supersedes?.some(s=>s.tabId===r.tabId&&
      ['author','phase','messageId','userMessageId'].every(k=>(s.observed?.[k]??null)===(r.invalidation?.observed?.[k]??null))));
    if (records.some(r => !superseded(r) && r.invalidation?.revision === b.replyState?.revision && r.invalidation?.observed &&
      ['author','phase','messageId','userMessageId'].some(key => (r.invalidation.observed[key] ?? null) !== (b.replyState?.[key] ?? null)))) return 'checking';
    if (records.some(r => ['available','checking'].includes(r.status) && matching(r))) return 'available';
    if (records.some(r => ['unavailable','recovering','suspended'].includes(r.status))) return 'unavailable';
    return 'checking';
  }
  function newReplyEvidence(b) {
    if (b.kind !== 'chatgpt') return false;
    const saved = b.replyState, records = receiverRecords.filter(r => r.id === b.id);
    return records.some(r => {
      const observed = r.invalidation?.observed;
      if (!observed || r.invalidation.revision !== saved?.revision) return false;
      const superseded = records.some(c => ['temporary-page','manual-receipt'].includes(c.source) && c.confirmed &&
        ['author','phase','revision','messageId','userMessageId'].every(k => (c.confirmed[k] ?? null) === (saved?.[k] ?? null)) &&
        c.supersedes?.some(s => s.tabId === r.tabId && ['author','phase','messageId','userMessageId'].every(k => (s.observed?.[k] ?? null) === (observed[k] ?? null))));
      return !superseded && (observed.userMessageId && observed.userMessageId !== saved?.userMessageId ||
        observed.phase === 'awaiting_permission' && saved?.phase !== 'awaiting_permission' ||
        observed.phase === 'generating' && observed.prior && saved?.phase === 'complete' &&
        ['author','phase','revision','messageId','userMessageId'].every(k => (observed.prior[k] ?? null) === (saved[k] ?? null)));
    });
  }
  const unavailable = b => receiverState(b) !== 'available';
  function paintReceiverStates() {
    markerRenderAt = Date.now();
    for (const b of state.bookmarks.filter(b => b.kind === 'chatgpt')) {
      const link = document.querySelector('[data-bookmark-id="' + b.id + '"]')?.querySelector('.bookmark-link');
      if (!link) continue;
      const next = bookmarkLink(b, '');
      link.title = next.title;
      link.querySelector('.source-icon').replaceChildren(...next.querySelector('.source-icon').childNodes);
    }
    const displayed = CodexStatus ? CodexStatus.applyToState(state, codexSnapshot) : state;
    const counts = M.replyCounts({ ...displayed, bookmarks: displayed.bookmarks.filter(b => !newReplyEvidence(b)) });
    for (const category of state.categories) {
      const button = document.querySelector('[data-focus-key="category:' + category.id + '"]');
      if (!button) continue;
      const value = counts.get(category.id) || 0, old = button.querySelector('.reply-count');
      if (value) {
        const count = old || element('span', 'reply-count'); count.textContent = String(value);
        count.title = value + ' 个会话待你回复'; count.setAttribute('aria-label', count.title);
        if (!old) button.append(count);
      } else old?.remove();
      button.title = value + ' 个会话待你回复';
    }
  }
  async function refreshReceivers() {
    if (!live || codexClosed || document.hidden) return;
    if (receiverReading) { receiverAgain = true; return; }
    receiverReading = true;
    try {
      const result = await call('receiver-status');
      const before = state.bookmarks.map(b => newReplyEvidence(b));
      receiverRecords = result.records || [];
      if (before.some((value, index) => value !== newReplyEvidence(state.bookmarks[index]))) paintReceiverStates();
    } catch {
      // A failed panel request is not evidence that the page receiver has failed.
    } finally {
      const again = receiverAgain; receiverAgain = false;
      receiverReading = false; clearTimeout(receiverTimer);
      if (!codexClosed) receiverTimer = setTimeout(refreshReceivers, again ? 0 : 2000);
    }
  }
  let archive = [], archiveRevision, archiveLoaded = false, archiveRequest = 0;
  let archiveResults = [], archiveWindow = null, archiveRange = '', archiveGeneration = 0, archiveRenderKey = '', searchTimer;
  const archiveEstimatedHeight = 56;
  let archiveRenderPending = false;
  let selected = 'all';
  let selectionRevision = 0;
  let selectionLoaded = false;
  const panelContext = live ? globalThis.BookmarkNavigation.createPanelContext(chrome, {
    onCreated, onReady: () => { void refreshDots(); }, isVisible: () => !document.hidden
  }) : null;
  const canCreateChat = live && typeof chrome.tabs?.create === 'function';
  let creatingChat = false;
  let codexSnapshot = CodexStatus?.emptySnapshot();
  let codexReading = null, codexTimer = null, codexClosed = false;
  let codexEpoch = 0, codexExpiry = null;
  let dotsSnapshot = { eligible: false };
  let dotsSequence = 0;
  let dotsReading = null, dotsAgain = false, panelWindowId = null;
  let openingDots = false;
  let currentId = null;
  let currentSequence = 0;
  let capturing = false;
  const preferences = live ? globalThis.BookmarkPreferences.createSelectionStore(chrome.storage.local) : null;
  let tabState = { openIds: new Set(), openOrder: new Map(), activeId: null };
  let ready = false;
  let renderedState = '';
  let blocked = false;
  let staleWorker = false;
  let saving = false;
  let onSave = null;
  let onDelete = null;
  let focusBeforeDialog = null;
  let requestNumber = 0;
  let inlineSaving = false;
  let dragging = null;
  let listOrder = [];
  let suppressClickUntil = 0;
  let menuCategory = null;
  let menuProject = null;
  const dialog = $('editor');
  const fields = $('dialog-fields');
  let retainedError = false;
  let tutorialView = null, tutorialSearchBeforePreview = null, dotsTourConfirmed = null, dotsTourConfirming = null;
  const status = (message = '', error = false, retain = false) => {
    retainedError = error && retain;
    property($('status'), 'textContent', error ? message : ''); toggle($('status'), 'error', error);
  };
  const tutorial = globalThis.BookmarkTutorial.createTour({ document, window, onError: message => status(message, true),
    onDotsShown: async runId => {
      if (!live || dotsTourConfirmed === runId || dotsTourConfirming === runId) return;
      dotsTourConfirming = runId;
      try {
        const windowId = await panelContext.getWindowId();
        if (document.hidden || !$('tutorial').open || tutorialView?.runId !== runId || tutorialView?.id !== 'dots') return;
        const result = await call('dots-guide-shown', { windowId, runId });
        if (result.shown) { dotsGuideClaim = null; dotsTourConfirmed = runId; }
      } catch { /* The next visible tutorial sync can retry the same run. */ }
      finally { if (dotsTourConfirming === runId) dotsTourConfirming = null; }
    },
    onView: view => {
      if (tutorialView?.id === view?.id) return;
      const preview = ['organize', 'close'].includes(view?.id);
      const wasPreview = ['organize', 'close'].includes(tutorialView?.id);
      if (preview && !wasPreview) {
        tutorialSearchBeforePreview = $('search').value;
        $('search').value = '';
        $('bookmark-list').scrollTop = 0;
      } else if (!preview && wasPreview) {
        $('search').value = tutorialSearchBeforePreview ?? '';
        tutorialSearchBeforePreview = null;
      }
      tutorialView = view; render();
      if (!view && !codexClosed) queueMicrotask(() => { maybeShowDotsGuide(); });
    },
    request: async (action, payload) => live ? chrome.runtime.sendMessage({ channel: 'session-bookmarks', action,
      payload: { ...payload, windowId: await panelContext.getWindowId() } }) : { ok: true, show: false }
  });
  let tutorialReady = false, tutorialSynced = false, dotsGuideClaim = null, dotsGuideCheck = 0;
  const dotsGuide = globalThis.BookmarkTutorial.createDotsGuide({ document, window, onShown: async token => {
    const result = await call('dots-guide-shown', { token, windowId: await panelContext.getWindowId() });
    if (result.shown && dotsGuideClaim?.token === token) dotsGuideClaim = null;
    return result;
  } });
  const dotsGuideBlocked = () => !tutorialReady || !tutorialSynced || tutorial.busy || codexClosed || document.hidden || !dotsSnapshot.eligible ||
    !dotsGuideClaim?.show || $('tutorial').open || ['settings', 'statistics', 'editor'].some(id => $(id)?.open);
  async function maybeShowDotsGuide() {
    if (dotsGuideBlocked()) return;
    const ticket = ++dotsGuideCheck, claim = dotsGuideClaim;
    let stored;
    try { stored = await chrome.storage.local.get([BookmarkOnboarding.KEY, BookmarkDotsGuide.KEY]); } catch { return; }
    if (ticket !== dotsGuideCheck || claim !== dotsGuideClaim || dotsGuideBlocked()) return;
    // A main tour handed off to a webpage has no open panel dialog, but still owns the walkthrough.
    if (['pending', 'active'].includes(stored[BookmarkOnboarding.KEY]?.status)) return;
    const current = stored[BookmarkDotsGuide.KEY];
    if (current?.status === 'shown') { dotsGuideClaim = null; return; }
    if (current?.token !== claim.token) { dotsGuideClaim = null; void refreshDots(); return; }
    if (dotsGuideClaim.expiresAt <= Date.now() + BookmarkDotsGuide.DISPLAY_MARGIN_MS) {
      dotsGuideClaim = null; void refreshDots(); return;
    }
    dotsGuide.present(dotsGuideClaim.token);
  }
  const syncTutorial = () => {
    if (tutorialReady && !document.hidden) void tutorial.sync().then(() => {
      tutorialSynced = true; maybeShowDotsGuide();
    }).catch(() => {});
  };
  function saveSelection() {
    if (preferences) void preferences.save(selected).catch(error => status(`筛选保存失败：${error.message}`, true));
  }
  function selectCategory(id) {
    if (selected !== id) $('bookmark-list').scrollTop = 0;
    selected = id; selectionRevision++; saveSelection(); render();
    if (selected === M.REMOVED) void refreshArchive();
  }
  async function refreshArchive() {
    if (!live || selected !== M.REMOVED || archiveLoaded && archiveRevision === state.archiveRevision) return;
    const request = ++archiveRequest;
    try {
      const result = await call('archive-load');
      if (request !== archiveRequest) return;
      archive = result.archive; archiveRevision = result.archiveRevision || undefined; archiveLoaded = true; archiveGeneration++;
      if (result.rejected) status(`有 ${result.rejected} 条无效归档记录。`, true);
      if (selected === M.REMOVED) render();
    } catch (error) { status(error.message, true); }
  }
  function paintCurrentButton() {
    const saved = currentId !== null && state.bookmarks.some(b => b.id === currentId);
    const button = $('add-current');
    property(button, 'disabled', !live || !ready || !selectionLoaded || blocked || capturing);
    attribute(button, 'aria-disabled', String(saved || button.disabled));
    property(button, 'title', saved ? '此页面已收藏' : '收藏当前对话');
    attribute(button, 'aria-label', button.title);
    toggle(button, 'bookmarked', saved);
  }
  function property(node, key, value) { if (node[key] !== value) node[key] = value; }
  function attribute(node, key, value) {
    if (node.getAttribute(key) === value) return;
    if (value === null) node.removeAttribute(key); else node.setAttribute(key, value);
  }
  function toggle(node, name, value) { if (node.classList.contains(name) !== Boolean(value)) node.classList.toggle(name, Boolean(value)); }
  const dotsActive = () => tabState.windowActiveIds?.get(panelWindowId) === 'dots:home';
  function paintDots() {
    const eligible = Boolean(live && dotsSnapshot.eligible);
    const add = $('add-dots'), open = $('open-dots'), count = $('dots-unread');
    property(add, 'hidden', !eligible); property(open, 'hidden', !eligible);
    property(add, 'disabled', !eligible || !ready || blocked);
    property(open, 'disabled', !eligible);
    toggle(add.parentElement, 'has-dots', eligible);
    toggle(open.parentElement, 'has-dots', eligible);
    toggle(open, 'tab-open', tabState.openIds.has('dots:home'));
    toggle(open, 'tab-active', dotsActive());
    attribute(open, 'aria-current', dotsActive() ? 'page' : null);
    const name = 'Dots';
    property($('add-dots-label'), 'textContent', `添加 ${name}`);
    property(add, 'title', ''); attribute(add, 'title', ''); attribute(add, 'aria-label', `添加 ${name}`);
    const unread = eligible ? dotsSnapshot.unread : null;
    property(count, 'textContent', Dots.badge(unread)); property(count, 'hidden', !count.textContent);
    property(open, 'title', unread > 0 ? `${unread}条消息未读` : `打开 ${name}`);
    attribute(open, 'aria-label', open.title);
  }
  async function refreshDots() {
    const sequence = ++dotsSequence;
    if (!live || document.hidden) return;
    if (dotsReading) { dotsAgain = true; return dotsReading; }
    dotsReading = (async () => {
      try {
        const windowId = await dotsWait(panelContext.getWindowId(), 1000);
        const result = await dotsWait(call('dots-get', { windowId }), 2000);
        // Loading a new document is not evidence that an existing entry disappeared.
        if (sequence === dotsSequence && !result.snapshot?.pending) {
          dotsSnapshot = result.snapshot || { eligible: false };
          $('dots-pro').checked = dotsSnapshot.eligible;
          dotsGuideClaim = result.guide?.show ? result.guide : null;
          if (!dotsSnapshot.eligible) { dotsGuideClaim = null; dotsGuide.hide(); }
          paintDots(); maybeShowDotsGuide();
        }
      } catch { /* A transport failure leaves the last confirmed UI intact; actions revalidate. */ }
    })().finally(() => {
      dotsReading = null;
      if (dotsAgain) { dotsAgain = false; void refreshDots(); }
    });
    return dotsReading;
  }
  async function refreshCodex() {
    clearTimeout(codexTimer);
    // Native transport belongs to the background service; panels only need messaging.
    if (!live || !CodexStatus || codexClosed || document.hidden || !ready) return;
    if (codexReading) return codexReading;
    const epoch = codexEpoch;
    codexReading = (async () => {
      let snapshot = CodexStatus.emptySnapshot();
      try {
        if (state.bookmarks.some(item => item.kind === 'codex')) snapshot = (await call('codex-status')).snapshot || snapshot;
      } catch { /* A missing companion leaves the other workbench features available. */ }
      if (codexClosed || document.hidden || dragging || epoch !== codexEpoch) return;
      clearTimeout(codexExpiry);
      if (CodexStatus.isFresh(snapshot)) codexExpiry = setTimeout(() => {
        codexEpoch++; codexSnapshot = CodexStatus.emptySnapshot(); render();
      }, Math.max(0, snapshot.observedAt + CodexStatus.MAX_AGE - Date.now()));
      const changed = JSON.stringify({ ...snapshot, observedAt: undefined }) !==
        JSON.stringify({ ...codexSnapshot, observedAt: undefined });
      codexSnapshot = snapshot;
      if (changed) render();
    })().finally(() => {
      codexReading = null;
      if (!codexClosed && !document.hidden && state.bookmarks.some(item => item.kind === 'codex')) codexTimer = setTimeout(refreshCodex, 2000);
    });
    return codexReading;
  }
  async function dotsWait(work, timeoutMs) {
    let timer;
    try { return await Promise.race([work, new Promise((_, reject) => { timer = setTimeout(() => reject(Error('操作超时，请重试。')), timeoutMs); })]); }
    finally { clearTimeout(timer); }
  }
  async function openDots(id, archiveId) {
    if (!live || openingDots) return;
    const snapshot = dotsSnapshot, task = {};
    openingDots = task;
    try {
      const windowId = await dotsWait(panelContext.getWindowId(), 1000);
      if (openingDots !== task) return;
      await dotsWait(call('dots-open', { windowId, deadline: Date.now() + 4000,
        ...(archiveId ? { archiveId } : id ? { id } : { binding: snapshot.binding }) }), 5000);
      if (openingDots === task) status();
    } catch (error) { if (openingDots === task) status(`打开 Dots 失败：${error.message}`, true); }
    finally { if (openingDots === task) { openingDots = null; void refreshDots(); } }
  }
  async function refreshCurrentButton() {
    const ticket = ++currentSequence;
    try {
      const tab = await panelContext.getActiveTab();
      const link = M.normalizeURL(tab?.pendingUrl || tab?.url);
      if (ticket === currentSequence) currentId = link.kind === 'chatgpt' ? link.id : null;
    } catch { if (ticket === currentSequence) currentId = null; }
    if (ticket === currentSequence) paintCurrentButton();
  }
  function paintTabStates() {
    tutorial.beforeRender();
    for (const row of $('bookmark-list').querySelectorAll('.bookmark')) {
      const bookmarkId = row.dataset.pageId || row.dataset.bookmarkId;
      if (!bookmarkId) continue;
      const id = globalThis.BookmarkNavigation.pageIdForBookmark(bookmarkId);
      const nativeActive = CodexStatus?.isActive(codexSnapshot, id);
      const active = (id === 'dots:home' ? dotsActive() : tabState.activeId === id) || nativeActive;
      toggle(row, 'tab-open', tabState.openIds.has(id) || nativeActive);
      toggle(row, 'tab-active', active);
      const close = row.querySelector('.close-tab');
      if (close) property(close, 'disabled', !tabState.openIds.has(id));
      const link = row.querySelector('.bookmark-link');
      attribute(link, 'aria-current', active ? 'page' : null);
    }
  }
  function sortTabStates() {
    tutorial.beforeRender();
    if (dragging || selected === M.REMOVED && !['organize', 'close'].includes(tutorialView?.id)) return;
    const list = $('bookmark-list');
    const active = document.activeElement;
    const scrollTop = list.scrollTop;
    function move(parent, items, first = parent.firstElementChild) {
      let next = first;
      for (const { node } of globalThis.BookmarkNavigation.sortByOpen(items, tabState.openOrder)) {
        if (node !== next) {
          // moveBefore preserves focus and element state; older Edge uses the same nodes with focus restored below.
          if (parent.moveBefore) parent.moveBefore(node, next);
          else parent.insertBefore(node, next);
        }
        next = node.nextElementSibling;
      }
    }
    for (const group of listOrder) {
      if (group.members) move(group.node, group.members, group.node.querySelector('legend').nextElementSibling);
    }
    move(list, listOrder);
    if (active?.isConnected && document.activeElement !== active) active.focus({ preventScroll: true });
    list.scrollTop = scrollTop;
    tutorial.position();
  }
  function icon(name) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'icon'); svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS(svg.namespaceURI, 'use');
    use.setAttribute('href', `#i-${name}`); svg.append(use); return svg;
  }
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function iconButton(name, title, callback) {
    const button = element('button', 'icon-button');
    button.type = 'button'; button.title = title; button.setAttribute('aria-label', title);
    button.append(icon(name)); button.addEventListener('click', callback); return button;
  }
  function bookmarkLink(b, category, archiveId) {
    const link = element(b.kind === 'dots' ? 'button' : 'a', `bookmark-link${b.kind === 'dots' ? ' dots-link' : ''}`);
    if (b.kind === 'dots') {
      link.type = 'button'; link.addEventListener('click', () => openDots(archiveId ? null : b.id, archiveId));
    } else link.href = b.url;
    const permission = !archiveId && !newReplyEvidence(b) && M.awaitingPermission(b), reply = !archiveId && !newReplyEvidence(b) && M.awaitingReply(b);
    link.title = b.kind === 'dots' ? '' : permission ? '等待权限确认' : reply ? '待你回复' :
      ['assistant', 'tool'].includes(b.replyState?.author) && b.replyState?.phase === 'generating' ? '工作中' : '';
    if (b.kind === 'chatgpt' || b.kind === 'demo') link.addEventListener('click', async event => {
      event.preventDefault();
      try {
        if (!live) throw new Error('请在 Edge 扩展侧栏中使用。');
        if (b.kind === 'demo') await chrome.tabs.create({ url: M.demoLink(b).url, active: true });
        else await openChat(b.url);
      } catch (error) { if (error.opened) status(); else status(`打开会话失败：${error.message}`, true); }
    });
    // Codex keeps the same native protocol link in both views.
    const sourceIcon = element('span', 'source-icon'); sourceIcon.append(icon(b.kind === 'dots' ? 'dots' : b.kind === 'codex' ? 'code' : 'chat'));
    if (permission || reply) {
      const marker = element('span', `reply-marker${permission ? ' permission-marker' : ''}`, permission ? '?' : '!');
      marker.title = ''; marker.setAttribute('aria-label', permission ? '等待权限确认' : '待你回复'); marker.setAttribute('role', 'img');
      sourceIcon.append(marker);
    }
    const source = b.kind === 'dots' ? archiveId ? 'Dots' : 'Dots 正在跟进' : b.kind === 'codex' ? 'Codex' : 'ChatGPT';
    const copy = element('span', 'bookmark-copy');
    copy.append(element('span', 'bookmark-title', b.title), element('span', 'bookmark-meta', `${source} · ${category}`));
    link.append(sourceIcon, copy); return link;
  }
  function appendCloseButton(row, b, focusKey) {
    if (b.kind !== 'chatgpt' && b.kind !== 'dots') return;
    const close = iconButton('close', '关闭标签页', async () => {
      close.disabled = true;
      try { await closeChat(b.url); }
      catch (error) { status(`关闭标签页失败：${error.message}`, true); }
      finally { close.disabled = !tabState.openIds.has(globalThis.BookmarkNavigation.pageIdForBookmark(b.id)); }
    });
    close.classList.add('close-tab'); close.dataset.focusKey = focusKey; row.append(close);
  }
  async function call(action, payload) {
    if (!live) throw new Error('请在 Edge 扩展侧栏中使用。');
    if (staleWorker && !['load', 'export', 'collect-diagnostics'].includes(action)) throw new Error('扩展需重新加载');
    const response = await chrome.runtime.sendMessage({ channel: 'session-bookmarks', action, payload });
    if (!response?.ok) throw new Error(response?.error || '操作失败，请重新打开侧栏。');
    return response;
  }
  function accept(result) {
    const parsed = M.normalizeState(result.state, { includeArchive: false });
    const { archive: incomingArchive, ...active } = parsed.state;
    state = active;
    if (incomingArchive !== undefined) {
      const checked = M.normalizeArchive(incomingArchive);
      archive = checked.archive; archiveRevision = state.archiveRevision; archiveLoaded = true; archiveGeneration++;
      parsed.rejected += checked.rejected;
    }
    staleWorker = result.state.version !== M.VERSION;
    const rejected = Math.max(result.rejected || 0, parsed.rejected);
    blocked = rejected > 0 || staleWorker;
    ready = true;
    if (selectionLoaded && !['all', 'unfiled', M.REMOVED].includes(selected) && !state.categories.some(p => p.id === selected)) {
      selected = 'all'; selectionRevision++; saveSelection();
    }
    if (renderedState !== renderKey()) { render(); void refreshCodex(); }
    if (selected === M.REMOVED) void refreshArchive();
    if (rejected) status(`有 ${rejected} 条无效记录。请导出备份修复后，选择替换导入。`, true);
    else if (staleWorker) status('扩展需重新加载', true);
    else if (!retainedError) status();
  }
  async function refresh() {
    const sequence = ++requestNumber;
    try { const result = await call('load', { activeOnly: true }); if (sequence === requestNumber) accept(result); }
    catch (error) { if (sequence === requestNumber) { ready = false; render(); status(error.message, true); } }
  }
  async function mutate(action, payload) {
    const sequence = ++requestNumber;
    const result = await call(action, payload);
    if (sequence === requestNumber) accept(result);
    else await refresh();
    if (!blocked) status();
    return result;
  }
  function renderKey() { return JSON.stringify([state, ready, blocked, staleWorker, selected, selectionLoaded]); }
  function render() {
    tutorial.beforeRender();
    renderedState = renderKey();
    const active = document.activeElement;
    const focusKey = active?.dataset.focusKey;
    const enabled = live && ready && !blocked;
    for (const id of ['add-codex', 'new-category']) $(id).disabled = !enabled;
    $('new-chat').disabled = !canCreateChat || creatingChat;
    paintCurrentButton();
    paintDots();
    panelContext?.setCategory(selectionLoaded && ready ? currentCategory() : null);
    $('export-button').disabled = !live;
    $('import-button').disabled = !live || staleWorker;
    const organizeStep = tutorialView?.id === 'organize';
    const closeStep = tutorialView?.id === 'close';
    const exampleView = organizeStep || closeStep;
    // Tutorial views present All without modifying the user's saved category/filter.
    const visibleCategory = exampleView ? 'all' : selected;
    const categories = $('category-list'); categories.replaceChildren();
    for (const id of ['all', 'unfiled', 'removed']) $('filter-' + id).setAttribute('aria-pressed', String(visibleCategory === (id === 'removed' ? M.REMOVED : id)));
    const rows = M.sortedCategories(state);
    const displayed = CodexStatus ? CodexStatus.applyToState(state, codexSnapshot) : state;
    markerRenderAt = Date.now();
    const pendingCounts = M.replyCounts({ ...displayed, bookmarks: displayed.bookmarks.filter(b => !newReplyEvidence(b)) });
    for (const p of rows) {
      const row = element('div', `category-row${visibleCategory === p.id ? ' active' : ''}`);
      row.dataset.categoryId = p.id;
      const button = element('button', 'category-button');
      button.dataset.focusKey = `category:${p.id}`;
      if (visibleCategory === p.id) button.setAttribute('aria-current', 'page');
      button.append(icon('folder'), element('span', 'category-name', p.name));
      const pending = pendingCounts.get(p.id) || 0;
      if (pending) {
        const count = element('span', 'reply-count', String(pending));
        count.title = `${pending} 个会话待你回复`; count.setAttribute('aria-label', count.title);
        button.append(count);
      }
      button.title = `${pending} 个会话待你回复`;
      button.setAttribute('aria-label', p.name);
      button.addEventListener('click', () => selectCategory(p.id));
      row.append(button);
      {
        const edit = iconButton('more', `编辑类别：${p.name}`, event => categoryMenu(p, event.currentTarget));
        edit.dataset.focusKey = `category-edit:${p.id}`; edit.disabled = !enabled; row.append(edit);
      }
      dragSource(row, 'category', p.id, enabled);
      dropTarget(row, p.id);
      categories.append(row);
    }
    const removed = visibleCategory === M.REMOVED;
    const archiveKey = `${archiveGeneration}:${$('search').value}`;
    const unchangedArchive = removed && archiveWindow && archiveRenderKey === archiveKey;
    const entries = unchangedArchive ? archiveResults :
      M.sortedBookmarks(removed ? { archive } : displayed, visibleCategory, exampleView ? '' : $('search').value);
    $('list-title').textContent = removed ? '已移除' : visibleCategory === 'unfiled' ? '未分类' : rows.find(p => p.id === visibleCategory)?.name || '全部收藏';
    $('list-count').textContent = entries.length;
    $('empty').hidden = entries.length !== 0;
    $('empty-text').textContent = $('search').value.trim() ? '没有匹配的收藏' : removed ? '暂无已移除的会话' : visibleCategory === 'all' ? '还没有收藏' : '此类别暂无收藏';
    if (unchangedArchive) { paintTabStates(); syncCategorySelect(); return; }
    const list = $('bookmark-list'), scrollTop = list.scrollTop;
    list.replaceChildren();
    toggle(list, 'archive-list', removed);
    listOrder = [];
    archiveWindow = null;
    if (removed) {
      archiveResults = entries; archiveRange = ''; archiveRenderKey = archiveKey;
      const window = element('div', 'archive-window');
      archiveWindow = { window, nodes: new Map(), heights: [], offsets: [0], width: null, gap: 4 };
      window.style.height = `${Math.max(0, entries.length * (archiveEstimatedHeight + 4) - 4)}px`;
      if (entries.length) list.append(window);
      list.scrollTop = scrollTop; renderArchiveWindow();
      if (focusKey) window.querySelector(`[data-focus-key="${focusKey}"]`)?.focus({ preventScroll: true });
      syncCategorySelect(); return;
    }
    const groups = new Map();
    const projectMembers = new Map();
    for (const b of state.bookmarks) {
      if (!b.projectId) continue;
      if (!projectMembers.has(b.projectId)) projectMembers.set(b.projectId, []);
      projectMembers.get(b.projectId).push(b);
    }
    for (const [baseIndex, b] of entries.entries()) {
      const row = element('article', 'bookmark');
      row.dataset.bookmarkId = b.id;
      dragSource(row, 'bookmark', b.id, enabled);
      sessionDropTarget(row, b.projectId ? 'project' : 'bookmark', b.projectId || b.id);
      const category = state.categories.find(p => p.id === b.categoryId)?.name || '未分类';
      const link = bookmarkLink(b, category); link.dataset.focusKey = `bookmark:${b.id}`; row.append(link);
      const edit = iconButton('more', `编辑收藏：${b.title}`, () => editBookmark(b));
      edit.title = `编辑：${b.title}`;
      edit.dataset.focusKey = `edit:${b.id}`; edit.disabled = !enabled; row.append(edit);
      appendCloseButton(row, b, `close:${b.id}`);
      const order = { node: row, baseIndex, bookmarkIds: [b.id], activityAt: M.conversationActivity(b) };
      if (b.projectId) {
        if (!groups.has(b.projectId)) {
          const project = state.projects.find(p => p.id === b.projectId);
          const group = element('fieldset', 'session-project'); group.dataset.projectId = project.id;
          const legend = element('legend');
          const heading = element('span', 'project-name', project.name); heading.title = '';
          const editProjectButton = iconButton('more', `编辑项目：${project.name}`, event => projectMenu(project, event.currentTarget));
          editProjectButton.dataset.focusKey = `project-edit:${project.id}`; editProjectButton.disabled = !enabled;
          legend.append(heading, editProjectButton); group.append(legend);
          sessionDropTarget(group, 'project', project.id);
          const members = projectMembers.get(project.id);
          const activity = members.map(M.conversationActivity).filter(time => time !== null);
          const groupOrder = { node: group, baseIndex, bookmarkIds: members.map(b => b.id), activityAt: activity.length ? Math.max(...activity) : null, members: [] };
          groups.set(project.id, groupOrder); listOrder.push(groupOrder); list.append(group);
        }
        groups.get(b.projectId).node.append(row);
        groups.get(b.projectId).members.push(order);
      } else { list.append(row); listOrder.push(order); }
    }
    syncCategorySelect();
    paintTabStates();
    sortTabStates();
    if (focusKey && !dialog.open) {
      const replacement = [...document.querySelectorAll('[data-focus-key]')].find(n => n.dataset.focusKey === focusKey);
      replacement?.focus({ preventScroll: true });
    }
    if (exampleView) list.scrollTop = 0;
    tutorial.position();
  }
  function rebuildArchiveOffsets() {
    const view = archiveWindow;
    view.offsets = [0];
    for (let index = 0; index < archiveResults.length; index++) {
      view.offsets.push(view.offsets[index] + (view.heights[index] ?? archiveEstimatedHeight) + view.gap);
    }
    view.window.style.height = `${Math.max(0, view.offsets.at(-1) - view.gap)}px`;
  }
  function archiveIndexAt(offset) {
    const offsets = archiveWindow.offsets;
    let low = 0, high = archiveResults.length;
    while (low < high) {
      const mid = Math.floor((low + high) / 2);
      if (offsets[mid + 1] <= offset) low = mid + 1; else high = mid;
    }
    return Math.min(low, Math.max(0, archiveResults.length - 1));
  }
  function scheduleArchiveRender() {
    if (archiveRenderPending || selected !== M.REMOVED || !archiveWindow) return;
    archiveRenderPending = true;
    const next = globalThis.requestAnimationFrame || (callback => setTimeout(callback, 0));
    next(() => { archiveRenderPending = false; renderArchiveWindow(); });
  }
  function archiveControls(row) {
    return [...row.querySelectorAll('a, button')].filter(node => !node.disabled && !node.hidden);
  }
  function ensureArchiveVisible(index) {
    const list = $('bookmark-list'), view = archiveWindow;
    const top = view.offsets[index], height = view.heights[index] ?? archiveEstimatedHeight;
    if (top < list.scrollTop) list.scrollTop = top;
    else if (top + height > list.scrollTop + list.clientHeight) list.scrollTop = top + height - list.clientHeight;
  }
  function renderArchiveWindow(focusIndex, focusEdge = 'first') {
    if (selected !== M.REMOVED || !archiveWindow || !archiveResults.length) return;
    const list = $('bookmark-list'), view = archiveWindow;
    const width = list.clientWidth || list.getBoundingClientRect().width;
    if (width !== view.width) {
      const anchor = archiveIndexAt(list.scrollTop || 0), delta = (list.scrollTop || 0) - (view.offsets[anchor] || 0);
      view.width = width; view.heights = [];
      view.gap = parseFloat(globalThis.getComputedStyle?.(list).getPropertyValue('--row-gap')) || 4;
      rebuildArchiveOffsets(); list.scrollTop = view.offsets[anchor] + delta;
    }
    if (focusIndex !== undefined) ensureArchiveVisible(focusIndex);
    const start = Math.max(0, archiveIndexAt(list.scrollTop || 0) - 4);
    const end = Math.min(archiveResults.length, archiveIndexAt((list.scrollTop || 0) + (list.clientHeight || 600)) + 5);
    const focused = document.activeElement;
    const focusedRow = focused?.closest('.archived-bookmark');
    const focusedIndex = focusedRow?.parentElement === view.window ? Number(focusedRow.dataset.archiveIndex) : null;
    const indices = Array.from({ length: end - start }, (_, index) => start + index);
    // Keep one offscreen focused row mounted without rendering the intervening history.
    if (focusIndex === undefined && focusedIndex !== null && !indices.includes(focusedIndex)) indices.push(focusedIndex);
    if (focusIndex !== undefined && !indices.includes(focusIndex)) indices.push(focusIndex);
    indices.sort((a, b) => a - b);
    const range = indices.join(':');
    if (range !== archiveRange) {
      const retained = new Map();
      for (const index of indices) {
        let row = view.nodes.get(index);
        if (!row) {
          const entry = archiveResults[index];
          const identity = entry.url === 'https://chatgpt.com/dots/home' ? { kind: 'dots', id: 'dots:home', url: entry.url } :
            entry.url === 'https://chatgpt.com/' ? { kind: 'chatgpt', id: 'chatgpt:home', url: entry.url } : M.normalizeURL(entry.url);
          const b = { ...identity, title: entry.title };
          row = element('article', 'bookmark archived-bookmark');
          row.dataset.archiveId = entry.id; row.dataset.archiveIndex = index; row.dataset.pageId = b.id;
          row.setAttribute('aria-posinset', index + 1); row.setAttribute('aria-setsize', archiveResults.length);
          const link = bookmarkLink(b, entry.categoryName, entry.id);
          link.dataset.archiveIndex = index; link.dataset.focusKey = `archive:${entry.id}`;
          const edit = iconButton('more', `编辑收藏：${entry.title}`, () => editArchive(entry));
          edit.title = `编辑：${entry.title}`; edit.dataset.focusKey = `archive-edit:${entry.id}`;
          edit.disabled = !live || !ready || blocked;
          dragSource(row, 'archive', entry.id, live && ready && !blocked);
          row.append(link, edit); appendCloseButton(row, b, `archive-close:${entry.id}`);
        }
        retained.set(index, row);
      }
      view.nodes = retained; view.window.replaceChildren(...retained.values()); archiveRange = range;
      if (focusIndex === undefined && focusedIndex !== null && retained.has(focusedIndex)) focused.focus({ preventScroll: true });
    }
    paintTabStates();
    const anchor = archiveIndexAt(list.scrollTop || 0), delta = (list.scrollTop || 0) - view.offsets[anchor];
    let changed = false;
    // Read one batch before applying positions, so each row keeps the normal content height.
    for (const [index, row] of view.nodes) {
      const height = row.getBoundingClientRect().height;
      if (height > 0 && Math.abs(height - (view.heights[index] ?? archiveEstimatedHeight)) > 0.1) {
        view.heights[index] = height; changed = true;
      }
    }
    if (changed) rebuildArchiveOffsets();
    for (const [index, row] of view.nodes) row.style.top = `${view.offsets[index]}px`;
    if (changed) { list.scrollTop = view.offsets[anchor] + delta; scheduleArchiveRender(); }
    if (focusIndex !== undefined) {
      ensureArchiveVisible(focusIndex);
      const controls = archiveControls(view.nodes.get(focusIndex));
      (focusEdge === 'last' ? controls.at(-1) : controls[0])?.focus({ preventScroll: true });
    }
  }
  $('bookmark-list').addEventListener('scroll', scheduleArchiveRender, { passive: true });
  if (globalThis.ResizeObserver) new ResizeObserver(scheduleArchiveRender).observe($('bookmark-list'));
  $('bookmark-list').addEventListener('keydown', event => {
    const row = event.target.closest('.archived-bookmark');
    if (selected !== M.REMOVED || !row || !archiveWindow) return;
    const index = Number(row.dataset.archiveIndex);
    let next, edge = 'first';
    if (event.key === 'Tab') {
      const controls = archiveControls(row), position = controls.indexOf(event.target.closest('a, button'));
      if (position < 0 || event.shiftKey && position > 0 || !event.shiftKey && position < controls.length - 1) return;
      next = index + (event.shiftKey ? -1 : 1); edge = event.shiftKey ? 'last' : 'first';
    } else if (event.key === 'ArrowDown') next = index + 1;
    else if (event.key === 'ArrowUp') next = index - 1;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = archiveResults.length - 1;
    else if (event.key === 'PageDown') next = Math.max(index + 1, archiveIndexAt(archiveWindow.offsets[index] + $('bookmark-list').clientHeight));
    else if (event.key === 'PageUp') next = Math.min(index - 1, archiveIndexAt(Math.max(0, archiveWindow.offsets[index] - $('bookmark-list').clientHeight)));
    if (next === undefined || next < 0 || next >= archiveResults.length) return;
    event.preventDefault(); renderArchiveWindow(next, edge);
  });
  function clearDropFeedback() {
    document.querySelectorAll('.drop-target, .drop-before, .drop-after').forEach(node => node.classList.remove('drop-target', 'drop-before', 'drop-after'));
  }
  function dragSource(row, kind, id, enabled) {
    row.draggable = enabled;
    let fromAction = false;
    row.addEventListener('mousedown', event => { fromAction = Boolean(event.target.closest('.icon-button')); });
    row.addEventListener('dragstart', event => {
      if (!enabled || fromAction || event.target.closest('.icon-button')) { event.preventDefault(); return; }
      dragging = { kind, id };
      event.dataTransfer.clearData();
      event.dataTransfer.setData('application/x-session-bookmark', JSON.stringify(dragging));
      event.dataTransfer.effectAllowed = 'move';
      row.classList.add('dragging');
    });
    row.addEventListener('dragend', () => {
      dragging = null; row.classList.remove('dragging'); clearDropFeedback(); suppressClickUntil = Date.now() + 200;
      sortTabStates();
    });
  }
  function dropTarget(node, categoryId) {
    const valid = () => dragging && ready && !blocked && (['bookmark', 'archive'].includes(dragging.kind) ||
      dragging.kind === 'category' && categoryId !== null && dragging.id !== categoryId);
    const position = event => event.clientX < node.getBoundingClientRect().left + node.getBoundingClientRect().width / 2 ? 'before' : 'after';
    node.addEventListener('dragover', event => {
      if (!valid()) return;
      event.preventDefault(); event.stopPropagation(); event.dataTransfer.dropEffect = 'move';
      clearDropFeedback(); node.classList.add(dragging.kind !== 'category' ? 'drop-target' : `drop-${position(event)}`);
    });
    node.addEventListener('dragleave', event => { if (!node.contains(event.relatedTarget)) clearDropFeedback(); });
    node.addEventListener('drop', async event => {
      event.preventDefault(); event.stopPropagation(); clearDropFeedback();
      if (!valid()) return;
      const source = dragging; dragging = null; suppressClickUntil = Date.now() + 200;
      try {
        if (source.kind === 'archive') {
          const entry = archive.find(item => item.id === source.id);
          if (!entry) throw Error('归档已被恢复或移除，请重新打开列表。');
          await restoreArchived(entry, entry.title, categoryId);
        } else if (source.kind === 'bookmark') await mutate('move', { id: source.id, categoryId });
        else await mutate('category-reorder', { id: source.id, targetId: categoryId, position: position(event) });
      } catch (error) { status(error.message, true); }
    });
  }
  function categoryMenu(p, button) {
    menuCategory = p;
    const menu = $('category-menu');
    showMenu(menu, button);
  }
  function showMenu(menu, button) {
    for (const other of document.querySelectorAll('.menu:popover-open')) other.hidePopover();
    menu.showPopover();
    menu.dataset.focusOrigin = button.dataset.focusKey;
    const rect = button.getBoundingClientRect();
    menu.style.left = `${Math.max(8, Math.min(rect.right - menu.offsetWidth, innerWidth - menu.offsetWidth - 8))}px`;
    menu.style.top = `${Math.max(8, Math.min(rect.bottom, innerHeight - menu.offsetHeight - 8))}px`;
    menu.querySelector('button').focus();
  }
  function sessionDropTarget(node, kind, id) {
    const action = () => {
      if (dragging?.kind !== 'bookmark' || !ready || blocked) return null;
      const source = state.bookmarks.find(b => b.id === dragging.id);
      const target = kind === 'project' ? state.projects.find(p => p.id === id) : state.bookmarks.find(b => b.id === id);
      if (!source || !target || kind === 'bookmark' && source.id === id) return null;
      if (source.projectId) return source.projectId === (kind === 'project' ? id : target.projectId) ? null : 'project-detach';
      if (source.categoryId !== target.categoryId) return null;
      return kind === 'project' ? 'project-join' : 'project-create';
    };
    node.addEventListener('dragover', event => {
      if (!action()) { event.preventDefault(); event.stopPropagation(); event.dataTransfer.dropEffect = 'none'; clearDropFeedback(); return; }
      event.preventDefault(); event.stopPropagation(); event.dataTransfer.dropEffect = 'move';
      clearDropFeedback(); node.classList.add('drop-target');
    });
    node.addEventListener('dragleave', event => { if (!node.contains(event.relatedTarget)) clearDropFeedback(); });
    node.addEventListener('drop', async event => {
      event.preventDefault(); event.stopPropagation(); clearDropFeedback();
      const operation = action();
      if (!operation) return;
      const sourceId = dragging.id; dragging = null; suppressClickUntil = Date.now() + 200;
      if (operation === 'project-create') { createProject(sourceId, id); return; }
      try { await mutate(operation, { id: sourceId, projectId: id }); }
      catch (error) { status(error.message, true); }
    });
  }
  function outsideProjectDropTarget(node) {
    const valid = event => dragging?.kind === 'bookmark' && ready && !blocked &&
      state.bookmarks.some(b => b.id === dragging.id && b.projectId &&
        event.target.closest('.session-project')?.dataset.projectId !== b.projectId);
    node.addEventListener('dragover', event => {
      if (!valid(event)) return;
      event.preventDefault(); event.stopPropagation(); event.dataTransfer.dropEffect = 'move';
      clearDropFeedback(); $('bookmark-list').classList.add('drop-target');
    });
    node.addEventListener('dragleave', event => { if (!node.contains(event.relatedTarget)) clearDropFeedback(); });
    node.addEventListener('drop', async event => {
      if (!valid(event)) return;
      event.preventDefault(); event.stopPropagation(); clearDropFeedback();
      const id = dragging.id; dragging = null; suppressClickUntil = Date.now() + 200;
      try { await mutate('project-detach', { id }); }
      catch (error) { status(error.message, true); }
    });
  }
  function createProject(sourceId, targetId) {
    openEditor('新建项目', '创建');
    const name = field('project-name', '项目名称');
    onSave = () => mutate('project-create', { name: name.value, sourceId, targetId });
    firstInput();
  }
  function projectMenu(p, button) { menuProject = p; showMenu($('project-menu'), button); }
  function editProject(p) {
    openEditor('重命名项目');
    const name = field('project-name', '项目名称', p.name);
    onSave = () => mutate('project-rename', { id: p.id, name: name.value });
    firstInput();
  }
  function dissolveProject(p) {
    openEditor('解散项目', '解散');
    fields.append(element('p', 'confirmation', `解散“${p.name}”？`));
    onSave = () => mutate('project-dissolve', { id: p.id });
    $('cancel-button').focus();
  }
  function field(name, text, value = '', options) {
    const wrapper = element('label', 'field'); wrapper.append(element('span', '', text));
    const input = document.createElement(options ? 'select' : 'input'); input.name = name;
    if (options) for (const option of options) { const node = element('option', '', option.name); node.value = option.id; input.append(node); }
    else { input.type = 'text'; input.required = true; input.maxLength = name === 'url' ? 2048 : ['category-name', 'project-name'].includes(name) ? 60 : 200; input.autocomplete = 'off'; }
    input.value = value; wrapper.append(input); fields.append(wrapper); return input;
  }
  function categoryField(value) {
    const wrapper = element('div', 'field');
    const label = element('label', '', '类别'); label.htmlFor = 'editor-category';
    const controls = element('div', 'category-select');
    const select = element('select'); select.name = 'category'; select.id = 'editor-category';
    const add = iconButton('plus', '新建类别', () => {
      inline.hidden = false; add.hidden = true; name.focus();
    });
    add.id = 'inline-category-toggle';
    controls.append(select, add); wrapper.append(label, controls);
    const inline = element('div', 'inline-category'); inline.hidden = true;
    const nameLabel = element('label', '', '类别名称'); nameLabel.htmlFor = 'inline-category-name';
    const name = element('input'); name.id = 'inline-category-name'; name.maxLength = 60; name.autocomplete = 'off';
    const error = element('p', 'error inline-error'); error.setAttribute('role', 'alert');
    const actions = element('div', 'inline-actions');
    const cancel = element('button', '', '取消'); cancel.type = 'button'; cancel.id = 'inline-category-cancel';
    const create = element('button', '', '创建'); create.type = 'button'; create.id = 'inline-category-create';
    const hide = () => { inline.hidden = true; add.hidden = false; name.value = ''; error.textContent = ''; add.focus(); };
    cancel.addEventListener('click', hide);
    create.addEventListener('click', async () => {
      if (saving || inlineSaving) return;
      try { M.label(name.value, '类别名称', 60); } catch (err) { error.textContent = err.message; name.focus(); return; }
      inlineSaving = true; error.textContent = '';
      dialog.setAttribute('closedby', 'none');
      const buttons = [...dialog.querySelectorAll('button')];
      const disabled = buttons.map(button => button.disabled);
      buttons.forEach(button => { button.disabled = true; }); name.disabled = true; select.disabled = true;
      try {
        const result = await mutate('category-create', { name: name.value });
        if (!state.categories.some(p => p.id === result.categoryId)) throw new Error('类别已被删除，请重新创建。');
        syncCategorySelect(result.categoryId); hide();
      } catch (err) { error.textContent = err.message; }
      finally {
        inlineSaving = false; buttons.forEach((button, index) => { button.disabled = disabled[index]; }); name.disabled = false; select.disabled = false;
        dialog.setAttribute('closedby', 'closerequest');
        if (inline.hidden) select.focus(); else name.focus();
      }
    });
    name.addEventListener('keydown', event => {
      if (event.key === 'Enter') { event.preventDefault(); create.click(); }
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); if (!inlineSaving) hide(); }
    });
    actions.append(cancel, create); inline.append(nameLabel, name, error, actions); wrapper.append(inline); fields.append(wrapper);
    syncCategorySelect(value ?? '');
    return select;
  }
  function syncCategorySelect(value) {
    const select = fields.querySelector('[name="category"]');
    if (!select) return;
    const selectedValue = value ?? select.value;
    const oldName = select.selectedOptions[0]?.textContent;
    select.replaceChildren();
    const options = [{ id: '', name: '未分类' }, ...M.sortedCategories(state)];
    if (selectedValue && !options.some(p => p.id === selectedValue)) options.push({ id: selectedValue, name: oldName || '类别已删除' });
    for (const p of options) { const option = element('option', '', p.name); option.value = p.id; select.append(option); }
    select.value = selectedValue;
  }
  function currentCategory() { return state.categories.some(p => p.id === selected) ? selected : ''; }
  function openEditor(title, submit = '保存') {
    if (!dialog.open) focusBeforeDialog = document.activeElement?.closest('.menu')?.dataset.focusOrigin || document.activeElement?.dataset.focusKey || document.activeElement?.id;
    fields.replaceChildren(); $('dialog-error').textContent = '';
    $('dialog-title').textContent = title; $('save-button').textContent = submit;
    $('dialog-title').classList.remove('dots-editor-heading'); property($('dialog-title'), 'title', ''); attribute($('dialog-title'), 'title', '');
    $('delete-button').hidden = true; onDelete = null; onSave = null;
    $('delete-button').classList.remove('restore-archive');
    if (!dialog.open) dialog.showModal();
  }
  function firstInput() { fields.querySelector('input, select')?.focus(); }
  function closeEditor() { if (!saving && !inlineSaving) dialog.close(); }
  async function restoreArchived(entry, title, categoryId) {
    const result = await mutate('archive-restore', { id: entry.id, title, categoryId });
    $('search').value = '';
    selectCategory(result.categoryId || 'unfiled');
  }
  function editArchive(entry) {
    openEditor('编辑收藏');
    const title = field('title', '名称', entry.title);
    const category = categoryField(M.archiveCategory(state, entry));
    if (entry.url !== 'https://chatgpt.com/dots/home') { const url = field('url', '链接', entry.url); url.readOnly = true; }
    onSave = () => mutate('archive-edit', { id: entry.id, title: title.value, categoryId: category.value });
    $('delete-button').hidden = false; $('delete-button').textContent = '恢复';
    $('delete-button').classList.add('restore-archive');
    onDelete = () => runEditorAction(() => restoreArchived(entry, title.value, category.value));
    firstInput();
  }
  function editBookmark(b) {
    openEditor('编辑收藏');
    const title = field('title', '名称', b.title);
    const category = categoryField(b.categoryId);
    if (b.kind !== 'dots') { const url = field('url', '链接', b.url); url.readOnly = true; }
    let detachProject = false;
    if (b.projectId) {
      const projectAction = element('button', '', '移出项目'); projectAction.type = 'button'; projectAction.id = 'bookmark-project-action';
      projectAction.addEventListener('click', () => {
        if (saving || inlineSaving) return;
        // Keep title/category edits intact while making the membership change on save.
        detachProject = true; projectAction.hidden = true;
      });
      fields.append(projectAction);
    }
    onSave = () => mutate('edit', { id: b.id, title: title.value, categoryId: category.value, ...(detachProject ? { projectId: null } : {}) });
    $('delete-button').hidden = false; $('delete-button').textContent = '移除';
    onDelete = () => runEditorAction(async () => {
      await mutate('remove', { id: b.id });
      if (b.kind === 'chatgpt' || b.kind === 'dots') {
        try { await closeChat(b.url); }
        catch (error) { status(`收藏已移除，但关闭标签页失败：${error.message}`, true, true); }
      }
    });
    firstInput();
  }
  function addCodex() {
    openEditor('添加 Codex', '收藏');
    const url = field('url', 'Codex 链接'); url.placeholder = 'codex://threads/…'; url.spellcheck = false;
    const title = field('title', '名称');
    const category = categoryField(currentCategory());
    onSave = async () => {
      if (M.normalizeURL(url.value).kind !== 'codex') throw new Error('请输入 Codex 深度链接。');
      await mutate('add', { url: url.value, title: title.value, categoryId: category.value });
    };
    firstInput();
  }
  function addDots() {
    if (!dotsSnapshot.eligible || !ready || blocked) return;
    const snapshot = dotsSnapshot;
    openEditor('添加 Dots', '收藏');
    $('dialog-title').classList.add('dots-editor-heading'); property($('dialog-title'), 'title', ''); attribute($('dialog-title'), 'title', '');
    const title = field('title', '名称');
    const category = categoryField(currentCategory());
    onSave = async () => mutate('dots-add', { title: title.value, categoryId: category.value,
      windowId: await panelContext.getWindowId(), binding: snapshot.binding, token: snapshot.token });
    firstInput();
  }
  async function newChat() {
    if (!canCreateChat || creatingChat) return;
    creatingChat = true; $('new-chat').disabled = true;
    try { await panelContext.createChat(); status(); }
    catch (error) { if (error.opened) status(); else status(`新建会话失败：${error.message}`, true); }
    finally { creatingChat = false; $('new-chat').disabled = !canCreateChat; }
  }
  async function addCurrent() {
    if ($('add-current').disabled || $('add-current').getAttribute('aria-disabled') === 'true') return;
    capturing = true; paintCurrentButton();
    try {
      const tab = await panelContext.getActiveTab();
      const link = M.normalizeURL(tab?.pendingUrl || tab?.url);
      if (link.kind !== 'chatgpt') throw new Error('请先打开 ChatGPT 对话标签页。');
      await refresh();
      if (!ready || blocked) return;
      currentId = link.id;
      if (state.bookmarks.some(b => b.id === link.id)) return;
      openEditor('收藏当前对话', '收藏');
      const title = field('title', '名称', tab.title?.trim().slice(0, 200) || 'ChatGPT');
      const category = categoryField(currentCategory());
      onSave = () => mutate('capture', { url: link.url, title: title.value, categoryId: category.value });
      firstInput();
    } catch (error) { status(error.message, true); }
    finally { capturing = false; void refreshCurrentButton(); }
  }
  function newCategory() {
    openEditor('新建类别', '创建');
    const name = field('category-name', '类别名称');
    onSave = () => mutate('category-create', { name: name.value }); firstInput();
  }
  function editCategory(p) {
    openEditor('编辑类别');
    const name = field('category-name', '类别名称', p.name);
    onSave = () => mutate('category-rename', { id: p.id, name: name.value });
    $('delete-button').hidden = false; $('delete-button').textContent = '删除';
    onDelete = () => {
      openEditor('删除类别', '删除');
      fields.append(element('p', 'confirmation', `删除“${p.name}”？其中的收藏将移到未分类。`));
      onSave = () => mutate('category-delete', { id: p.id });
      $('cancel-button').focus();
    };
    firstInput();
  }
  async function exportBackup() {
    $('settings').close();
    try {
      const { backup } = await call('export');
      const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }));
      const a = element('a'); a.href = url; a.download = `客服工作台-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
      status('已发起备份下载');
    } catch (error) { status(error.message, true); }
  }
  async function importBackup(event) {
    const file = event.target.files[0]; event.target.value = '';
    if (!file) return;
    $('settings').close();
    try {
      if (file.size > 5 * 1024 * 1024) throw new Error('备份文件须小于 5 MB。');
      const raw = JSON.parse(await file.text());
      const parsed = M.normalizeState(raw, { strict: true }).state;
      openEditor('导入备份', '导入');
      fields.append(element('p', 'confirmation', `${parsed.categories.length} 个类别，${parsed.projects.length} 个项目，${parsed.bookmarks.length} 条收藏`));
      const mode = field('mode', '导入方式', blocked || !ready ? 'restore' : 'import', [{ id: 'import', name: '合并，保留已有收藏' }, { id: 'restore', name: '替换全部类别与收藏' }]);
      onSave = async () => {
        if (mode.value === 'restore') {
          openEditor('替换全部收藏', '替换');
          fields.append(element('p', 'confirmation', '现有类别与收藏将被此备份替换。'));
          onSave = () => mutate('restore', raw);
          $('cancel-button').focus();
          return false;
        }
        await mutate('import', raw);
      };
      firstInput();
    } catch (error) { status(error instanceof SyntaxError ? 'JSON 文件格式无效。' : error.message, true); }
  }
  async function runEditorAction(action) {
    if (saving || inlineSaving || !action) return;
    saving = true; $('dialog-error').textContent = '';
    dialog.setAttribute('closedby', 'none');
    for (const id of ['save-button', 'delete-button', 'cancel-button']) $(id).disabled = true;
    try { const result = await action(); if (result !== false) dialog.close(); }
    catch (error) { $('dialog-error').textContent = error.message; }
    finally { saving = false; dialog.setAttribute('closedby', 'closerequest'); for (const id of ['save-button', 'delete-button', 'cancel-button']) $(id).disabled = false; }
  }
  $('editor-form').addEventListener('submit', event => { event.preventDefault(); return runEditorAction(onSave); });
  dialog.addEventListener('cancel', event => { if (saving || inlineSaving) event.preventDefault(); });
  dialog.addEventListener('close', () => {
    const target = [...document.querySelectorAll('[data-focus-key], [id]')].find(n => n.dataset.focusKey === focusBeforeDialog || n.id === focusBeforeDialog);
    (target || $('search')).focus({ preventScroll: true });
  });
  $('cancel-button').addEventListener('click', closeEditor);
  $('delete-button').addEventListener('click', () => onDelete?.());
  $('add-current').addEventListener('click', addCurrent);
  $('add-codex').addEventListener('click', addCodex);
  $('add-dots').addEventListener('click', addDots);
  $('open-dots').addEventListener('click', () => openDots());
  $('new-chat').addEventListener('click', newChat);
  $('new-category').addEventListener('click', newCategory);
  $('search').addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { $('bookmark-list').scrollTop = 0; render(); }, 120);
  });
  $('export-button').addEventListener('click', exportBackup);
  $('import-button').addEventListener('click', () => $('import-file').click());
  $('import-file').addEventListener('change', importBackup);
  let groupSettingRevision = 0, groupSettingSaving = false, groupEnabled = true;
  let refreshingSessions = false;
  $('refresh-sessions').disabled = !live;
  $('refresh-sessions').addEventListener('click', async () => {
    if (!live || refreshingSessions) return;
    refreshingSessions = true;
    $('refresh-sessions').disabled = true;
    $('refresh-status').textContent = '正在刷新…';
    try {
      const result = await call('refresh-sessions', { scope: 'all', windowId: await panelContext.getWindowId() });
      $('refresh-status').textContent = result.busy ? '正在刷新，请稍候' :
        `成功 ${result.success} · 失败 ${result.failed} · 跳过 ${result.skipped}`;
      const unhydrated = result.details?.filter(detail => detail.reason === 'assistant-not-hydrated').length || 0;
      if (unhydrated) $('refresh-status').textContent += ' · ' + unhydrated + ' 条尚未加载出助手回复，请稍后再试';
      if (result.tracking?.scheduled) $('refresh-status').textContent +=
        ` · 仍在生成：已安排 ${result.tracking.scheduled} 条后台复查`;
      if (result.tracking?.warning) $('refresh-status').textContent += ` · ${result.tracking.warning}`;
      if (result.cleanup?.failed) $('refresh-status').textContent +=
        ` · 临时页关闭失败 ${result.cleanup.failed} · 标签 ID ${result.cleanup.leakedTabIds.join('、')}`;
    } catch (error) { $('refresh-status').textContent = error.message; }
    finally {
      refreshingSessions = false; $('refresh-sessions').disabled = false;
    }
  });
  async function refreshGroupSetting() {
    if (!live || groupSettingSaving) return;
    const revision = ++groupSettingRevision;
    $('auto-group').disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ channel: 'session-bookmarks', action: 'auto-group-get' });
      if (revision !== groupSettingRevision) return;
      if (!result?.ok || typeof result.enabled !== 'boolean') throw Error(result?.error || '自动分组选项读取失败。');
      groupEnabled = result.enabled; $('auto-group').checked = groupEnabled;
    } catch (error) { if (revision === groupSettingRevision) status(error.message, true); }
    finally { if (revision === groupSettingRevision && !groupSettingSaving) $('auto-group').disabled = false; }
  }
  $('auto-group').addEventListener('change', async () => {
    if (!live || groupSettingSaving) return;
    groupSettingRevision++; groupSettingSaving = true; $('auto-group').disabled = true;
    const enabled = $('auto-group').checked;
    try {
      const result = await chrome.runtime.sendMessage({ channel: 'session-bookmarks', action: 'auto-group-set', payload: { enabled } });
      if (!result?.ok) throw Error(result?.error || '自动分组选项保存失败。');
      groupEnabled = enabled; status();
    } catch (error) { $('auto-group').checked = groupEnabled; status(error.message, true); }
    finally { groupSettingSaving = false; $('auto-group').disabled = false; }
  });
  $('copy-diagnostics').disabled = !live;
  $('copy-diagnostics').addEventListener('click', async () => {
    if (!live || $('copy-diagnostics').disabled) return;
    $('copy-diagnostics').disabled = true;
    try {
      const targetId = currentId || tabState.activeId;
      const text = panelContext.getWindowId().then(windowId => call('collect-diagnostics', { targetId, windowId }))
        .then(({ diagnostic }) => {
          diagnostic = BookmarkDiagnostics.fromBackground(diagnostic, { panelVersion: PANEL_VERSION,
            manifestVersion: chrome.runtime.getManifest?.().version, targetId });
          const displayed = CodexStatus ? CodexStatus.applyToState(state, codexSnapshot) : state;
          const renderedRows = new Map([...$('bookmark-list').querySelectorAll('.bookmark')].map(row => [row.dataset.bookmarkId, row]));
          const visible = node => {
            if (!node?.getClientRects().length) return false;
            for (let current = node; current; current = current.parentElement) {
              const style = getComputedStyle(current);
              if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility)) return false;
            }
            return true;
          };
          const rows = [...displayed.bookmarks].sort((a,b) => Number(b.id === targetId) - Number(a.id === targetId)).slice(0,200).map(b => {
            const row = renderedRows.get(b.id);
            const marks = row ? [...row.querySelectorAll('.reply-marker')] : [];
            const rendered = !row ? 'not-rendered' : !visible(row) ? 'hidden' : 'rendered';
            const markerVisible = row ? marks.some(visible) : null;
            const actual = rendered !== 'rendered' ? 'unknown' : marks.length > 1 ? 'invalid' : marks.length && !markerVisible ? 'hidden' :
              !marks.length ? 'none' : marks[0].classList.contains('permission-marker') && marks[0].textContent === '?' ? 'green' :
                marks[0].textContent === '!' ? 'red' : 'invalid';
            const expected = newReplyEvidence(b) ? 'unknown' : BookmarkDiagnostics.marker(b.replyState, b.kind);
            return { id: b.id, expected, displayed: b.replyState ? { author: b.replyState.author, phase: b.replyState.phase } : null,
              row: rendered, receiverState: receiverState(b), receiverUnavailable: unavailable(b), markerPresent: row ? marks.length > 0 : null, markerVisible, actual,
              matches: rendered !== 'rendered' || expected === 'unknown' ? null : actual === (expected === 'not-applicable' ? 'none' : expected) };
          });
          diagnostic.panel = { version: PANEL_VERSION, sampledAt: Date.now(), renderedAt: markerRenderAt, targetId, rows,
            omittedRows: Math.max(0, displayed.bookmarks.length - rows.length) };
          return JSON.stringify(BookmarkDiagnostics.fit(diagnostic), null, 2);
        });
      if (typeof ClipboardItem === 'function' && navigator.clipboard.write) {
        const content = text.then(value => new Blob([value], { type: 'text/plain' }));
        // Start the clipboard operation during the click's user activation;
        // data can arrive later, including after per-page timeouts.
        void content.catch(() => {});
        await Promise.all([navigator.clipboard.write([new ClipboardItem({ 'text/plain': content })]), content]);
      } else await navigator.clipboard.writeText(await text);
    } catch { status('状态诊断复制失败。', true); }
    finally { $('copy-diagnostics').disabled = !live; }
  });
  $('auto-group').disabled = !live;
  $('dots-pro').disabled = !live;
  $('dots-pro').addEventListener('change', async () => {
    const enabled = $('dots-pro').checked;
    $('dots-pro').disabled = true;
    try {
      const result = await call('dots-pro-set', { enabled, windowId: await panelContext.getWindowId() });
      dotsSnapshot = result.snapshot; paintDots();
      dotsGuideClaim = result.guide?.show ? result.guide : null;
      if (!enabled) { dotsGuideClaim = null; dotsGuide.hide(); }
      else { void maybeShowDotsGuide(); if (!result.guide?.show) void refreshDots(); }
    } catch (error) { $('dots-pro').checked = dotsSnapshot.eligible; status(error.message, true); }
    finally { $('dots-pro').disabled = !live; }
  });
  $('settings-toggle').addEventListener('click', () => { $('settings').showModal(); void refreshGroupSetting(); });
  $('settings-close').addEventListener('click', () => $('settings').close());
  $('settings').addEventListener('close', () => $('settings-toggle').focus());
  $('tutorial-button').disabled = !live;
  $('tutorial-button').addEventListener('click', () => { dotsGuide.hide(); $('settings').close(); return tutorial.restart(); });
  for (const id of ['settings', 'statistics', 'editor']) $(id).addEventListener('close', () => { queueMicrotask(syncTutorial); });
  let statisticsTimer, statisticsRequest = 0;
  async function refreshStatistics() {
    if (!$('statistics').open) return;
    clearTimeout(statisticsTimer);
    const request = ++statisticsRequest;
    try {
      const result = live ? await chrome.runtime.sendMessage({ channel: 'session-bookmarks', action: 'stats-today' }) :
        { ok: true, ...BookmarkStatistics.closedPeriod(Date.now()), available: false };
      if (!$('statistics').open || request !== statisticsRequest) return;
      if (!result?.ok) throw Error(result?.error || '统计读取失败。');
      if (result.day !== BookmarkStatistics.closedPeriod(Date.now()).day) { void refreshStatistics(); return; }
      $('statistics-unavailable').hidden = result.available;
      $('statistics-values').hidden = !result.available;
      $('statistics-range').hidden = !result.available;
      $('statistics-range').textContent = result.available ? BookmarkStatistics.formatRange(result) : '';
      $('statistics-messages').textContent = result.available ? String(result.messages) : '—';
      $('statistics-characters').textContent = result.available ? String(result.characters) : '—';
    } catch (error) {
      if (request === statisticsRequest && $('statistics').open) {
        $('statistics-messages').textContent = '—'; $('statistics-characters').textContent = '—';
        status(error.message, true);
      }
    } finally {
      if (request === statisticsRequest && $('statistics').open) {
        statisticsTimer = setTimeout(refreshStatistics, Math.max(20, BookmarkStatistics.nextDay(Date.now()) - Date.now() + 20));
      }
    }
  }
  $('statistics-button').addEventListener('click', () => {
    $('statistics-messages').textContent = '—'; $('statistics-characters').textContent = '—';
    for (const id of ['statistics-range', 'statistics-values', 'statistics-unavailable']) $(id).hidden = true;
    $('statistics').showModal(); void refreshStatistics();
  });
  $('statistics-close').addEventListener('click', () => $('statistics').close());
  $('statistics').addEventListener('close', () => {
    statisticsRequest++; clearTimeout(statisticsTimer); $('statistics-button').focus();
  });
  document.addEventListener('visibilitychange', () => {
    void refreshCodex();
    panelContext?.reportVisibility();
    if (!document.hidden) { void refreshStatistics(); void refreshDots(); syncTutorial(); }
  });
  window.addEventListener('pageshow', () => { void refreshStatistics(); });
  for (const id of ['all', 'unfiled']) $('filter-' + id).addEventListener('click', () => selectCategory(id));
  $('filter-removed').addEventListener('click', () => selectCategory(M.REMOVED));
  dropTarget($('filter-unfiled'), null);
  outsideProjectDropTarget(document.body);
  $('category-rename').addEventListener('click', () => { $('category-menu').hidePopover(); editCategory(menuCategory); });
  $('category-delete').addEventListener('click', () => { $('category-menu').hidePopover(); editCategory(menuCategory); onDelete(); });
  $('project-rename').addEventListener('click', () => { $('project-menu').hidePopover(); editProject(menuProject); });
  $('project-dissolve').addEventListener('click', () => { $('project-menu').hidePopover(); dissolveProject(menuProject); });
  for (const menu of document.querySelectorAll('.menu')) menu.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    event.preventDefault(); menu.hidePopover();
    [...document.querySelectorAll('[data-focus-key]')].find(node => node.dataset.focusKey === menu.dataset.focusOrigin)?.focus();
  });
  document.addEventListener('click', event => {
    if (Date.now() < suppressClickUntil) { event.preventDefault(); event.stopPropagation(); }
  }, true);
  document.addEventListener('dragover', event => { event.preventDefault(); event.dataTransfer.dropEffect = 'none'; clearDropFeedback(); });
  document.addEventListener('drop', event => { event.preventDefault(); clearDropFeedback(); dragging = null; });
  render();
  if (live) {
    void panelContext.getWindowId().then(id => { panelWindowId = id; paintDots(); paintTabStates(); tutorial.position(); }).catch(() => {});
    let resolveInitialTabs;
    const initialTabs = new Promise(resolve => { resolveInitialTabs = resolve; });
    const tracker = globalThis.BookmarkNavigation.createTabTracker(chrome, snapshot => {
      const before = state.bookmarks.map(b => newReplyEvidence(b));
      tabState = snapshot; paintTabStates(); paintDots(); sortTabStates(); void refreshCurrentButton();
      if (before.some((value, index) => value !== newReplyEvidence(state.bookmarks[index]))) paintReceiverStates();
      void refreshReceivers();
      void tutorial.refreshGeometry();
      resolveInitialTabs();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'session' && changes.sessionBookmarksReceivers || area==='local'&&changes.sessionBookmarksClosedWatch) void refreshReceivers();
      if (area === 'local' && changes.sessionBookmarks) void initialTabs.then(async () => { await refresh(); await refreshReceivers(); });
      if (area === 'local' && changes.sessionBookmarksRemoved) {
        archiveLoaded = false;
        if (selected === M.REMOVED) void initialTabs.then(refreshArchive);
      }
      if (area === 'local' && changes[BookmarkStatistics.KEY]) void refreshStatistics();
      if (area === 'local' && changes[BookmarkPreferences.AUTO_GROUP_KEY] && $('settings').open) void refreshGroupSetting();
      if (area === 'local' && changes[BookmarkPreferences.MANUAL_PRO_KEY]) void refreshDots();
      if (area === 'local' && changes[BookmarkOnboarding.KEY]) syncTutorial();
      if (area === 'local' && changes[BookmarkDotsGuide.KEY]?.newValue?.status === 'shown') dotsGuideClaim = null;
    });
    chrome.runtime.onMessage?.addListener(message => {
      if (message?.channel === Dots.UNREAD_CHANNEL && message.action === 'changed' && message.windowId === panelWindowId) { void refreshDots(); return; }
      if (message?.channel === CodexStatus?.CHANNEL && message.action === 'refreshed') { void refreshCodex(); return; }
      if (message?.channel === CodexStatus?.CHANNEL && message.action === 'disconnected') {
        codexEpoch++; clearTimeout(codexExpiry);
        codexSnapshot = CodexStatus.emptySnapshot(); render();
        return;
      }
    });
    void tracker.refresh();
    window.addEventListener('pagehide', () => { codexClosed = true; clearTimeout(receiverTimer); clearTimeout(codexTimer); clearTimeout(codexExpiry); tracker.destroy(); panelContext.destroy(); tutorial.destroy(); dotsGuide.destroy(); clearTimeout(statisticsTimer); }, { once: true });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) void refreshReceivers(); });
    void (async () => {
      const revision = selectionRevision;
      let preferenceError;
      try {
        const restored = await preferences.load();
        if (revision === selectionRevision) selected = restored;
      } catch (error) { preferenceError = error; }
      selectionLoaded = true;
      // First paint of saved rows already has the initial tab order, avoiding a startup reshuffle.
      await initialTabs;
      await refresh();
      void refreshDots();
      if (preferenceError) status(`筛选读取失败：${preferenceError.message}`, true);
      tutorialReady = true; syncTutorial();
    })();
  }
})();
