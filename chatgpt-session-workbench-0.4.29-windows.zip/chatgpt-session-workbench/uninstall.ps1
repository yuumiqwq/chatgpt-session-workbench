[CmdletBinding()]
param(
    [string]$InstallDirectory,
    [switch]$PlanOnly
)
$ErrorActionPreference = 'Stop'
if (-not $InstallDirectory) { $InstallDirectory = $PSScriptRoot }
$hostName = 'com.chatgpt_session_workbench.codex'
$InstallDirectory = [IO.Path]::GetFullPath($InstallDirectory)
$native = Join-Path $InstallDirectory 'native-host'
$manifestPath = Join-Path $native ($hostName + '.json')
$registryPath = 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\' + $hostName
$statePath = Join-Path $InstallDirectory 'install-state.json'
$state = $null
if (Test-Path -LiteralPath $statePath -PathType Leaf) { $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json }
$files = @(
    (Join-Path $native 'workbench-codex-host.exe'),
    (Join-Path $native 'host-config.json'),
    $manifestPath,
    (Join-Path $InstallDirectory 'install-state.json')
)
$plan = [ordered]@{
    version = 1
    registryPath = $registryPath
    removeOnlyIfRegistryDefaultMatches = $manifestPath
    removeFiles = $files
    preservedExtensionDirectory = $(if ($state) { $state.extensionDirectory } else { $null })
    preservesBrowserStorage = $true
}
if ($PlanOnly) { $plan | ConvertTo-Json -Depth 5; return }
if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'This directory does not contain a Workbench installation record.' }
if ($state.installDirectory -ne $InstallDirectory -or $state.manifestPath -ne $manifestPath) { throw 'The installation record does not match this directory.' }
if (Test-Path -LiteralPath $registryPath) {
    $current = (Get-Item -LiteralPath $registryPath).GetValue('')
    if ($current -eq $manifestPath) { Remove-Item -LiteralPath $registryPath -Force }
}
foreach ($path in $files) { if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force } }
if ((Test-Path -LiteralPath $native -PathType Container) -and @(Get-ChildItem -LiteralPath $native -Force).Count -eq 0) { Remove-Item -LiteralPath $native }
$plan | ConvertTo-Json -Depth 5
