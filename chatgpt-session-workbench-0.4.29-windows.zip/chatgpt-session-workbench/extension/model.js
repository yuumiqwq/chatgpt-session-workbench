/* Shared pure model: classic script also works under file://. */
(function (root) {
  'use strict';
  const VERSION = 2;
  const MAX_ITEMS = 10000;
  const MAX_CATEGORIES = 500;
  const REMOVED = 'archive:removed';
  const UUID = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}';
  const ownObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const emptyState = () => ({ version: VERSION, categories: [], projects: [], bookmarks: [] });
  const DEMO_IDS = Object.freeze(['demo:example-1', 'demo:example-2']);
  function demoLink(input) {
    if (input.kind !== 'demo' || !DEMO_IDS.includes(input.id) || input.url !== 'https://chatgpt.com/') throw Error('示例链接无效。');
    return { kind: 'demo', id: input.id, url: input.url };
  }
  function demoState(now = Date.now()) {
    return { ...emptyState(), bookmarks: DEMO_IDS.map((id, index) => ({ ...demoLink({ kind: 'demo', id, url: 'https://chatgpt.com/' }),
      title: `示例${index + 1}`, categoryId: null, projectId: null, createdAt: now, updatedAt: now })) };
  }
  const isConversation = item => item.kind === 'chatgpt' || item.kind === 'codex';
  function label(value, name = '名称', max = 200) {
    if (typeof value !== 'string' || !value.trim() || value.trim().length > max || /[\u0000-\u001f\u007f]/u.test(value)) {
      throw new Error(`${name}须为 1–${max} 个字符，且不含控制字符。`);
    }
    return value.trim();
  }
  function normalizeURL(input) {
    if (typeof input !== 'string' || input.length > 2048) throw new Error('请输入有效的会话链接。');
    const value = input.trim();
    if (/[\s\\\u0000-\u001f\u007f]/u.test(value)) throw new Error('链接中含有无效字符。');
    const codex = value.match(new RegExp(`^codex://threads/(${UUID})$`, 'i'));
    if (codex) {
      const id = codex[1].toLowerCase();
      return { kind: 'codex', id: `codex:${id}`, url: `codex://threads/${id}` };
    }
    // Validate the original path before URL() can resolve dot segments or escapes.
    const chat = value.replace(/^https:\/\/chatgpt\.com/i, 'https://chatgpt.com').match(new RegExp(`^https://chatgpt\\.com(/(?:g/[a-zA-Z0-9_-]+/)?c/(${UUID}))/?(?:[?#][^\\s]*)?$`));
    if (!chat) throw new Error('仅支持 chatgpt.com 对话链接或 codex://threads/UUID。');
    const url = new URL(value);
    if (url.origin !== 'https://chatgpt.com' || url.username || url.password) throw new Error('ChatGPT 链接无效。');
    const id = chat[2].toLowerCase();
    const path = chat[1].slice(0, -chat[2].length) + id;
    return { kind: 'chatgpt', id: `chatgpt:${id}`, url: `https://chatgpt.com${path}` };
  }
  // Fixed native builtin:orbit destination; UI eligibility uses the separate manual Pro preference.
  function normalizeDotsURL(value) {
    if (value !== 'https://chatgpt.com/dots/home') throw Error('Dots 链接无效。');
    return value;
  }
  function normalizeDotsBinding(value) {
    if (value == null) return null;
    if (!ownObject(value)) throw Error('Dots 账户标识无效。');
    if (typeof value.contextId === 'string' && /^sha256:[0-9a-f]{64}$/.test(value.contextId)) return { contextId: value.contextId };
    // Preserve earlier backup bindings; current eligibility does not read these fields.
    return { accountId: label(value.accountId, '账户标识', 200), workspaceId: label(value.workspaceId, '工作区标识', 200) };
  }
  function dotsLink(input) {
    if (!new RegExp(`^dots:${UUID}$`).test(input.id)) throw Error('Dots 跟进标识无效。');
    return { kind: 'dots', id: input.id.toLowerCase(), url: normalizeDotsURL(input.url), binding: normalizeDotsBinding(input.binding) };
  }
  function categoryId(value) {
    if (typeof value !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(value) || ['all', 'unfiled'].includes(value)) throw new Error('类别 ID 无效。');
    return value;
  }
  function timestamp(value, fallback) {
    const n = typeof value === 'string' ? Date.parse(value) : value;
    if (Number.isSafeInteger(n) && n >= 0 && n <= 8640000000000000) return n;
    if (fallback !== undefined && value == null) return fallback;
    throw new Error('收藏时间无效。');
  }
  function normalizeArchive(items, { strict = false } = {}) {
    if (!Array.isArray(items)) throw new Error('归档列表格式无效。');
    const entries = new Map();
    let rejected = 0;
    for (const item of items) {
      try {
        if (!ownObject(item) || !new RegExp(`^archive:${UUID}$`).test(item.id)) throw new Error('归档标识无效。');
        const url = ['https://chatgpt.com/dots/home', 'https://chatgpt.com/'].includes(item.url) ? item.url : normalizeURL(item.url).url;
        const entry = { id: item.id.toLowerCase(), title: label(item.title, '收藏名称'), url,
          categoryName: label(item.categoryName, '类别名称', 60), removedAt: timestamp(item.removedAt) };
        if (Object.hasOwn(item, 'categoryId')) entry.categoryId = item.categoryId == null ? null : categoryId(item.categoryId);
        const previous = entries.get(entry.id);
        if (previous && JSON.stringify(previous) !== JSON.stringify(entry)) throw new Error('归档标识冲突。');
        entries.set(entry.id, entry);
      } catch (error) { if (strict) throw error; rejected++; }
    }
    return { archive: [...entries.values()], rejected };
  }
  function mergeArchive(existing = [], incoming = []) {
    return normalizeArchive([...existing, ...incoming], { strict: true }).archive;
  }
  function normalizeState(raw, { strict = false, includeArchive = true } = {}) {
    if (raw == null && !strict) return { state: emptyState(), rejected: 0, migrated: false };
    if (!ownObject(raw) || ![undefined, 0, 1, VERSION].includes(raw.version)) throw new Error('备份格式或版本不受支持。');
    const legacy = raw.version !== VERSION;
    const categories = legacy ? raw.projects : raw.categories;
    if (!Array.isArray(categories) || !Array.isArray(raw.bookmarks) || (!legacy && !Array.isArray(raw.projects))) throw new Error('缺少类别、项目或收藏列表。');
    if (categories.length > MAX_CATEGORIES || raw.bookmarks.length > MAX_ITEMS || (!legacy && raw.projects.length > MAX_ITEMS)) throw new Error('类别或收藏数量超过上限。');
    const state = emptyState();
    let rejected = 0;
    if (raw.archive !== undefined) {
      if (includeArchive) {
        const result = normalizeArchive(raw.archive, { strict });
        state.archive = result.archive; rejected += result.rejected;
      } else state.archive = raw.archive;
    }
    if (typeof raw.archiveRevision === 'string') state.archiveRevision = raw.archiveRevision;
    const attempt = fn => { try { fn(); } catch (error) { if (strict) throw error; rejected++; } };
    for (const item of categories) attempt(() => {
      if (!ownObject(item)) throw new Error('类别格式无效。');
      const id = categoryId(item.id);
      const name = label(item.name, '类别名称', 60);
      if (state.categories.some(p => p.id === id)) throw new Error('类别 ID 重复。');
      state.categories.push({ id, name });
    });
    if (!legacy) for (const item of raw.projects) attempt(() => {
      if (!ownObject(item)) throw new Error('项目格式无效。');
      const id = categoryId(item.id);
      if (state.projects.some(p => p.id === id)) throw new Error('项目 ID 重复。');
      const category = ensureCategory(state, item.categoryId);
      state.projects.push({ id, name: label(item.name, '项目名称', 60), categoryId: category });
    });
    const bookmarks = new Map();
    for (const item of raw.bookmarks) attempt(() => {
      if (!ownObject(item)) throw new Error('收藏格式无效。');
      const link = item.kind === 'demo' ? demoLink(item) : item.kind === 'dots' ? dotsLink(item) : normalizeURL(item.url);
      if (item.kind !== undefined && item.kind !== link.kind) throw new Error('收藏类型与链接不符。');
      const title = label(item.title, '收藏名称');
      const createdAt = timestamp(item.createdAt, raw.version === VERSION || raw.version === 1 ? undefined : 0);
      const updatedAt = timestamp(item.updatedAt, createdAt);
      const oldCategory = legacy ? item.projectId : item.categoryId;
      if (oldCategory != null) categoryId(oldCategory);
      const category = state.categories.some(p => p.id === oldCategory) ? oldCategory : null;
      const project = legacy ? null : item.projectId ?? null;
      if (project !== null && !state.projects.some(p => p.id === project && p.categoryId === category)) throw new Error('项目与收藏类别不一致。');
      const fields = isConversation(link) ? conversationFields({ ...item, replyState: undefined }) : {};
      // An invalid optional observation must never hide an otherwise valid bookmark.
      if (isConversation(link) && item.replyState != null) attempt(() => { fields.replyState = normalizeReplyState(item.replyState); });
      const entry = { ...link, title, categoryId: category, projectId: project, createdAt, updatedAt, ...fields };
      const previous = bookmarks.get(link.id);
      if (!previous || entry.updatedAt > previous.updatedAt) bookmarks.set(link.id, entry);
    });
    state.bookmarks = [...bookmarks.values()];
    return { state: pruneProjects(state), rejected, migrated: raw.version !== VERSION };
  }
  function ensureCategory(state, id) {
    if (id == null || id === '') return null;
    if (!state.categories.some(p => p.id === id)) throw new Error('类别已被删除，请重新选择。');
    return id;
  }
  function addBookmark(state, input, now = Date.now()) {
    const link = input.kind === 'dots' ? dotsLink(input) : normalizeURL(input.url);
    const title = label(input.title, '收藏名称');
    const category = ensureCategory(state, input.categoryId);
    const previous = state.bookmarks.find(b => b.id === link.id);
    if (!previous && state.bookmarks.length >= MAX_ITEMS) throw new Error('收藏数量已达上限。');
    const project = resolveProject(state, input, category, previous);
    if (link.kind === 'dots' && previous) throw Error('Dots 跟进标识已存在。');
    const fields = link.kind === 'dots' ? {} : { ...conversationFields(previous || {}), ...conversationFields(input) };
    const entry = { ...link, title, categoryId: category, projectId: project, createdAt: previous?.createdAt ?? now, updatedAt: now, ...fields };
    return pruneProjects({ ...state, bookmarks: [entry, ...state.bookmarks.filter(b => b.id !== link.id)] });
  }
  function updateBookmark(state, input, now = Date.now()) {
    const previous = state.bookmarks.find(b => b.id === input.id);
    if (!previous) throw new Error('收藏已被移除。');
    const title = label(input.title, '收藏名称');
    const category = ensureCategory(state, input.categoryId);
    const project = resolveProject(state, input, category, previous);
    return pruneProjects({ ...state, bookmarks: state.bookmarks.map(b => b.id === input.id ? { ...b, title, categoryId: category, projectId: project, updatedAt: now } : b) });
  }
  function createCategory(state, input) {
    if (state.categories.length >= MAX_CATEGORIES) throw new Error('类别数量已达上限。');
    const name = label(input.name, '类别名称', 60);
    const id = categoryId(input.id);
    if (state.categories.some(p => p.id === id || p.name === name)) throw new Error('类别已存在。');
    return { ...state, categories: [...state.categories, { id, name }] };
  }
  function moveBookmark(state, input, now = Date.now()) {
    const previous = state.bookmarks.find(b => b.id === input.id);
    if (!previous) throw new Error('收藏已被移除。');
    const category = ensureCategory(state, input.categoryId);
    if (previous.categoryId === category && !previous.projectId) return state;
    return pruneProjects({ ...state, bookmarks: state.bookmarks.map(b => b.id === input.id ? { ...b, categoryId: category, projectId: null, updatedAt: now } : b) });
  }
  function reorderCategory(state, input) {
    const index = state.categories.findIndex(p => p.id === input.id);
    if (index < 0) throw new Error('类别已被删除。');
    const categories = [...state.categories];
    if (input.direction === 'up' || input.direction === 'down') {
      const next = index + (input.direction === 'up' ? -1 : 1);
      if (next < 0 || next >= categories.length) return state;
      [categories[index], categories[next]] = [categories[next], categories[index]];
    } else {
      if (!['before', 'after'].includes(input.position) || !categories.some(p => p.id === input.targetId)) throw new Error('类别排序位置无效。');
      if (input.id === input.targetId) return state;
      const [category] = categories.splice(index, 1);
      const target = categories.findIndex(p => p.id === input.targetId);
      categories.splice(target + (input.position === 'after' ? 1 : 0), 0, category);
    }
    return { ...state, categories };
  }
  function renameCategory(state, input) {
    ensureCategory(state, input.id);
    const name = label(input.name, '类别名称', 60);
    if (state.categories.some(p => p.id !== input.id && p.name === name)) throw new Error('类别名称已存在。');
    return { ...state, categories: state.categories.map(p => p.id === input.id ? { ...p, name } : p) };
  }
  function deleteCategory(state, id) {
    ensureCategory(state, id);
    return pruneProjects({ ...state, categories: state.categories.filter(p => p.id !== id), bookmarks: state.bookmarks.map(b => b.categoryId === id ? { ...b, categoryId: null, projectId: null } : b) });
  }
  function pruneProjects(state) {
    const counts = new Map();
    for (const b of state.bookmarks) if (b.projectId) counts.set(b.projectId, (counts.get(b.projectId) || 0) + 1);
    const projects = state.projects.filter(p => counts.get(p.id) >= 2);
    const retained = new Set(projects.map(p => p.id));
    return { ...state, projects, bookmarks: state.bookmarks.map(b => b.projectId && !retained.has(b.projectId) ? { ...b, projectId: null } : b) };
  }
  function resolveProject(state, input, category, previous) {
    const id = Object.hasOwn(input, 'projectId') ? input.projectId || null : previous?.categoryId === category ? previous.projectId : null;
    if (id && !state.projects.some(p => p.id === id && p.categoryId === category)) throw new Error('项目已变更，请重新选择。');
    return id ?? null;
  }
  function createProject(state, input, now = Date.now()) {
    const target = state.bookmarks.find(b => b.id === input.targetId);
    const source = state.bookmarks.find(b => b.id === input.sourceId);
    if (!target || !source || target.id === source.id) throw new Error('请选择两个不同的收藏。');
    if (source.projectId) return source.projectId === target.projectId ? state : detachBookmark(state, source.id);
    if (target.projectId || source.categoryId !== target.categoryId) return state;
    const id = categoryId(input.id);
    if (state.projects.some(p => p.id === id)) throw new Error('项目 ID 已存在。');
    const name = label(input.name, '项目名称', 60);
    const project = { id, name, categoryId: target.categoryId };
    return pruneProjects({ ...state, projects: [...state.projects, project], bookmarks: state.bookmarks.map(b => [source.id, target.id].includes(b.id) ? { ...b, categoryId: project.categoryId, projectId: id, updatedAt: now } : b) });
  }
  function joinProject(state, input, now = Date.now()) {
    const project = state.projects.find(p => p.id === input.projectId);
    if (!project) throw new Error('项目已被删除。');
    const source = state.bookmarks.find(b => b.id === input.id);
    if (!source) throw new Error('收藏已被移除。');
    if (source.projectId === project.id) return state;
    if (source.projectId) return detachBookmark(state, source.id);
    if (source.categoryId !== project.categoryId) return state;
    return pruneProjects({ ...state, bookmarks: state.bookmarks.map(b => b.id === input.id ? { ...b, categoryId: project.categoryId, projectId: project.id, updatedAt: now } : b) });
  }
  function renameProject(state, input) {
    if (!state.projects.some(p => p.id === input.id)) throw new Error('项目已被删除。');
    const name = label(input.name, '项目名称', 60);
    return { ...state, projects: state.projects.map(p => p.id === input.id ? { ...p, name } : p) };
  }
  function dissolveProject(state, id) {
    if (!state.projects.some(p => p.id === id)) throw new Error('项目已被删除。');
    return { ...state, projects: state.projects.filter(p => p.id !== id), bookmarks: state.bookmarks.map(b => b.projectId === id ? { ...b, projectId: null } : b) };
  }
  function detachBookmark(state, id) {
    const source = state.bookmarks.find(b => b.id === id);
    if (!source) throw new Error('收藏已被移除。');
    if (!source.projectId) return state;
    return pruneProjects({ ...state, bookmarks: state.bookmarks.map(b => b.id === id ? { ...b, projectId: null } : b) });
  }
  function removeBookmark(state, id, now = Date.now()) {
    const bookmark = state.bookmarks.find(item => item.id === id);
    if (!bookmark) return state;
    const entry = { id: `archive:${crypto.randomUUID()}`, title: bookmark.title, url: bookmark.url,
      categoryName: state.categories.find(item => item.id === bookmark.categoryId)?.name || '未分类', categoryId: bookmark.categoryId, removedAt: now };
    return pruneProjects({ ...state, bookmarks: state.bookmarks.filter(item => item.id !== id),
      archive: mergeArchive(state.archive, [entry]) });
  }
  function archiveCategory(state, entry) {
    if (Object.hasOwn(entry, 'categoryId')) return state.categories.some(c => c.id === entry.categoryId) ? entry.categoryId : null;
    const matches = state.categories.filter(c => c.name === entry.categoryName);
    return matches.length === 1 ? matches[0].id : null;
  }
  function editArchive(state, input) {
    const entry = state.archive?.find(item => item.id === input.id);
    if (!entry) throw Error('归档已被恢复或移除，请重新打开列表。');
    const category = state.categories.find(c => c.id === input.categoryId);
    return { ...state, archive: state.archive.map(item => item.id === entry.id ? { ...item,
      title: label(input.title, '收藏名称'), categoryId: category?.id || null, categoryName: category?.name || '未分类' } : item) };
  }
  function restoreArchive(state, input, now = Date.now()) {
    const edited = editArchive(state, input), entry = edited.archive.find(item => item.id === input.id);
    const link = entry.url === 'https://chatgpt.com/dots/home' ?
      { kind: 'dots', id: `dots:${crypto.randomUUID()}`, url: entry.url, binding: null } :
      entry.url === 'https://chatgpt.com/' ? demoLink({ kind: 'demo', id: DEMO_IDS[0], url: entry.url }) : normalizeURL(entry.url);
    if (link.kind !== 'dots' && state.bookmarks.some(b => b.id === link.id || b.url === link.url)) throw Error('此链接已收藏，请先处理已有收藏；归档已保留。');
    if (state.bookmarks.length >= MAX_ITEMS) throw Error('收藏数量已达上限。');
    const bookmark = { ...link, title: entry.title, categoryId: entry.categoryId, projectId: null, createdAt: now, updatedAt: now };
    return { ...state, bookmarks: [bookmark, ...state.bookmarks], archive: state.archive.filter(item => item.id !== entry.id) };
  }
  function mergeImport(state, raw) {
    const incoming = normalizeState(raw, { strict: true }).state;
    let result = { ...state, categories: [...state.categories], projects: [...state.projects], bookmarks: [...state.bookmarks] };
    const mapping = new Map();
    for (const p of incoming.categories) {
      const same = result.categories.find(q => q.name === p.name);
      if (same) { mapping.set(p.id, same.id); continue; }
      let id = p.id;
      let suffix = 1;
      while (result.categories.some(q => q.id === id)) id = `${p.id.slice(0, 65)}_import_${suffix++}`;
      result = createCategory(result, { id, name: p.name });
      mapping.set(p.id, id);
    }
    // Existing entries win; importing the same backup is idempotent.
    const ids = new Set(result.bookmarks.map(b => b.id));
    const projectMapping = new Map();
    for (const p of incoming.projects) {
      if (!incoming.bookmarks.some(b => b.projectId === p.id && !ids.has(b.id))) continue;
      const category = mapping.get(p.categoryId) ?? null;
      const same = result.projects.find(q => q.id === p.id && q.name === p.name && q.categoryId === category);
      let id = same?.id ?? p.id;
      let suffix = 1;
      if (!same) {
        while (result.projects.some(q => q.id === id)) id = `${p.id.slice(0, 65)}_import_${suffix++}`;
        result.projects.push({ ...p, id, categoryId: category });
      }
      projectMapping.set(p.id, id);
    }
    for (const b of incoming.bookmarks) {
      if (!ids.has(b.id)) { result.bookmarks.push({ ...b, categoryId: mapping.get(b.categoryId) ?? null, projectId: projectMapping.get(b.projectId) ?? null }); ids.add(b.id); }
    }
    if (result.bookmarks.length > MAX_ITEMS) throw new Error('合并后收藏数量超过上限。');
    if (state.archive !== undefined || incoming.archive !== undefined) result.archive = mergeArchive(state.archive, incoming.archive);
    return pruneProjects(result);
  }
  function conversationFields(item) {
    const fields = {};
    if (item.replyState != null) fields.replyState = normalizeReplyState(item.replyState);
    for (const key of ['lastConversationAt', 'activityAt']) {
      if (item[key] != null) fields[key] = timestamp(item[key]);
    }
    return fields;
  }
  // Observation time orders captures only; it never becomes a conversation timestamp.
  function messageId(value) {
    if (value == null) return null;
    if (typeof value !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(value)) throw new Error('消息标识无效。');
    return value;
  }
  function normalizeReplyState(value) {
    if (!ownObject(value) || !['user', 'assistant', 'tool'].includes(value.author) ||
        !['complete', 'generating', 'unknown', 'awaiting_permission'].includes(value.phase) ||
        (value.phase === 'awaiting_permission' && value.author === 'user') ||
        !Number.isSafeInteger(value.revision) || value.revision < 1) throw new Error('回复状态无效。');
    if (value.retiredMessageIds != null && (!Array.isArray(value.retiredMessageIds) || value.retiredMessageIds.length > 256)) throw new Error('回复历史标识无效。');
    return { author: value.author, phase: value.phase, messageId: messageId(value.messageId),
      userMessageId: messageId(value.userMessageId), observedAt: timestamp(value.observedAt), revision: value.revision,
      ...(value.retiredMessageIds?.length ? { retiredMessageIds: value.retiredMessageIds.map(messageId) } : {}) };
  }
  function awaitingReply(bookmark) {
    return isConversation(bookmark) && bookmark.replyState?.author === 'assistant' && bookmark.replyState.phase === 'complete';
  }
  function awaitingPermission(bookmark) {
    return isConversation(bookmark) && ['assistant', 'tool'].includes(bookmark.replyState?.author) && bookmark.replyState.phase === 'awaiting_permission';
  }
  function replyCounts(state) {
    const counts = new Map();
    for (const b of state.bookmarks) if (awaitingReply(b)) counts.set(b.categoryId, (counts.get(b.categoryId) || 0) + 1);
    return counts;
  }
  function observeReply(state, input, decision = () => {}) {
    // Older callers supplied an unused timestamp as the third argument.
    if (typeof decision !== 'function') decision = () => {};
    const keep = reason => { decision(reason); return state; };
    const b = state.bookmarks.find(b => b.id === input.id);
    if (!b || b.kind !== 'chatgpt') return keep('not-bookmarked');
    const previous = b.replyState;
    const next = normalizeReplyState({ ...input, retiredMessageIds: undefined, revision: (previous?.revision || 0) + 1 });
    if (!Number.isSafeInteger(input.baseRevision) || input.baseRevision < 0 ||
        !Array.isArray(input.userMessageIds) || input.userMessageIds.length > 256 ||
        input.precedingMessageIds != null && (!Array.isArray(input.precedingMessageIds) || input.precedingMessageIds.length > 256)) throw new Error('观测版本无效。');
    const users = input.userMessageIds.map(messageId);
    const preceding = (input.precedingMessageIds || []).map(messageId);
    if (previous) {
      const retired = previous.retiredMessageIds || [];
      if (retired.includes(next.messageId) || retired.includes(next.userMessageId)) return keep('retired-identity');
      const sameTurn = next.messageId && next.userMessageId && ['author', 'messageId', 'userMessageId'].every(key => previous[key] === next[key]);
      const matchesPrevious = value => value?.revision === previous.revision &&
        ['author', 'phase', 'messageId', 'userMessageId'].every(key => value[key] === previous[key]);
      const witnessedPrevious = matchesPrevious(input.prior);
      const followsMessage = previous.author !== 'user' && next.author !== 'user' && next.messageId &&
        next.messageId !== previous.messageId && next.userMessageId && next.userMessageId === previous.userMessageId &&
        previous.messageId && preceding.includes(previous.messageId);
      // The initial document read is fixed at its original revision. Later storage reads
      // never grant an old tab authority to skip a permission/clear cycle it did not see.
      const initialBaselineMatches = matchesPrevious(input.initialBaseline) && input.baseRevision === previous.revision;
      const permissionCleared = previous.phase === 'awaiting_permission' && sameTurn &&
        input.permissionCleared === true && witnessedPrevious && input.baseRevision === previous.revision;
      if (next.phase === 'unknown' && !permissionCleared) return keep('unknown-unproven');
      if (next.observedAt < previous.observedAt) return keep('older-observation');
      // Partial history hydration may briefly end at the user turn already answered.
      if ((previous.author === 'assistant' || previous.phase === 'awaiting_permission') && next.author === 'user' &&
          (!next.messageId || next.userMessageId === previous.userMessageId)) return keep('answered-user');
      // A completed UUID turn with both visible roles can replace a virtualized
      // transcript window. Unlike predecessor evidence, this proof never rebases
      // an old revision or equal timestamp, and retired identities stay rejected.
      const turn = input.completedTurn;
      const pairedCompletion = turn?.route === b.id && typeof turn.turnId === 'string' &&
        /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(turn.turnId) &&
        next.author === 'assistant' && next.phase === 'complete' &&
        next.messageId === `work-${turn.turnId}-assistant` && next.userMessageId === `work-${turn.turnId}-user` &&
        users.includes(next.userMessageId) && next.userMessageId !== previous.userMessageId &&
        input.baseRevision === previous.revision && next.observedAt > previous.observedAt;
      const active = input.activeTurn;
      const activeGeneration = active?.route === b.id && typeof active.turnId === 'string' &&
        /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(active.turnId) &&
        next.author === 'assistant' && ['generating', 'awaiting_permission'].includes(next.phase) &&
        next.messageId === `work-${active.turnId}-assistant` && next.userMessageId === `work-${active.turnId}-user` &&
        users.includes(next.userMessageId) && input.baseRevision === previous.revision && next.observedAt > previous.observedAt;
      // A fresh document may recover the same live Work permission turn only from
      // its exact initial revision and the collector's in_progress UUID proof.
      const initialContinuation = initialBaselineMatches && (['generating', 'complete'].includes(next.phase) ||
        sameTurn && activeGeneration && next.phase === 'awaiting_permission');
      if (previous.userMessageId && next.userMessageId !== previous.userMessageId &&
          (!next.userMessageId || !users.includes(previous.userMessageId)) && !pairedCompletion && !activeGeneration) return keep('missing-user-ancestry');
      const newUser = pairedCompletion || activeGeneration && next.userMessageId !== previous.userMessageId ||
        next.userMessageId && next.userMessageId !== previous.userMessageId && users.includes(previous.userMessageId);
      if (previous.author === 'assistant' && previous.phase === 'complete' && next.phase !== 'complete' &&
          !(next.userMessageId && next.userMessageId !== previous.userMessageId && users.includes(previous.userMessageId)) &&
          !(witnessedPrevious && input.baseRevision === previous.revision)) return keep('unwitnessed-restart');
      // A witnessed dismissal can continue under another assistant/tool message ID only
      // when the DOM also places the previous message before the current reply.
      if (previous.phase === 'unknown' && !newUser &&
          (!(sameTurn || followsMessage) || !(witnessedPrevious || initialContinuation))) return keep('unwitnessed-continuation');
      const answerToUser = previous.author === 'user' && next.author === 'assistant' &&
        next.userMessageId && next.userMessageId === previous.userMessageId;
      const finishesKnownMessage = previous.author === 'assistant' && previous.phase === 'generating' &&
        next.author === 'assistant' && next.phase === 'complete' && next.messageId &&
        next.messageId === previous.messageId && next.userMessageId === previous.userMessageId &&
        // A document still holding this message's earlier completion did not witness
        // its resumed generation. It must not use the late-completion exception.
        !(input.prior?.phase === 'complete' && input.prior.messageId === next.messageId);
      const laterMessage = followsMessage && !['awaiting_permission', 'unknown'].includes(previous.phase);
      if (input.baseRevision !== previous.revision && !newUser && !answerToUser && !finishesKnownMessage && !laterMessage) return keep('stale-revision');
      if (['author', 'phase', 'messageId', 'userMessageId'].every(key => previous[key] === next[key])) return keep('unchanged');
      const newlyRetired = [
        previous.author !== 'user' && previous.messageId !== next.messageId ? previous.messageId : null,
        previous.userMessageId !== next.userMessageId ? previous.userMessageId : null
      ].filter(Boolean);
      const retiredMessageIds = [...new Set([...retired, ...newlyRetired])].slice(-256);
      if (retiredMessageIds.length) next.retiredMessageIds = retiredMessageIds;
    } else if (input.baseRevision !== 0) return keep('uninitialized-revision');
    decision('accepted');
    return { ...state, bookmarks: state.bookmarks.map(item => item === b ? { ...item, replyState: next } : item) };
  }
  function conversationActivity(item) {
    return item.lastConversationAt ?? item.activityAt ?? null;
  }
  function sortedBookmarks(state, category = 'all', query = '') {
    const term = query.trim().toLocaleLowerCase();
    if (category === REMOVED) return (state.archive || []).filter(item =>
      item.title.toLocaleLowerCase().includes(term) || item.url.toLocaleLowerCase().includes(term) || item.categoryName.toLocaleLowerCase().includes(term))
      .sort((first, second) => second.removedAt - first.removedAt || first.id.localeCompare(second.id));
    return state.bookmarks.filter(b => (category === 'all' || b.categoryId === (category === 'unfiled' ? null : category)) && b.title.toLocaleLowerCase().includes(term))
      .sort((a, b) => (conversationActivity(b) ?? -1) - (conversationActivity(a) ?? -1) || b.createdAt - a.createdAt || a.id.localeCompare(b.id));
  }
  function sortedCategories(state) {
    return [...state.categories];
  }
  const api = { VERSION, REMOVED, emptyState, demoState, demoLink, isConversation, label, normalizeURL, normalizeDotsURL, normalizeDotsBinding, normalizeArchive, mergeArchive, normalizeState, addBookmark, updateBookmark, moveBookmark, removeBookmark, createCategory, reorderCategory, renameCategory, deleteCategory, createProject, joinProject, renameProject, dissolveProject, detachBookmark, mergeImport, sortedBookmarks, sortedCategories, conversationActivity, normalizeReplyState, observeReply, awaitingReply, awaitingPermission, replyCounts };
  Object.assign(api, { archiveCategory, editArchive, restoreArchive });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkModel = Object.freeze(api);
})(globalThis);
