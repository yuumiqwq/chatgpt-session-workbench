'use strict';
(() => {
  if (window.top !== window || !globalThis.chrome?.runtime?.id) return;
  if (globalThis.__workbenchRecoveryURL) {
    const expectedURL = globalThis.__workbenchRecoveryURL; delete globalThis.__workbenchRecoveryURL;
    if (location.href !== expectedURL) return;
  }
  const VERSION = '0.4.29';
  if (globalThis.__workbenchReceiver?.version === VERSION) {
    globalThis.__workbenchReceiver.ensure();
    return;
  }
  const receivers = [];
  const registerReceiver = listener => { receivers.push(listener); chrome.runtime.onMessage?.addListener(listener); };
  globalThis.__workbenchReceiver = { version: VERSION, ensure() {
    for (const listener of receivers) {
      chrome.runtime.onMessage?.removeListener?.(listener);
      chrome.runtime.onMessage?.addListener(listener);
    }
  } };
  const documentId = crypto.randomUUID();
  const documentStartedAt = Number.isFinite(globalThis.performance?.timeOrigin) ? globalThis.performance.timeOrigin : Date.now();
  const root = document.documentElement;
  root.setAttribute('data-workbench-version', VERSION);
  let loggedErrors = 0;
  const markerHistory = [];
  let markerCollector = () => null;
  function diagnose(stage, reason, observed, revision) {
    root.setAttribute('data-workbench-stage', stage);
    root.setAttribute('data-workbench-reason', `${VERSION}:${reason}`);
    if (stage.endsWith('-error') || /storage-|rejected/.test(reason)) {
      root.setAttribute('data-workbench-result', `${VERSION}:${reason}`);
    }
    const event = { stage, reason: `${VERSION}:${reason}`, phase: observed?.phase, revision };
    if (JSON.stringify(event) !== markerHistory.at(-1)?.key) {
      markerHistory.push({ ...event, at: Date.now(), key: JSON.stringify(event) });
      if (markerHistory.length > 16) markerHistory.shift();
    }
  }
  function failure(stage, error, fallback) {
    const code = /context invalidated/i.test(error?.message || '') ? 'context-invalidated' :
      /receiving end|message port|connection/i.test(error?.message || '') ? 'runtime-disconnected' : fallback;
    diagnose(stage, code);
    if (loggedErrors++ < 3) console.warn('[workbench reply]', { version: VERSION, stage, code });
  }
  diagnose('initializing', 'script-start');
  let rescanReply = async () => ({ initialized: false });
  let readHealth = () => ({id:null,documentId,routeEpoch:0,lastValidReadAt:null});
  // Only trusted interaction with this document transfers a refresh-owned tab to the user.
  // Activation alone also occurs when a background window loses its other tabs.
  let refreshClaimed = false, refreshOwned = false;
  for (const name of ['pointerdown', 'keydown', 'wheel']) document.addEventListener(name, event => {
    if (!event.isTrusted || refreshClaimed || !refreshOwned && !/#workbench-refresh-[a-z0-9-]+$/.test(location.href)) return;
    refreshClaimed = true;
    void chrome.runtime.sendMessage({ channel: 'session-bookmarks-refresh', action: 'claim' })
      .then(result => { if (!result?.adopted) refreshClaimed = false; }, () => { refreshClaimed = false; });
  }, true);
  const safeToReload = () => {
    const D = BookmarkChatDOM, tail = D.reply(document);
    return tail?.phase === 'complete' && !D.generationActive(document) && !D.composerText(D.composer(document)).trim();
  };
  registerReceiver((message, sender, respond) => {
    if (message?.channel !== 'session-bookmarks-refresh' || !['version', 'rescan', 'health'].includes(message.action) ||
        sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL('background.js')) return false;
    if (message.temporary === true) refreshOwned = true;
    const url = location.href;
    if(message.action==='health'){respond({version:VERSION,url,requestId:message.requestId,...readHealth()});return false;}
    if (message.action === 'version') {
      let safe = false;
      try { safe = safeToReload(); } catch { /* An unreadable document is not safe to reload. */ }
      const home = new URL(url).pathname === '/' && !new URL(url).hash.startsWith('#settings');
      if(home)try{safe=!BookmarkChatDOM.generationActive(document)&&!BookmarkChatDOM.composerText(BookmarkChatDOM.composer(document)).trim();}catch{}
      respond({ version: VERSION, url, documentId, documentStartedAt, safeToReload: safe }); return false;
    }
    (async () => {
      const result = message.id === 'dots:home' ? {id:message.id,...(await globalThis.BookmarkDotsUnread?.sample?.({requestId:message.requestId,documentId}) ||
        {initialized:false,noData:true})} : await rescanReply(message.id);
      // Reuse the collector's result; diagnostics must not repeat the full DOM scan.
      const diagnostic = message.id === 'dots:home' ? { stage: result.initialized?'completed':'observing', reason: `${VERSION}:${result.initialized?'unread-sampled':'no-valid-tail'}`, result: null } : {
        stage: root.getAttribute('data-workbench-stage'), reason: root.getAttribute('data-workbench-reason'), result: root.getAttribute('data-workbench-result') };
      const loads = (globalThis.performance?.getEntriesByType?.('resource') || []).filter(entry => {
        try { return new URL(entry.name).pathname === '/backend-api/conversations/' + message.id?.slice(8); } catch { return false; }
      });
      respond({ version: VERSION, url, ...result, documentId, documentStartedAt, routeEpoch:readHealth().routeEpoch, diagnostic, requestId: message.requestId,
        sampledAt: result.sampledAt ?? Date.now(), progress: { resources: loads.length, lastResourceAt: Math.round(loads.at(-1)?.responseEnd || 0),
          readyState: document.readyState }, initialized: location.href === url && result.initialized === true });
    })().catch(() => respond({ version: VERSION, url, initialized: false }));
    return true;
  });
  registerReceiver((message, sender, respond) => {
    if (message?.channel !== 'session-bookmarks-diagnostics' || message.action !== 'read' ||
        sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL('background.js')) return false;
    let id;
    try {
      const link = BookmarkModel.normalizeURL(location.href);
      if (link.kind !== 'chatgpt') return false;
      id = link.id;
    } catch { return false; }
    respond(BookmarkDiagnostics.readPage(document, BookmarkChatDOM, id, VERSION, markerCollector()));
    return false;
  });
  // Reply collection does not depend on optional tutorial or statistics setup.
  try { startReplyObserver(); root.setAttribute('data-workbench-collector', 'running'); diagnose('observing', 'observer-registered'); }
  catch (error) { root.setAttribute('data-workbench-collector', 'failed'); failure('init-error', error, 'reply-init-failed'); }
  let quickGuide = { hide() {}, check() {} };
  try {
  document.getElementById('session-bookmarks-quick')?.remove();
  const host = document.createElement('div');
  host.id = 'session-bookmarks-quick';
  host.style.setProperty('all', 'initial', 'important');
  const shadow = host.attachShadow({ mode: 'open' });
  const { style, button } = BookmarkQuickButton.create(document);
  // Reference Edge native side-panel header: 40 CSS px at matching page/panel zoom.
  // #add-current top = tools padding 10 + search outer height (44 + 2 borders) + gap 8.
  // 40 + 10 + 46 + 8 = 104; retains the existing fixed-header alignment model.
  style.textContent += `
    .quick-button { position: fixed; z-index: 2147483646;
      top: 104px; right: max(16px, env(safe-area-inset-right)); }
    .status { position: fixed; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); }
  `;
  button.hidden = true;
  registerReceiver((message, sender, respond) => {
    if (sender.id === chrome.runtime.id && message?.channel === BookmarkOnboarding.CHANNEL && message.action === 'quick-geometry') {
      respond({ geometry: BookmarkQuickButton.geometry(button, window) });
    }
  });
  const status = document.createElement('span');
  status.className = 'status'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  shadow.append(style, button, status);
  document.documentElement.append(host);
  let currentURL = '';
  let sequence = 0;
  let bookmarked = false;
  let scheduled = false, invalidated = false;
  const request = BookmarkQuickButton.createClient(chrome.runtime);
  function showQuickError(error, action) {
    const detail = BookmarkQuickButton.failure(error);
    invalidated = detail.reload;
    button.title = detail.reload ? detail.message : action === 'quick-add' ? '收藏失败：' + detail.message : '无法检查收藏：' + detail.message;
    button.setAttribute('aria-label', button.title);
    status.textContent = button.title;
    root.setAttribute('data-workbench-quick-stage', action);
    root.setAttribute('data-workbench-quick-error', detail.code);
  }
  function paint(saved) {
    bookmarked = saved;
    invalidated = false;
    root.removeAttribute('data-workbench-quick-error');
    root.setAttribute('data-workbench-quick-stage', saved ? 'saved' : 'ready');
    const label = saved ? '此页面已收藏' : '收藏当前对话';
    if (button.title !== label) button.title = label;
    if (button.getAttribute('aria-label') !== label) button.setAttribute('aria-label', label);
    if (button.getAttribute('aria-disabled') !== String(saved)) button.setAttribute('aria-disabled', String(saved));
  }
  async function refresh(force = false) {
    const url = location.href;
    if (!force && url === currentURL) return;
    currentURL = url;
    const ticket = ++sequence;
    status.textContent = '';
    try {
      if (BookmarkModel.normalizeURL(url).kind !== 'chatgpt') throw new Error();
    } catch { button.hidden = true; quickGuide.hide(); return; }
    button.hidden = false; button.disabled = true; paint(false);
    try {
      const saved = await request('quick-check', url);
      if (ticket === sequence && location.href === url) paint(saved);
    } catch (error) {
      if (ticket === sequence) showQuickError(error, 'quick-check');
    } finally { if (ticket === sequence) { button.disabled = invalidated; if (!invalidated) void quickGuide.check(); } }
  }
  button.addEventListener('click', async () => {
    if (button.disabled) return;
    if (currentURL !== location.href) { await refresh(); return; }
    if (bookmarked) return;
    const url = currentURL;
    const ticket = ++sequence;
    button.disabled = true;
    try {
      const saved = await request('quick-add', url);
      if (ticket === sequence && location.href === url) { paint(saved); status.textContent = '已收藏'; }
    } catch (error) {
      if (ticket === sequence) showQuickError(error, 'quick-add');
    } finally { if (ticket === sequence) { button.disabled = invalidated; if (!invalidated) void quickGuide.check(); } }
  });
  function scheduleRefresh() {
    if (scheduled || location.href === currentURL) return;
    scheduled = true;
    queueMicrotask(() => { scheduled = false; void refresh(); });
  }
  // Navigation API observes pushState/replaceState across isolated worlds.
  window.navigation?.addEventListener('currententrychange', scheduleRefresh);
  window.addEventListener('popstate', scheduleRefresh);
  window.addEventListener('hashchange', scheduleRefresh);
  window.addEventListener('pageshow', () => { void refresh(true); });
  new MutationObserver(scheduleRefresh).observe(document.documentElement, { childList: true, subtree: true });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.sessionBookmarks) void refresh(true);
  });
  quickGuide = BookmarkQuickGuide.createPrompt({ document, window, button, shadow, location, chrome });
  void refresh();
  } catch (error) { failure('optional-error', error, 'quick-guide-init-failed'); }
  try { startStatisticsObserver(); }
  catch (error) { failure('optional-error', error, 'statistics-init-failed'); }

  function startStatisticsObserver() {
    const D = BookmarkChatDOM, S = BookmarkStatistics;
    const startedAt = Date.now();
    let timer, sending = false, retryTimer, ready = false, suspended = false;
    const outbox = [];
    function getRoute() {
      try { return BookmarkModel.normalizeURL(location.href).id; }
      catch { return `new:${new URL(location.href).pathname}`; }
    }
    const tracker = S.createTracker({ route: getRoute(), entries: D.messages(document), readText: D.userText,
      newId: () => crypto.randomUUID() });
    async function flush() {
      if (sending || suspended) return;
      clearTimeout(retryTimer); retryTimer = null;
      sending = true;
      try {
        if (!ready) {
          const result = await chrome.runtime.sendMessage({ channel: 'session-bookmarks-statistics', action: 'stats-start', startedAt });
          if (!result?.ok) throw Error();
          ready = true;
        }
        while (outbox.length && !suspended) {
          const result = await chrome.runtime.sendMessage({ channel: 'session-bookmarks-statistics', action: 'stats-record', event: outbox[0] });
          if (!result?.ok) throw Error();
          outbox.shift();
        }
      } catch {
        // Retry the same metadata transaction if the service worker/storage was temporarily unavailable.
        if (!suspended && !retryTimer) retryTimer = setTimeout(() => { retryTimer = null; void flush(); }, 5000);
      } finally { sending = false; }
    }
    function inspect() {
      if (!tracker.hasPending) return;
      const entries = D.messages(document), route = getRoute();
      const record = tracker.observe({ entries, route });
      if (record) { outbox.push(record); void flush(); }
    }
    function schedule() {
      if (!suspended && !timer && tracker.hasPending) timer = setTimeout(() => { timer = null; inspect(); }, 50);
    }
    function begin() {
      const composer = D.composer(document);
      if (!composer) return;
      // Consume a preceding confirmed send before beginning a second, possibly identical, message.
      inspect();
      tracker.begin({ route: getRoute(), entries: D.messages(document), text: D.composerText(composer) });
      schedule();
    }
    document.addEventListener('click', event => { if (D.sendButton(event.target)) begin(); }, true);
    document.addEventListener('keydown', event => {
      if (event.key !== 'Enter' || event.shiftKey || event.altKey || event.isComposing || event.keyCode === 229 || event.repeat) return;
      const composer = D.composer(document);
      if (composer && (event.target === composer || composer.contains(event.target))) begin();
    }, true);
    document.addEventListener('submit', event => {
      const composer = D.composer(document);
      if (composer && event.target.contains(composer) && (!event.submitter || D.sendButton(event.submitter))) begin();
    }, true);
    new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true,
      attributeFilter: ['data-message-id', 'data-message-author-role', 'data-turn-key', 'data-talvt-turn-state', 'hidden', 'inert', 'aria-hidden', 'class', 'style'] });
    window.navigation?.addEventListener('currententrychange', schedule);
    for (const event of ['popstate', 'hashchange']) window.addEventListener(event, schedule);
    window.addEventListener('pageshow', event => {
      suspended = false;
      if (event.persisted) tracker.reset({ route: getRoute(), entries: D.messages(document) });
      schedule();
      if (!ready || outbox.length) void flush();
    });
    window.addEventListener('pagehide', () => {
      suspended = true;
      clearTimeout(timer); timer = null;
      clearTimeout(retryTimer); retryTimer = null;
    });
    void flush();
  }

  function startReplyObserver() {
    const D = BookmarkChatDOM;
    let route = null, epoch = 0, baseRevision = 0, enabled = false;
    let timer, checked = false, checking = false, checkAgain = false, sending = false, lastSignature = '', validatedSignature = '';
    let lastCheckAt = 0;
    let probeTimer, checkTimer, checkRetries = 0, hydrationTries = 0, probeStep = 0, probeMode = '', tailSignal = '', tailNode = null, inspectAgain = false, suspended = false;
    let observedAt = 0, latestObserved = null, lastDecision = null, snapshotReason = 'not-sampled';
    async function requestReply(message) {
      let deadline;
      try { return await Promise.race([chrome.runtime.sendMessage(message), new Promise((_, reject) => {
        deadline = setTimeout(() => reject(Error('reply-request-timeout')), document.hidden ? 5000 : 1000);
      })]); } finally { clearTimeout(deadline); }
    }
    const machine = D.createReplyMachine();
    let debugState = '';
    function trace(state, reason, observed, revision = baseRevision) {
      diagnose(state, reason, observed, revision);
      const identity = `${state}:${observed?.messageId}:${revision}`;
      if (globalThis.BookmarkReplyDebug === true && identity !== debugState) {
        console.debug('[workbench reply]', { state, reason, route, turnId: observed?.messageId || null, revision });
      }
      debugState = identity;
    }
    let acknowledged = null, attempt = null, witnessedPermission = null, storedReply = null, storedRevision = 0, unprovenTail = false;
    // This baseline belongs to the new content document, not subsequent SPA visits or
    // storage notifications. It allows an already finished, freshly loaded reply to
    // recover from unknown without granting old tabs a fresh permission-exit revision.
    let initialRead = false, initialBaseline = null;
    let lastHealthNotice = '', lastEvidenceNotice = '';
    let healthEpoch=0, latestSample=null, health={currentValid:false,lastAttemptAt:null,lastRespondedAt:null,lastValidReadAt:null,failureSince:null,lastFailureReason:null};
    const resetHealth=()=>{healthEpoch++;latestSample=null;health={currentValid:false,lastAttemptAt:null,lastRespondedAt:null,lastValidReadAt:null,failureSince:null,lastFailureReason:null};};
    function validRead(sample, observed){
      if(sample!==latestSample||sample.epoch!==epoch||sample.routeEpoch!==healthEpoch||suspended||!checked||!enabled||checking||sending||baseRevision!==storedRevision||
        !sameReply(storedReply,acknowledged)||!sameReply(observed,acknowledged)||validatedSignature!==sample.signature||
        !acknowledged||acknowledged.phase==='unknown')return;
      Object.assign(health,{currentValid:true,lastValidReadAt:sample.at,failureSince:null,lastFailureReason:null});
      const notice = `${route}:${healthEpoch}:${baseRevision}`;
      if (notice !== lastHealthNotice) {
        lastHealthNotice = notice;
        // Notify after the current storage acknowledgement has left its sending phase.
        void Promise.resolve().then(() => chrome.runtime.sendMessage({ channel: 'session-bookmarks-receiver', action: 'changed', id: route, documentId, routeEpoch: healthEpoch, observation: { author: observed.author, phase: observed.phase, messageId: observed.messageId, userMessageId: observed.userMessageId } }))
          .catch(() => { if (lastHealthNotice === notice) lastHealthNotice = ''; });
      }
    }
    readHealth=()=>{syncRoute();return {id:route,documentId,documentStartedAt,routeEpoch:healthEpoch,...health,
      pending:checking||sending, storedRevision,
      replyState: acknowledged ? { author: acknowledged.author, phase: acknowledged.phase, messageId: acknowledged.messageId,
        userMessageId: acknowledged.userMessageId, revision: baseRevision } : null,
      observed: latestObserved ? { author: latestObserved.author, phase: latestObserved.phase,
        messageId: latestObserved.messageId, userMessageId: latestObserved.userMessageId,
        prior: acknowledged && baseRevision === storedRevision && sameReply(acknowledged, storedReply) ?
          { author: acknowledged.author, phase: acknowledged.phase, messageId: acknowledged.messageId,
            userMessageId: acknowledged.userMessageId, revision: baseRevision } : null } : null,
      currentValid:health.currentValid===true&&!checking&&!sending&&!suspended&&baseRevision===storedRevision&&sameReply(storedReply,acknowledged)};};
    const sameReply = (a, b) => a && b && ['author', 'phase', 'messageId', 'userMessageId'].every(key => a[key] === b[key]);
    const followsReply = (a, b) => a && b && a.author !== 'user' && b.author !== 'user' && b.messageId &&
      b.messageId !== a.messageId && b.userMessageId && b.userMessageId === a.userMessageId &&
      a.messageId && b.precedingMessageIds.includes(a.messageId);
    const ownership = new WeakMap();
    const messageRoutes = new Map();
    const userHeads = new Map(), knownUsers = new Set(), messageUsers = new Map();
    const sentUsers = new Map();
    let pendingSend = null;
    let previousNodes = [];
    markerCollector = () => ({ route, epoch, documentStartedAt, observedAt, observed: latestObserved,
      checked, enabled, checking, sending, suspended, baseRevision, storedRevision, stored: storedReply, acknowledged,
      lastCheckAt, snapshotReason, decision: lastDecision,
      attempt: attempt && { observedAt: attempt.observedAt, revision: attempt.revision, tries: attempt.tries, blocked: attempt.blocked },
      history: markerHistory, health:readHealth() });
    function getRoute() {
      try { const link = BookmarkModel.normalizeURL(location.href); return link.kind === 'chatgpt' ? link.id : null; }
      catch { return null; }
    }
    function syncRoute() {
      const next = getRoute();
      if (next === route) return;
      // Retained React nodes from the previous conversation are not evidence for the new URL.
      for (const item of previousNodes) if (!ownership.has(item.node)) ownership.set(item.node, { route, id: item.id });
      route = next; epoch++; baseRevision = 0; enabled = false;
      resetHealth();
      lastSignature = ''; validatedSignature = ''; machine.reset(); checked = false; checking = false; checkAgain = false; sending = false;
      acknowledged = null; attempt = null;
      unprovenTail = false;
      storedReply = null; storedRevision = 0;
      witnessedPermission = null;
      pendingSend = null;
      markerHistory.length = 0; observedAt = 0; latestObserved = null; lastDecision = null;
      clearTimeout(probeTimer); probeTimer = null;
      clearTimeout(checkTimer); checkTimer = null;
      checkRetries = 0; hydrationTries = 0; probeStep = 0; probeMode = ''; tailSignal = ''; tailNode = null; inspectAgain = false;
    }
    function snapshot(nodes = D.messages(document), busy) {
      const reject = reason => { snapshotReason = reason; return null; };
      snapshotReason = 'valid';
      previousNodes = nodes;
      if (!nodes.length) return reject('no-messages');
      const last = nodes.at(-1), owner = ownership.get(last.node);
      if (owner && owner.route !== route && owner.id === last.id) return reject('retained-route');
      if (last.id && messageRoutes.has(last.id) && messageRoutes.get(last.id) !== route) return reject('retained-route');
      for (const item of nodes) if (!ownership.has(item.node) || ownership.get(item.node).id !== item.id) ownership.set(item.node, { route, id: item.id });
      for (const item of nodes) if (item.id && !messageRoutes.has(item.id)) messageRoutes.set(item.id, route);
      while (messageRoutes.size > 512) messageRoutes.delete(messageRoutes.keys().next().value);
      const observed = D.reply(document, nodes, busy);
      // The live Work turn UUID identifies both roles even when its user has been
      // virtualized. Only that turn's explicit in-progress state supplies this proof.
      const activeTurn = D.activeTurnEvidence(nodes, observed);
      if (activeTurn && !observed.userMessageId) {
        observed.userMessageId = `work-${activeTurn.turnId}-user`;
        observed.userMessageIds = [observed.userMessageId];
      }
      // A surviving, previously witnessed assistant is a chronological anchor even
      // when its user node was virtualized away before the next submit event.
      const anchor = acknowledged && nodes.findIndex(item => item.id === acknowledged.messageId);
      const userIndex = nodes.findIndex(item => item.author === 'user' && item.id === observed.userMessageId);
      if (acknowledged?.userMessageId && anchor >= 0 && userIndex > anchor &&
          observed.userMessageId !== acknowledged.userMessageId) {
        observed.userMessageIds = [...new Set([acknowledged.userMessageId, ...observed.userMessageIds.slice(-255)])];
      }
      if (!observed.userMessageId && acknowledged?.messageId === observed.messageId && acknowledged.userMessageId) {
        observed.userMessageId = acknowledged.userMessageId;
        observed.userMessageIds = [acknowledged.userMessageId];
      }
      // Preserve a user identity actually witnessed for this same Work assistant,
      // even if its initial storage check failed before completion and virtualization.
      const witnessedUser = messageUsers.get(`${route}:${observed.messageId}`);
      if (!storedReply && !observed.userMessageId && observed.author === 'assistant' && observed.phase === 'complete' &&
          observed.messageId?.startsWith('work-') && witnessedUser === observed.messageId.replace(/-assistant$/, '-user') &&
          last.turn.getAttribute('data-talvt-turn-state') === 'complete') {
        observed.userMessageId = witnessedUser;
        observed.userMessageIds = [witnessedUser];
      }
      // A mounted complete Work turn can retain its verified user identity after user virtualization.
      // Saved metadata alone, or a different/unknown/permission tail, supplies no completion evidence.
      if (!observed.userMessageId && observed.author === 'assistant' && observed.phase === 'complete' &&
          (storedReply?.phase === 'complete' || storedReply?.phase === 'generating' && initialBaseline?.id === route &&
            initialBaseline.phase === 'generating' && initialBaseline.revision === storedRevision && sameReply(initialBaseline, storedReply)) &&
          storedReply.author === observed.author && storedReply.messageId === observed.messageId &&
          observed.messageId?.startsWith('work-') && storedReply.userMessageId === observed.messageId.replace(/-assistant$/, '-user') &&
          last.turn.getAttribute('data-talvt-turn-state') === 'complete') {
        observed.userMessageId = storedReply.userMessageId;
        observed.userMessageIds = [storedReply.userMessageId];
      }
      const head = userHeads.get(route), user = observed.userMessageId;
      const mountedUser = nodes.findLast(item => item.author === 'user' && item.id === user);
      if (observed.author === 'user' && head && user !== head && mountedUser &&
          !D.sendSummary(D.userText(mountedUser)).characters && !D.userHasAttachment(mountedUser)) return reject('empty-user');
      // A confirmed local send can replace the entire mounted transcript window.
      // Carry the witnessed predecessor IDs across that replacement, without
      // interpreting a click or a history-only DOM change as a completed send.
      if (pendingSend && Date.now() - pendingSend.at > 120000) pendingSend = null;
      const sentUser = pendingSend && nodes.findLast(item => item.author === 'user' && item.id === user);
      if (pendingSend && user && !pendingSend.known.has(`${route}:${user}`) &&
          sentUser && (pendingSend.characters || D.userHasAttachment(sentUser)) &&
          D.sendSummary(D.userText(sentUser)).digest === pendingSend.digest) {
        sentUsers.set(`${route}:${user}`, pendingSend.users);
        pendingSend = null;
      }
      const sentPredecessors = sentUsers.get(`${route}:${user}`);
      if (sentPredecessors) observed.userMessageIds = [...new Set([...sentPredecessors, ...observed.userMessageIds])].slice(-256);
      while (sentUsers.size > 256) sentUsers.delete(sentUsers.keys().next().value);
      // An initial in-progress UUID can be older mounted history. Require the
      // witnessed completed predecessor or a newly committed user's ancestry.
      if (storedReply?.author === 'assistant' && storedReply.phase === 'complete' && observed.phase !== 'complete' &&
          !sameReply(acknowledged, storedReply) &&
          !(user && user !== storedReply.userMessageId && observed.userMessageIds.includes(storedReply.userMessageId)))
        return reject('unwitnessed-restart');
      // React can retain/reorder an old turn. A previously seen user cannot become a new tail again.
      if (head && user && user !== head && knownUsers.has(`${route}:${user}`) && !sentPredecessors?.includes(head)) return reject('known-user-replay');
      if (observed.author !== 'user' && observed.messageId) {
        const key = `${route}:${observed.messageId}`;
        if (messageUsers.has(key) && messageUsers.get(key) !== user) return reject('message-user-conflict');
        if (user) messageUsers.set(key, user);
      }
      // Record known ownership for the whole visible history, not just its tail.
      // A retained earlier assistant must not become an answer to a later user
      // after reordering; absent user hydration is not a permanent null binding.
      const turnUsers = new Map(nodes.filter(item => item.author === 'user' && item.id).map(item => [item.turn, item.id]));
      let precedingUser = null;
      for (const item of nodes) {
        if (item.author === 'user') { precedingUser = item.id; continue; }
        const itemUser = item.id?.startsWith('work-') ? turnUsers.get(item.turn) : precedingUser;
        if (item.id && itemUser && !messageUsers.has(`${route}:${item.id}`)) messageUsers.set(`${route}:${item.id}`, itemUser);
      }
      // Keep this newly validated pair stable through the completion quiet window.
      // Previously seen old users were rejected above; this does not rebase storage.
      const completedTurn = D.completedTurnEvidence(nodes, observed);
      if (user && (!head || observed.userMessageIds.includes(head) || completedTurn || activeTurn)) userHeads.set(route, user);
      for (const id of observed.userMessageIds) knownUsers.add(`${route}:${id}`);
      while (knownUsers.size > 512) knownUsers.delete(knownUsers.values().next().value);
      while (messageUsers.size > 512) messageUsers.delete(messageUsers.keys().next().value);
      while (userHeads.size > 32) userHeads.delete(userHeads.keys().next().value);
      if (observed.phase === 'awaiting_permission') witnessedPermission = observed;
      if (completedTurn) observed.completedTurn = { ...completedTurn, route };
      if (activeTurn) observed.activeTurn = { ...activeTurn, route };
      return observed;
    }
    function schedule() {
      syncRoute();
      if (timer || suspended) return;
      // Leading bounded throttle: continual streaming mutations cannot postpone detection forever.
      timer = setTimeout(() => { timer = null; void inspect(); }, 100);
    }
    function watchTail(observed) {
      const active = observed?.author !== 'user' && observed?.phase === 'generating';
      const mode = active ? 'generating' : !observed || observed.author !== 'user' && observed.phase === 'unknown' ? 'hydration' : '';
      if (mode !== probeMode) {
        clearTimeout(probeTimer); probeTimer = null;
        probeMode = mode; probeStep = 0; hydrationTries = 0;
      }
      if (!mode || probeTimer || suspended || !route || !enabled || !active && hydrationTries >= 5) return;
      const delay = active ? [10000, 30000, 60000][Math.min(probeStep++, 2)] : [500, 1500, 5000, 15000, 30000][hydrationTries++];
      probeTimer = setTimeout(() => {
        probeTimer = null;
        syncRoute();
        if (suspended || !enabled) return;
        if (!active || D.replySignal(document, previousNodes.at(-1)) !== tailSignal) schedule();
        else {health.lastRespondedAt=Date.now();watchTail(observed);}
      }, delay);
    }
    function retryCheck() {
      if (checkTimer || suspended || checkRetries >= 3) return;
      checkTimer = setTimeout(() => { checkTimer = null; void check(); }, [500, 2000, 5000][checkRetries++]);
    }
    async function check() {
      syncRoute();
      if (!route) return;
      if (checking) { checkAgain = true; return; }
      const ticket = epoch, id = route;
      checking = true; checkAgain = false;
      lastCheckAt = Date.now();
      try {
        const result = await requestReply({ channel: 'session-bookmarks-reply', action: 'reply-check', id });
        if (ticket !== epoch || getRoute() !== id) return;
        if (!result?.ok) { diagnose('check-error', !result ? 'background-no-response' : ['reply-route-changed','reply-recovery-canceled'].includes(result.reason) ? result.reason : 'background-check-rejected'); retryCheck(); return; }
        clearTimeout(checkTimer); checkTimer = null; checkRetries = 0;
        // A delayed read must not replace metadata acknowledged by a newer write.
        if (result.bookmarked && result.revision !== 0 && result.revision < storedRevision) return;
        storedReply = result.current; storedRevision = result.revision;
        const initialPermission = !checked && result.current?.phase === 'awaiting_permission' &&
          result.current.observedAt <= documentStartedAt && sameReply(result.current, witnessedPermission);
        if (!initialRead) {
          initialRead = true;
          if (['unknown', 'generating'].includes(result.current?.phase) && result.current.observedAt <= documentStartedAt)
            initialBaseline = { id, ...result.current };
        }
        const observed = snapshot();
        const witnessed = sameReply(result.current, acknowledged) || sameReply(result.current, observed);
        const newUser = result.current?.userMessageId && observed?.userMessageId &&
          observed.userMessageId !== result.current.userMessageId && observed.userMessageIds.includes(result.current.userMessageId);
        const laterMessage = followsReply(result.current, observed) && !['awaiting_permission', 'unknown'].includes(result.current.phase);
        const activeTurn = observed?.activeTurn && result.current?.phase === 'complete' &&
          !(result.current.retiredMessageIds || []).some(value => value === observed.messageId || value === observed.userMessageId);
        const canRebase = witnessed || newUser || laterMessage || activeTurn;
        if (!enabled || result.revision === 0) {
          if (!enabled || baseRevision !== 0) { lastSignature = ''; acknowledged = null; attempt = null; }
          baseRevision = result.revision;
        } else if (result.revision >= baseRevision) {
          // Rebase only on a witnessed state or visible later user/message; an unseen
          // permission/clear cycle still cannot authorize an old tab's exit.
          if (canRebase) baseRevision = result.revision;
        }
        if (sameReply(result.current, observed)) { acknowledged = observed; lastSignature = JSON.stringify(observed); }
        else if (initialPermission) acknowledged = witnessedPermission;
        if (attempt && result.revision > (attempt.revision ?? baseRevision) && attempt.transportRevision == null && canRebase) {
          attempt.blocked = false;
          if (result.revision > (attempt.rebasedTo ?? -1)) {
            attempt.rebasedTo = result.revision;
            if (attempt.tries >= 2) attempt.tries = 0;
          }
          // New DOM evidence may have arrived before another tab's last metadata write.
          attempt.observedAt = Date.now();
        }
        enabled = result.bookmarked; checked = true;
      } catch (error) { failure('check-error', error, 'reply-check-failed'); retryCheck(); }
      finally {
        if (ticket === epoch) {
          checking = false;
          if (latestSample && latestObserved) validRead(latestSample, latestObserved);
          // A second storage event during the read still needs one coalesced fresh read.
          if (checkAgain) void check();
          if (enabled) schedule();
        }
      }
    }
    async function inspect() {
      syncRoute();
      if (!route) { diagnose('idle', 'unsupported-route'); return; }
      const entries = D.messages(document), last = entries.at(-1);
      const busy = last ? D.generationActive(document, last) : false;
      const nextSignal = D.replySignal(document, last, busy);
      if (nextSignal !== tailSignal || last?.node !== tailNode) {
        clearTimeout(probeTimer); probeTimer = null;
        tailSignal = nextSignal; tailNode = last?.node; probeStep = 0; hydrationTries = 0;
      }
      let observed = snapshot(entries, busy);
      observedAt = Date.now(); latestObserved = observed;
      let sample=Object.freeze({epoch,routeEpoch:healthEpoch,at:observedAt,signature:JSON.stringify(observed)});
      latestSample=sample;health.currentValid=false;
      health.lastAttemptAt=observedAt;health.lastRespondedAt=observedAt;
      if (observed && (observed.author === 'user' || ['generating','awaiting_permission'].includes(observed.phase)) && !sameReply(observed, storedReply)) {
        const notice = JSON.stringify([route, healthEpoch, storedRevision, observed.author, observed.phase, observed.messageId, observed.userMessageId]);
        if (notice !== lastEvidenceNotice) {
          lastEvidenceNotice = notice;
          void Promise.resolve().then(() => chrome.runtime.sendMessage({ channel: 'session-bookmarks-receiver', action: 'changed', id: route, documentId, routeEpoch: healthEpoch, observation: { author: observed.author, phase: observed.phase, messageId: observed.messageId, userMessageId: observed.userMessageId } }))
            .catch(() => { if (lastEvidenceNotice === notice) lastEvidenceNotice = ''; });
        }
      }
      watchTail(observed);
      if (!observed) diagnose('observing', 'no-valid-tail');
      if (!enabled) { if (!checked && !checking && !checkTimer) void check(); return; }
      if (!observed) { validatedSignature = ''; health.failureSince ??= observedAt;health.lastFailureReason='no-data';return; }
      if (sending) { inspectAgain = true; return; }
      // Active generation resets quiet time on every observation; its body digest is unused.
      // Resume fingerprinting immediately when generation ends to retain completion hydration checks.
      const transition = machine.observe(observed, observed.phase === 'generating' ? '' : D.replyFingerprint(document, last), Date.now(), busy);
      trace(transition.state, transition.reason, observed);
      if (transition.state === 'candidate') { validatedSignature = ''; health.lastFailureReason='candidate';schedule(); return; }
      observed = transition.value;
      // The quiet-time machine can confirm completion from an otherwise unknown
      // DOM tail. Health must describe that same accepted sample, not its raw input.
      latestObserved = observed;
      latestSample = sample = Object.freeze({ ...sample, signature: JSON.stringify(observed) });
      watchTail(observed);
      unprovenTail = Boolean(observed.completedTurn && storedReply?.author === 'assistant' &&
        storedReply.phase === 'complete' && storedReply.userMessageId !== observed.userMessageId &&
        !observed.userMessageIds.includes(storedReply.userMessageId));
      if (unprovenTail) { validatedSignature = '';health.lastFailureReason='unproven-history-tail'; trace('observing', 'unproven-history-tail', observed); return; }
      const signature = JSON.stringify(observed);
      const now = Date.now();
      if (attempt?.signature !== signature) attempt = { signature, observedAt: now, tries: 0, revision: null, blocked: false };
      if (signature === lastSignature) { validatedSignature = signature;validRead(sample,observed);return; }
      health.lastFailureReason='unacknowledged';
      if (attempt.blocked || attempt.tries >= 2 || attempt.tries && attempt.revision === baseRevision) return;
      const ticket = epoch, id = route, pending = attempt;
      pending.tries++; pending.revision = pending.transportRevision ?? baseRevision;
      lastDecision = { at: Date.now(), status: 'sending', revision: pending.revision };
      sending = true;
      try {
        const result = await requestReply({ channel: 'session-bookmarks-reply', action: 'reply-observe', id,
          observation: { ...observed, observedAt: pending.observedAt, baseRevision: pending.revision,
            ...(initialBaseline?.id === id ? { initialBaseline: { author: initialBaseline.author, phase: initialBaseline.phase,
              messageId: initialBaseline.messageId, userMessageId: initialBaseline.userMessageId, revision: initialBaseline.revision } } : {}),
            ...(acknowledged ? { prior: { author: acknowledged.author, phase: acknowledged.phase,
              messageId: acknowledged.messageId, userMessageId: acknowledged.userMessageId, revision: baseRevision } } : {}),
            permissionCleared: observed.phase === 'unknown' && acknowledged?.phase === 'awaiting_permission' &&
              ['author', 'messageId', 'userMessageId'].every(key => observed[key] && observed[key] === acknowledged[key]) } });
        if (ticket !== epoch || getRoute() !== id) return;
        if (!result?.ok) {
          lastDecision = { at: Date.now(), status: 'transport-error' };
          diagnose('send-error', 'background-observation-rejected');
          pending.transportRevision = pending.revision; pending.revision = null;
          return;
        }
        enabled = result.bookmarked;
        lastDecision = { at: Date.now(), status: result.accepted ? 'accepted' : result.synchronized ? 'synchronized' : 'rejected',
          reason: result.reason, revision: result.revision };
        if (result.revision >= storedRevision) { storedReply = result.current; storedRevision = result.revision; }
        if ((result.accepted || result.synchronized) && result.revision >= baseRevision) {
          baseRevision = result.revision; acknowledged = observed; lastSignature = signature;
          validatedSignature = signature;
          validRead(sample,observed);
          trace(transition.state, result.accepted ? 'storage-accepted' : 'storage-synchronized', observed);
        } else {
          health.lastFailureReason='state-conflict';
          trace(transition.state, 'stale-observation-rejected', observed, result.revision);
          // A check may unblock only a witnessed state or a proven later user/message.
          // Another tab's unseen permission state still cannot authorize a stale exit.
          pending.blocked = true;
          if (pending.tries === 1) await check();
        }
        schedule();
      } catch (error) {
        lastDecision = { at: Date.now(), status: /timeout/.test(error?.message || '') ? 'timeout' : 'transport-error' };
        failure('send-error', error, 'reply-observe-failed');
        // A transport error can retry once on a later event; rejected metadata follows the stricter rule above.
        pending.transportRevision = pending.revision;
        pending.revision = null;
      }
      finally {
        if (ticket === epoch) {
          sending = false;
          if (latestSample && latestObserved) validRead(latestSample, latestObserved);
          // Both a transport failure and a DOM event coalesced during I/O need a
          // follow-up even if this was the document's last mutation. The same
          // attempt keeps its original timestamp/revision and at most two sends.
          if (inspectAgain || pending.transportRevision != null && pending.tries < 2) schedule();
          inspectAgain = false;
        }
      }
    }
    rescanReply = async id => {
      syncRoute();
      if (!id || id !== route) return { id: route, initialized: false };
      const started=Date.now(),end=started+1100,ticket=epoch;let deadline;
      // One total receipt budget, including checks already in flight. The existing
      // collector can finish later; a pending confirmation never claims success.
      try { if (document.hidden) {
        // Hidden-page timers may be batched. Sample directly when idle and let
        // the collector finish outstanding storage work without a 25ms polling loop.
        if (!checked && !checking) void check();
        if (!checking && !sending) await inspect();
      } else await Promise.race([(async()=>{
        if (!checking && (!checked || Date.now()-lastCheckAt>=1000)) await check();
        while((checking||sending)&&Date.now()<end)await new Promise(resolve=>setTimeout(resolve,25));
        if(ticket===epoch&&getRoute()===id&&Date.now()<end)await inspect();
      })(),new Promise(resolve=>{deadline=setTimeout(resolve,1100);})]); }
      finally {clearTimeout(deadline);}
      if(ticket!==epoch||getRoute()!==id)return {id:route,initialized:false};
      const observed=latestObserved, current=readHealth();
      // Completion quiet time, storage acknowledgement and route identity must all agree.
      // A refresh never resets the state machine or grants a newer storage revision.
      return { id: route, sampledAt:latestSample?.at??started, pending:checking||sending||health.lastFailureReason==='candidate', initialized: current.currentValid && latestSample?.at>=started &&
        Boolean(observed && acknowledged && baseRevision === storedRevision && sameReply(storedReply, acknowledged) &&
          validatedSignature === JSON.stringify(observed) && sameReply(observed, acknowledged) &&
          (observed.phase !== 'unknown' || observed.author === 'user')),
        noData: checked && enabled && (!observed || observed.phase === 'unknown'),
        stateConflict: unprovenTail || Boolean(observed && storedReply && !sameReply(observed, storedReply) &&
          (attempt?.blocked || storedRevision !== baseRevision)),
        storedRevision, health:readHealth(),
        replyState: acknowledged ? { author: acknowledged.author, phase: acknowledged.phase, revision: baseRevision,
          messageId: acknowledged.messageId, userMessageId: acknowledged.userMessageId } : null };
    };
    const observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true,
      attributeFilter: ['data-message-author-role', 'data-message-id', 'data-conversation-role', 'data-chatgpt-agent-turn-start', 'data-turn-key', 'data-talvt-turn-state', 'data-is-streaming', 'data-message-status', 'data-user-message-bubble', 'data-content-search-unit-key', 'data-chatgpt-search-message-ids', 'aria-busy', 'data-testid', 'aria-label', 'disabled', 'aria-disabled', 'role', 'hidden', 'inert', 'aria-hidden', 'class', 'style'] });
    function sendingUser(kind) {
      syncRoute();
      const composer = D.composer(document), before = snapshot() || acknowledged;
      if (route && before?.userMessageId && composer) {
        const summary = D.sendSummary(D.composerText(composer));
        // Key/click and submit can describe one transaction after React cleared the
        // composer. Keep its original digest and pre-send identities through hydration.
        if (!pendingSend || summary.characters && summary.digest !== pendingSend.digest ||
            !summary.characters && kind !== 'submit' && Date.now() - pendingSend.at > 250) {
          pendingSend = { users: before.userMessageIds || [before.userMessageId], known: new Set(knownUsers), at: Date.now(), ...summary };
        }
      }
      schedule();
    }
    // The actual new user DOM commits the clear; drafts and failed sends do not.
    document.addEventListener('click', event => { if (D.sendButton(event.target)) sendingUser(); }, true);
    document.addEventListener('keydown', event => {
      if (event.key !== 'Enter' || event.shiftKey || event.altKey || event.ctrlKey || event.metaKey || event.isComposing || event.keyCode === 229 || event.repeat) return;
      const composer = D.composer(document);
      if (composer && (event.target === composer || composer.contains(event.target)) &&
          [...document.querySelectorAll('button')].some(D.sendButton)) sendingUser();
    }, true);
    document.addEventListener('submit', event => {
      const composer = D.composer(document);
      if (composer && event.target.contains(composer) && (!event.submitter || D.sendButton(event.submitter))) sendingUser('submit');
    }, true);
    function resume() {
      suspended = false; checkRetries = 0; hydrationTries = 0; probeStep = 0;
      clearTimeout(probeTimer); probeTimer = null;
      // Explicit restoration can retry an exhausted transport, but cannot unblock
      // a repository conflict or grant a new permission-exit baseline.
      if (attempt?.transportRevision != null && !attempt.blocked) attempt.tries = 0;
      if (!checking && (!checked || Date.now() - lastCheckAt >= 1000)) void check();
      schedule();
    }
    for (const name of ['popstate', 'hashchange']) window.addEventListener(name, schedule);
    for (const name of ['pageshow', 'focus']) window.addEventListener(name, resume);
    window.addEventListener('pagehide', () => {
      suspended = true;
      resetHealth();
      clearTimeout(timer); timer = null;
      clearTimeout(probeTimer); probeTimer = null;
      clearTimeout(checkTimer); checkTimer = null;
    });
    window.navigation?.addEventListener('currententrychange', schedule);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) resume(); });
    chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.sessionBookmarks) void check(); });
    syncRoute(); schedule();
  }
})();
