(function (root) {
  'use strict';
  const M = typeof module !== 'undefined' && module.exports ? require('./model.js') : root.BookmarkModel;
  const KEY = 'sessionBookmarksClosedWatch', ALARM = 'session-bookmarks-closed-watch';
  const RETRY_ALARM = 'session-bookmarks-monitor-checkpoint', RETRY_MS = 30000;
  const INTERVAL = 3 * 60 * 1000;
  const generating = reply => ['assistant', 'tool'].includes(reply?.author) && reply.phase === 'generating';
  function pageId(value) {
    try { const link = M.normalizeURL(value); return link.kind === 'chatgpt' ? link.id : null; }
    catch { return null; }
  }
  const markerOf = tab => /#workbench-refresh-[a-z0-9-]+$/.exec(tab?.pendingUrl || tab?.url || '')?.[0];
  const validId = id => typeof id === 'string' && pageId(`https://chatgpt.com/c/${id.slice(8)}`) === id;
  function createService({ browser, repository, isOtherTemporary = () => false, now = Date.now,
    timeoutMs = 20000, pollMs = 250, startupRestoreMs = 3000, startupQuietMs = 1000, startupMaxMs = 10000,
    claim = async () => ({ allowed: true }), preserveStartupDeadline = false, sourceHealth = async () => null, repairSource = async () => false }) {
    let state = { schema: 2, jobs: [], live: [], leases: [], history: [], confirmations: [], startup: null,
      ...(preserveStartupDeadline ? { policy: 'pending-3m' } : {}) };
    let initialized, serial = Promise.resolve(), ticking = null, manual = 0, startupRequested = false;
    const removed = new Map(), runtimeOwned = new Set();
    const focusedWindows = new Set(), invalidatedSources = new Set();
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    const command = operation => {
      const next = serial.catch(() => {}).then(operation); serial = next; return next;
    };
    let dirty = false;
    const persistence = () => ({ status: dirty ? 'retrying' : 'ok', failures: state.persistence?.failures || 0,
      lastFailureAt: state.persistence?.lastFailureAt ?? null, lastSuccessAt: state.persistence?.lastSuccessAt ?? null,
      nextRetryAt: dirty ? state.persistence?.nextRetryAt ?? null : null,
      reason: dirty ? 'storage-write-failed' : null });
    async function save() {
      dirty = true;
      for (let attempt = 0; attempt < 2; attempt++) {
        const previous = state.persistence || {};
        state.persistence = { ...persistence(), status: 'ok', reason: null, nextRetryAt: null, lastSuccessAt: now() };
        try {
          await browser.storage.local.set({ [KEY]: JSON.parse(JSON.stringify(state)) });
          dirty = false;
          await browser.alarms?.clear(RETRY_ALARM).catch(() => {});
          return;
        } catch {
          state.persistence = { ...previous, status: 'retrying', reason: 'storage-write-failed',
            failures: (previous.failures || 0) + 1, lastFailureAt: now(), nextRetryAt: now() + RETRY_MS };
        }
      }
      // No network action may pass a failed checkpoint. A separate alarm retries only storage.
      await browser.alarms?.create(RETRY_ALARM, { when: state.persistence.nextRetryAt }).catch(() => {});
      throw Error('monitor-persistence-failed');
    }
    async function retryPersistence() {
      await recover();
      return command(async () => { if (dirty) await save(); await schedule(); });
    }
    const load = async () => (await bounded(() => repository.dispatch('load', { activeOnly: true }))).state.bookmarks.filter(b => b.kind === 'chatgpt' && !b.archived && !b.archivedAt);
    const queryTabs = () => bounded(() => browser.tabs.query({}));
    const leaseFor = id => state.leases.find(l => l.tabId === id);
    function temporary(tab) {
      const lease = leaseFor(tab.id);
      return Boolean(lease && !lease.adopted || state.leases.some(l => l.tabId === null && markerOf(tab) === l.marker) || isOtherTemporary(tab));
    }
    const realTabs = tabs => tabs.filter(t => Number.isInteger(t.id) && !temporary(t) && pageId(t.pendingUrl || t.url));
    const hasReal = (tabs, id) => realTabs(tabs).some(t => pageId(t.pendingUrl || t.url) === id);
    const sameReply=(a,b)=>a&&b&&['author','phase','revision','messageId','userMessageId'].every(k=>(a[k]??null)===(b[k]??null));
    const sameObserved=(a,b)=>a&&b&&['author','phase','messageId','userMessageId'].every(k=>(a[k]??null)===(b[k]??null));
    const manualTickets=new Map();let manualSequence=0;
    const sourcesOf=job=>job.source?[job.source,...(job.source.peers||[])]:[];
    function sourcePresent(job,tabs){
      if(job.canceled)return false;
      const real=realTabs(tabs).filter(t=>pageId(t.pendingUrl||t.url)===job.id),sources=sourcesOf(job);
      if(!job.source)return !real.length;
      if(!job.manualPending&&sources.some(s=>invalidatedSources.has(s.tabId)))return false;
      return real.length===sources.length&&sources.every(source=>{
        const tab=real.find(t=>t.id===source.tabId);
        return tab&&(job.mode==='manual-receipt'||tab.active===false)&&tab.windowId===source.windowId&&tab.url===source.url&&
          (!tab.pendingUrl||tab.pendingUrl===source.url)&&tab.status!=='loading'&&
          (!['frozen','discarded'].includes(source.reason)||Boolean(tab.frozen||tab.discarded));
      });
    }
    async function sourceValid(job,tabs){
      if(!sourcePresent(job,tabs))return false;
      for(const source of sourcesOf(job)){
        const window=await bounded(()=>browser.windows.get(source.windowId));
        if(typeof window.focused!=='boolean'||job.canceled)return false;
        const health=await sourceHealth(source.tabId);
        if(health && (source.documentId&&health.documentId&&health.documentId!==source.documentId ||
          source.routeEpoch!=null&&health.routeEpoch!=null&&health.routeEpoch!==source.routeEpoch ||
          health.invalidation && health.invalidation.revision===(job.acceptedRevision??job.revision??job.confirmed?.revision)&&!sameObserved(health.invalidation.observed,source.baseline) ||
          job.mode!=='manual-receipt' && health.status==='available' && health.checkedAt>=job.requestedAt))return false;
      }
      return !job.canceled && (!job.source || sourcePresent(job,await queryTabs()));
    }
    function sourceChanged(tabId,observed,identity={}){
      for(const ticket of manualTickets.values())if(sourcesOf(ticket).some(s=>s.tabId===tabId))ticket.evidence.set(tabId,{observed,identity});
      const entries=[...state.jobs,...state.confirmations].filter(j=>sourcesOf(j).some(s=>s.tabId===tabId));
      if(entries.length&&entries.every(j=>{
        const source=sourcesOf(j).find(s=>s.tabId===tabId);
        return sameObserved(observed,source.baseline)&&(!identity.documentId||identity.documentId===source.documentId)&&
          (identity.routeEpoch==null||identity.routeEpoch===source.routeEpoch);
      }))return Promise.resolve();
      return cancelSource(tabId,true);
    }
    function cancelSource(tabId,observationOnly=false){
      if(!observationOnly)for(const ticket of manualTickets.values())if(sourcesOf(ticket).some(s=>s.tabId===tabId))ticket.canceled=true;
      invalidatedSources.add(tabId);
      if(!state.jobs.some(j=>sourcesOf(j).some(s=>s.tabId===tabId))&&!state.confirmations.some(c=>sourcesOf(c).some(s=>s.tabId===tabId)))return Promise.resolve();
      for(const job of state.jobs)if(sourcesOf(job).some(s=>s.tabId===tabId))job.canceled=true;
      state.confirmations=state.confirmations.filter(c=>!sourcesOf(c).some(s=>s.tabId===tabId));
      return command(async()=>{state.jobs=state.jobs.filter(j=>!j.canceled);await save();await schedule();});
    }
    async function beginManual({id,runId,sources,baseline}){
      await recover();
      const token=runId+':'+(++manualSequence),captured=(sources||[]).map(t=>({tabId:t.id,url:t.url,windowId:t.windowId,
        documentId:t.documentId||null,routeEpoch:t.routeEpoch??null,baseline:{...baseline}}));
      for(const source of captured)invalidatedSources.delete(source.tabId);
      const ticket={id,runId,mode:'manual-receipt',manualPending:true,requestedAt:now(),source:captured.length?{...captured[0],peers:captured.slice(1)}:null,evidence:new Map()};
      manualTickets.set(token,ticket);
      for(const source of sourcesOf(ticket)){
        const h=await sourceHealth(source.tabId);source.documentId ||= h?.documentId||null;source.routeEpoch ??= h?.routeEpoch??null;
      }
      return token;
    }
    function endManual(token){manualTickets.delete(token);}
    function manualEvidenceValid(ticket,receipt,collectorTabId) {
      return sourcesOf(ticket).every(source=>{const e=ticket.evidence.get(source.tabId);return !e || e.observed &&
        (sameObserved(e.observed,source.baseline)||source.tabId===collectorTabId&&sameObserved(e.observed,receipt.replyState)) &&
        (!e.identity.documentId||!source.documentId||e.identity.documentId===source.documentId) &&
        (e.identity.routeEpoch==null||source.routeEpoch==null||e.identity.routeEpoch===source.routeEpoch);});
    }
    async function confirmManual(token,{receipt,requestId,sentAt,collectorTabId}){
      const ticket=manualTickets.get(token);
      if(!ticket||ticket.canceled||!requestId?.startsWith(ticket.runId+':')||receipt?.requestId!==requestId||receipt.id!==ticket.id||pageId(receipt.url)!==ticket.id||
        !receipt.documentId||!Number.isSafeInteger(receipt.routeEpoch)||!Number.isSafeInteger(receipt.sampledAt)||receipt.sampledAt<sentAt||receipt.sampledAt>now()+1000)return false;
      const saved=(await load()).find(b=>b.id===ticket.id)?.replyState;
      if(!sameReply(receipt.replyState,saved)||receipt.storedRevision!==saved?.revision)return false;
      for(const source of sourcesOf(ticket)){
        const evidence=ticket.evidence.get(source.tabId);
        if(evidence&&(!evidence.observed||!sameObserved(evidence.observed,source.baseline)&&
          !(source.tabId===collectorTabId&&sameObserved(evidence.observed,receipt.replyState))))return false;
        if(source.tabId===collectorTabId){source.documentId=receipt.documentId;source.routeEpoch=receipt.routeEpoch;source.baseline={...saved};}
        else if(evidence?.identity.documentId&&source.documentId&&evidence.identity.documentId!==source.documentId)return false;
      }
      if(!await sourceValid(ticket,await queryTabs())||ticket.canceled)return false;
      if(!ticket.source)return true;
      return command(async()=>{
        const current=(await load()).find(b=>b.id===ticket.id)?.replyState;
        if(ticket.canceled||!sameReply(saved,current)||!await sourceValid(ticket,await queryTabs())||!manualEvidenceValid(ticket,receipt,collectorTabId))return false;
        for(const source of sourcesOf(ticket))invalidatedSources.delete(source.tabId);
        state.confirmations=[...state.confirmations.filter(c=>c.id!==ticket.id),{id:ticket.id,mode:'manual-receipt',runId:ticket.runId,requestId,
          source:structuredClone(ticket.source),requestedAt:ticket.requestedAt,version:browser.runtime.getManifest().version,confirmed:{...saved},
          checkedAt:now(),sampledAt:receipt.sampledAt,documentId:receipt.documentId,routeEpoch:receipt.routeEpoch}].slice(-128);
        await save();return true;
      });
    }
    async function requestRecovery(source){
      await recover();
      invalidatedSources.delete(source.tabId);
      return command(async()=>{
        const b=(await load()).find(b=>b.id===pageId(source.url));
        if(!b||!generating(b.replyState)||b.replyState.revision!==source.revision)return false;
        if(state.jobs.some(j=>j.id===b.id))return true;
        const tabs=await queryTabs(),peers=[];
        for(const tab of realTabs(tabs).filter(t=>pageId(t.pendingUrl||t.url)===b.id&&t.id!==source.tabId)){
          if(!tab.frozen&&!tab.discarded)return false;
          invalidatedSources.delete(tab.id);
          const health=await sourceHealth(tab.id);
          peers.push({tabId:tab.id,url:tab.url,windowId:tab.windowId,documentId:health?.documentId||null,
            routeEpoch:health?.routeEpoch??null,baseline:{...b.replyState},reason:tab.frozen?'frozen':'discarded'});
        }
        const h=await sourceHealth(source.tabId);
        const job={id:b.id,mode:'opened-recovery',source:{...source,peers,baseline:{...b.replyState},documentId:source.documentId||h?.documentId||null,
          routeEpoch:source.routeEpoch??h?.routeEpoch??null},revision:source.revision,requestedAt:now(),
          dueAt:now()+INTERVAL,attempts:0,version:browser.runtime.getManifest().version};
        if(!await sourceValid(job,await queryTabs()))return false;
        state.jobs.push(job);record(job.id,'opened-recovery-queued',{tabId:source.tabId});await save();await schedule();return true;
      });
    }
    async function isRecoveryPending(id){await recover();return state.jobs.some(j=>j.id===id&&j.mode==='opened-recovery'&&!j.canceled);}
    async function confirmations(){
      await recover();const tabs=await queryTabs(),bookmarks=await load(),result=[];
      for(const c of state.confirmations){
        if(c.version!==browser.runtime.getManifest().version||!sameReply(c.confirmed,bookmarks.find(b=>b.id===c.id)?.replyState)||!await sourceValid(c,tabs))continue;
        result.push({id:c.id,sourceTabId:c.source.tabId,source:c.mode==='manual-receipt'?'manual-receipt':'temporary-page',status:'available',reason:'temporary-confirmed',
          confirmed:{...c.confirmed},supersedes:sourcesOf(c).map(s=>({tabId:s.tabId,observed:s.baseline})),documentId:c.documentId,routeEpoch:c.routeEpoch,checkedAt:c.checkedAt,contentVersion:c.version});
      }
      return result;
    }
    function record(id, reason, extra = {}) {
      state.history.push({ id, at: now(), reason, ...extra }); state.history = state.history.slice(-80);
    }
    async function schedule() {
      const deadlines = state.leases.length || state.startup?.waitingForWindow ? [now() + INTERVAL] : state.jobs.map(j => j.dueAt);
      if (!deadlines.length) { await browser.alarms?.clear(ALARM); return; }
      await browser.alarms?.create(ALARM, { when: Math.max(now() + 1000, Math.min(...deadlines)) });
    }
    function enqueue(id, bookmarks, reason = 'last-generating-tab-closed') {
      const b = bookmarks.find(b => b.id === id);
      if (!b || !generating(b.replyState) || state.jobs.some(j => j.id === id)) return;
      state.jobs.push({ id, dueAt: now() + INTERVAL, revision: b.replyState.revision, attempts: 0 });
      record(id, reason);
    }
    function rememberClose(entry) {
      state.pendingCloses = (state.pendingCloses || []).filter(c => c.tabId !== entry.tabId && now() - c.at <= 30000);
      state.pendingCloses.push({ id: entry.id, tabId: entry.tabId, at: now() });
      state.pendingCloses = state.pendingCloses.slice(-128);
    }
    function resolveCloses(bookmarks, tabs) {
      state.pendingCloses = (state.pendingCloses || []).filter(c => now() - c.at <= 30000 && !hasReal(tabs, c.id));
      for (const entry of state.pendingCloses) {
        removed.set(entry.tabId, { id: entry.id, at: entry.at });
        enqueue(entry.id, bookmarks, 'late-generating-close-confirmed');
      }
    }
    async function bounded(operation, ms = timeoutMs) {
      let timer;
      try { return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
        timer = setTimeout(() => reject(Error('timeout')), Math.max(1, ms));
      })]); } finally { clearTimeout(timer); }
    }
    async function cleanup(lease) {
      let tab;
      try {
        const tabs = await queryTabs();
        const matching = tabs.filter(t => lease.tabId === null ? markerOf(t) === lease.marker : t.id === lease.tabId);
        if (matching.length > 1) { record(lease.id, 'ownership-unverified'); return false; }
        tab = matching[0];
        if (tab && lease.tabId === null) { lease.tabId = tab.id; if (!Number.isInteger(lease.windowId)) lease.windowId = tab.windowId; }
      }
      catch { record(lease.id, 'cleanup-query-failed', { tabId: lease.tabId }); return false; }
      if (!tab && lease.tabId === null && !lease.creationFailed) { record(lease.id, 'creation-pending'); return false; }
      if (tab && lease.kind === 'popup' && tab.windowId !== lease.windowId) lease.adopted = true;
      if (tab && lease.kind === 'popup' && !lease.adopted) {
        let window;
        try { window = await bounded(() => browser.windows.get(lease.windowId, { populate: true })); }
        catch { record(lease.id, 'cleanup-window-unverified'); return false; }
        if (!lease.ready && !window.focused && !focusedWindows.has(lease.windowId) && window.state !== 'minimized') {
          record(lease.id, 'minimize-unconfirmed'); return false;
        }
        if (focusedWindows.has(lease.windowId) || window.focused !== false || window.state !== 'minimized' || window.type !== 'popup' ||
            tab.windowId !== lease.windowId || window.tabs?.length !== 1 || window.tabs[0].id !== tab.id) lease.adopted = true;
        // A popup's sole tab is active even while its window is minimized.
        if (!lease.adopted && !runtimeOwned.has(tab.id) && markerOf(tab) !== lease.marker) { record(lease.id, 'ownership-unverified'); return false; }
      }
      if (!tab) { record(lease.id, 'temporary-closed', { tabId: lease.tabId }); }
      else if (lease.adopted || lease.kind !== 'popup' && tab.active && (runtimeOwned.has(tab.id) || markerOf(tab) === lease.marker)) {
        lease.adopted = true;
        if (pageId(tab.pendingUrl || tab.url) === lease.id) {
          state.live = state.live.filter(t => t.tabId !== tab.id);
          state.live.push({ tabId: tab.id, id: lease.id, adoptedMarker: lease.marker });
          state.jobs = state.jobs.filter(j => j.id !== lease.id);
        }
        record(lease.id, 'temporary-adopted', { tabId: lease.tabId });
      } else if (tab.windowId === lease.windowId && (runtimeOwned.has(tab.id) || markerOf(tab) === lease.marker)) {
        // Persist the lease until removal succeeds; failed cleanup occupies the single slot.
        try {
          if (lease.adopted) return false;
          lease.closing = true;
          // Removing its last owned tab closes the popup. A tab added after the window snapshot
          // survives this API call; windows.remove would also destroy that newly added user tab.
          const removed = await bounded(() => lease.adopted ? false : Promise.resolve(browser.tabs.remove(tab.id)).then(() => true));
          if (!removed) { lease.closing = false; record(lease.id, 'temporary-adopted', { tabId: tab.id }); return false; }
          record(lease.id, 'temporary-closed', { tabId: tab.id });
        }
        catch { lease.closing = false; record(lease.id, 'temporary-close-failed', { tabId: tab.id }); return false; }
      } else { record(lease.id, 'ownership-unverified', { tabId: lease.tabId }); return false; }
      state.leases = state.leases.filter(l => l !== lease); runtimeOwned.delete(lease.tabId);
      return true;
    }
    function recover() {
      if (initialized) return initialized;
      initialized = command(async () => {
        // Recovery already reconciled this worker's state before a checkpoint failed.
        // Do not reload an older journal over the pending close/job/lease transition.
        if (dirty) { await save(); await schedule(); return; }
        const stored = (await browser.storage.local.get(KEY))[KEY];
        if ([1, 2].includes(stored?.schema)) {
          state.persistence = { failures: Number.isSafeInteger(stored.persistence?.failures) ? stored.persistence.failures : 0,
            lastFailureAt: Number.isSafeInteger(stored.persistence?.lastFailureAt) ? stored.persistence.lastFailureAt : null,
            lastSuccessAt: Number.isSafeInteger(stored.persistence?.lastSuccessAt) ? stored.persistence.lastSuccessAt : null };
          state.pendingCloses = (Array.isArray(stored.pendingCloses) ? stored.pendingCloses : []).filter(c =>
            validId(c?.id) && Number.isInteger(c.tabId) && Number.isSafeInteger(c.at) && c.at <= now() && now() - c.at <= 30000).slice(-128);
          if (validId(stored.lastNavigation?.id) && Number.isSafeInteger(stored.lastNavigation.at)) state.lastNavigation = stored.lastNavigation;
          // Old/partial data grants neither an arbitrary URL nor tab-ID-only removal authority.
          state.jobs = (Array.isArray(stored.jobs) ? stored.jobs : []).filter(j => validId(j?.id) &&
            Number.isSafeInteger(j.dueAt) && j.dueAt >= 0 && Number.isSafeInteger(j.revision) && j.revision > 0)
            .map(j => ({ id: j.id, dueAt: j.dueAt, revision: j.revision, attempts: Number.isSafeInteger(j.attempts) ? j.attempts : 0,
            ...(j.mode==='opened-recovery'&&j.source&&Number.isInteger(j.source.tabId)&&pageId(j.source.url)===j.id?
              {mode:j.mode,source:j.source,requestedAt:j.requestedAt,version:j.version}: {}) }));
          state.confirmations=(Array.isArray(stored.confirmations)?stored.confirmations:[]).filter(c=>validId(c?.id)&&c.source&&Number.isInteger(c.source.tabId)&&pageId(c.source.url)===c.id).slice(-128);
          state.live = (Array.isArray(stored.live) ? stored.live : []).filter(t => validId(t?.id) && Number.isInteger(t.tabId))
            .map(t => ({ tabId: t.tabId, id: t.id, ...(typeof t.adoptedMarker === 'string' ? { adoptedMarker: t.adoptedMarker } : {}) }));
          state.leases = (Array.isArray(stored.leases) ? stored.leases : []).filter(l => validId(l?.id) &&
            /^#workbench-refresh-closed-[a-z0-9-]+$/.test(l.marker) && (l.tabId === null || Number.isInteger(l.tabId)))
            .map(l => ({ id: l.id, tabId: l.tabId, windowId: l.windowId, marker: l.marker, adopted: l.adopted === true,
              ...(l.kind === 'popup' ? { kind: 'popup', ready: l.ready === true } : {}),
              ...(l.creationFailed === true ? { creationFailed: true } : {}) }));
          if (stored.startup?.pending === true && Number.isSafeInteger(stored.startup.readyAt) && Number.isSafeInteger(stored.startup.maxAt)) {
            state.startup = { pending: true, readyAt: stored.startup.readyAt, maxAt: stored.startup.maxAt,
              waitingForWindow: stored.startup.waitingForWindow === true };
          }
          state.history = (Array.isArray(stored.history) ? stored.history : []).filter(h => validId(h?.id) &&
            Number.isSafeInteger(h.at) && /^[a-z-]{1,60}$/.test(h.reason)).slice(-80).map(h => ({
              id: h.id, at: h.at, reason: h.reason, ...(Number.isInteger(h.tabId) ? { tabId: h.tabId } : {}),
              ...(typeof h.verified === 'boolean' ? { verified: h.verified } : {}),
              ...(['generating', 'complete'].includes(h.phase) ? { phase: h.phase } : {}),
              ...(Number.isSafeInteger(h.attempts) ? { attempts: h.attempts } : {}) }));
          // Upgrade old catch-up journals before an overdue alarm can use their immediate deadline.
          if (preserveStartupDeadline && stored.policy !== 'pending-3m') {
            for (const job of state.jobs) job.dueAt = Math.max(job.dueAt, now() + INTERVAL);
            state.startup = null;
          }
        }
        let tabs = await queryTabs();
        const bookmarks = state.jobs.length || state.live.length || state.pendingCloses?.length ? await load() : [];
        for (const lease of [...state.leases]) {
          if (lease.tabId === null) {
            const matching = tabs.filter(t => markerOf(t) === lease.marker);
            const tab = matching.length === 1 ? matching[0] : null;
            if (tab) { lease.tabId = tab.id; if (!Number.isInteger(lease.windowId)) lease.windowId = tab.windowId; }
          }
          await cleanup(lease);
        }
        tabs = await queryTabs();
        // Only a persisted real document can supply a missed shutdown/close transition.
        // Convert a missed source close before enqueue performs per-id deduplication.
        for(const job of state.jobs)if(job.source&&!hasReal(tabs,job.id)){
          delete job.source;delete job.mode;delete job.acceptedRevision;
          record(job.id,'opened-source-closed');
        }
        for (const live of state.live) if (!hasReal(tabs, live.id)) { rememberClose(live); enqueue(live.id, bookmarks); }
        resolveCloses(bookmarks, tabs);
        state.jobs = state.jobs.filter((j, i, all) => all.findIndex(x => x.id === j.id) === i &&
          generating(bookmarks.find(b => b.id === j.id)?.replyState) && sourcePresent(j,tabs) && (!j.source||j.version===browser.runtime.getManifest().version));
        state.live = realTabs(tabs).map(t => ({ tabId: t.id, id: pageId(t.pendingUrl || t.url),
          ...(state.live.find(l => l.tabId === t.id)?.adoptedMarker ? { adoptedMarker: markerOf(t) } : {}) }));
        if (startupRequested && preserveStartupDeadline) for (const job of state.jobs) job.dueAt = Math.max(job.dueAt, now() + INTERVAL);
        if (!state.jobs.length) state.startup = null;
        await save(); await schedule();
      });
      initialized.catch(() => { initialized = null; });
      return initialized;
    }
    async function tabSeen(tab) {
      if(!temporary(tab))for(const job of state.jobs)if(job.source&&pageId(tab?.pendingUrl||tab?.url)===job.id&&
        !sourcesOf(job).some(s=>s.tabId===tab.id))job.canceled=true;
      const preparing=leaseFor(tab?.id);
      if(preparing?.navigationPending && (tab.windowId!==preparing.windowId ||
        (tab.pendingUrl||tab.url)!=='about:blank'+preparing.marker)) preparing.adopted=true;
      await recover();
      return command(async () => {
        if (!Number.isInteger(tab?.id)) return;
        let id = pageId(tab.pendingUrl || tab.url);
        if (temporary(tab)) return;
        const previous = state.live.find(t => t.tabId === tab.id);
        if (!id && !previous || previous?.id === id && !state.jobs.some(j => j.id === id)) return;
        // Events can queue during a rapid A -> B -> A route change. Reconcile the real
        // document before retiring A, and never give a temporary collector a live identity.
        const tabs = previous && previous.id !== id ? await queryTabs() : null;
        if (tabs) {
          tab = tabs.find(t => t.id === tab.id);
          if (!tab || temporary(tab)) return;
          id = pageId(tab.pendingUrl || tab.url);
          if (previous.id === id && !state.jobs.some(j => j.id === id)) return;
        }
        state.live = state.live.filter(t => t.tabId !== tab.id);
        if (previous && previous.id !== id && !hasReal(tabs, previous.id))
          enqueue(previous.id, await load(), 'last-generating-tab-left');
        if (id) {
          state.live.push({ tabId: tab.id, id, ...(previous?.adoptedMarker && previous.adoptedMarker === markerOf(tab) ? { adoptedMarker: previous.adoptedMarker } : {}) });
          const currentTabs=await queryTabs();
          const retained=state.jobs.find(j=>j.id===id&&sourcesOf(j).some(s=>s.tabId===tab.id)&&sourcePresent(j,currentTabs));
          if(retained){await save();await schedule();return;}
          state.confirmations=state.confirmations.filter(c=>c.id!==id);
          const canceled = state.jobs.some(j => j.id === id);
          state.jobs = state.jobs.filter(j => j.id !== id);
          if (canceled) record(id, 'user-reopened');
        }
        await save(); await schedule();
      });
    }
    function tabRemoved(tabId) {
      for(const job of state.jobs)if(sourcesOf(job).some(s=>s.tabId===tabId)){delete job.source;delete job.mode;delete job.acceptedRevision;}
      state.confirmations=state.confirmations.filter(c=>!sourcesOf(c).some(s=>s.tabId===tabId));
      // Capture before asynchronous work; this also authorizes a previously validated in-flight generating write.
      const live = state.live.find(t => t.tabId === tabId);
      const lease = leaseFor(tabId);
      if (lease?.kind === 'popup' && !lease.closing && !lease.closed) {
        lease.closed = true; record(lease.id, 'check-window-closed');
      }
      if (live) removed.set(tabId, { id: live.id, at: now() });
      for (const [id, entry] of removed) if (now() - entry.at > 30000) removed.delete(id);
      return recover().then(() => command(async () => {
        const entry = state.live.find(t => t.tabId === tabId);
        if (!entry && !leaseFor(tabId)) return;
        if (entry && !leaseFor(tabId)) {
          const tabs = await queryTabs();
          if (!hasReal(tabs, entry.id)) enqueue(entry.id, await load());
          rememberClose(entry);
        }
        state.live = state.live.filter(t => t.tabId !== tabId);
        await save(); await schedule();
      }));
    }
    const wasRemoved = (tabId, id) => removed.get(tabId)?.id === id && now() - removed.get(tabId).at <= 30000;
    async function observed(tabId, id, result) {
      const lease=leaseFor(tabId),job=state.jobs.find(j=>j.id===id);
      if(lease&&!lease.adopted&&job?.source&&result?.current){job.acceptedRevision=result.current.revision;return;}
      if (!wasRemoved(tabId, id)) return;
      await recover();
      return command(async () => {
        if (result?.bookmarked && wasRemoved(tabId, id) && generating(result.current)) {
          if (!hasReal(await queryTabs(), id)) enqueue(id, await load());
        }
        await save(); await schedule();
      });
    }
    async function adopt(tabId, reason = 'trusted-user-takeover') {
      void cancelSource(tabId);
      // Mark synchronously so cleanup waiting on a browser API sees a newly delivered claim.
      const pendingLease = leaseFor(tabId);
      if (pendingLease) pendingLease.adopted = true;
      await recover();
      return command(async () => {
        const lease = leaseFor(tabId);
        if (!lease) return false;
        lease.adopted = true;
        const tab = await bounded(() => browser.tabs.get(tabId)).catch(() => null);
        if (pageId(tab?.pendingUrl || tab?.url) === lease.id) {
          state.live = state.live.filter(t => t.tabId !== tabId);
          state.live.push({ tabId, id: lease.id, adoptedMarker: lease.marker });
          state.jobs = state.jobs.filter(j => j.id !== lease.id);
        }
        record(lease.id, reason, { tabId });
        await save(); await schedule(); return true;
      });
    }
    async function tabActivated(tabId) {
      void cancelSource(tabId);
      if (!state.leases.length) return false;
      if (leaseFor(tabId)?.kind === 'popup') return windowChanged({ id: leaseFor(tabId).windowId });
      if (leaseFor(tabId)) return adopt(tabId);
      const tab = await bounded(() => browser.tabs.get(tabId));
      const intent = state.leases.find(l => l.tabId === null && markerOf(tab) === l.marker);
      if (!intent) return false;
      intent.tabId = tabId; intent.windowId = tab.windowId;
      return intent.kind === 'popup' ? windowChanged({ id: tab.windowId }) : adopt(tabId);
    }
    function ownsWindow(windowId) { return state.leases.some(l => l.kind === 'popup' && l.windowId === windowId); }
    async function windowChanged(window, focused = false) {
      if (focused) {
        focusedWindows.add(window.id);
        for(const job of state.jobs)if(job.source&&state.leases.some(l=>l.id===job.id))job.canceled=true;
      }
      const lease = state.leases.find(l => l.kind === 'popup' && l.windowId === window.id);
      if (!lease) return false;
      if (focused || window.focused || lease.ready && window.state && window.state !== 'minimized') lease.adopted = true;
      if (!lease.ready && !lease.adopted) return false;
      const current = await bounded(() => browser.windows.get(window.id));
      if (lease.adopted || current.focused || current.state !== 'minimized') return adopt(lease.tabId, 'window-takeover');
      return false;
    }
    function windowRemoved(windowId) {
      focusedWindows.delete(windowId);
      const lease = state.leases.find(l => l.kind === 'popup' && l.windowId === windowId);
      if (!lease || lease.closing || lease.closed) return Promise.resolve();
      lease.closed = true;
      return command(async () => { record(lease.id, 'check-window-closed'); await save(); });
    }
    async function startup(source = 'browser') {
      if (startupRequested) return ticking;
      startupRequested = true;
      await recover();
      await command(async () => {
        if (!state.jobs.length) return;
        for (const job of state.jobs) {
          job.dueAt = preserveStartupDeadline ? Math.max(job.dueAt, now() + INTERVAL) : now();
          record(job.id, preserveStartupDeadline ? source === 'install' ? 'install-deferred' : 'startup-deferred' : source === 'install' ? 'install-catchup' : 'browser-startup-catchup');
        }
        state.startup = preserveStartupDeadline ? null : { pending: true, readyAt: now() + startupRestoreMs, maxAt: now() + startupMaxMs, waitingForWindow: false };
        await save(); await schedule();
      });
      if (state.jobs.length) return tick();
    }
    async function settleStartup() {
      const restore = state.startup;
      if (!restore) return true;
      const windows = await bounded(() => browser.windows.getAll({ windowTypes: ['normal'] }));
      if (!windows.some(w => w.type === 'normal' && Number.isInteger(w.id))) {
        restore.waitingForWindow = true; await command(async () => { await save(); await schedule(); }); return false;
      }
      if (restore.waitingForWindow) {
        restore.readyAt = now() + startupRestoreMs; restore.maxAt = now() + startupMaxMs; restore.waitingForWindow = false;
      }
      const end = Date.now() + Math.min(startupMaxMs, Math.max(0, restore.maxAt - now()));
      let ready = Date.now() + Math.max(0, restore.readyAt - now()), signature;
      while (Date.now() < Math.min(end, ready)) {
        const tabs = await queryTabs();
        const next = JSON.stringify(tabs.filter(t => !temporary(t)).map(t => [t.id, t.windowId, t.pendingUrl || t.url, t.status]).sort((a,b) => a[0]-b[0]));
        if (signature !== undefined && signature !== next) ready = Math.max(ready, Date.now() + startupQuietMs);
        signature = next; await pause(Math.min(pollMs, Math.max(1, Math.min(end, ready) - Date.now())));
      }
      await command(async () => { if (state.startup === restore) state.startup = null; await save(); });
      return true;
    }
    function windowCreated(window) {
      if (window.type !== 'normal') return Promise.resolve();
      return recover().then(async () => {
        if (!state.startup) return;
        // A first window can arrive while the no-window query is still resolving.
        if (ticking) await ticking;
        if (state.startup) return tick();
      });
    }
    async function authorizeObservation(tabId, id) {
      const lease = leaseFor(tabId);
      if (!lease || lease.adopted) return;
      const job=state.jobs.find(j=>j.id===id);
      if(lease.id!==id||!job||!await sourceValid(job,await queryTabs()))throw Error('closed-check-canceled');
      if(job.source){
        // Read storage directly: this guard also runs inside the repository's serialized write.
        const raw=await browser.storage.local.get('sessionBookmarks');
        const saved=raw.sessionBookmarks?.bookmarks.find(b=>b.id===id)?.replyState;
        if(saved?.revision!==(job.acceptedRevision??job.revision)||job.canceled)throw Error('opened-check-stale');
        if(!sourcePresent(job,await queryTabs()))throw Error('closed-check-canceled');
      }
    }
    async function reconcile() {
      await recover();
      return command(async () => {
        if (!state.jobs.length && !state.pendingCloses?.length) return;
        const bookmarks = await load();
        const previousJobs = state.jobs.length, previousCloses = state.pendingCloses?.length || 0;
        resolveCloses(bookmarks, await queryTabs());
        const jobs = state.jobs.filter(j => bookmarks.some(b => b.id === j.id) &&
          (state.leases.some(l => l.id === j.id) || generating(bookmarks.find(b => b.id === j.id).replyState)));
        if (jobs.length === previousJobs && previousCloses === state.pendingCloses.length) return;
        state.jobs = jobs;
        await save(); await schedule();
      });
    }
    // The manual all-sessions refresh can observe a still-generating conversation
    // without an existing real tab. It must enter the same three-minute monitor as
    // a user-closed generating tab, rather than vanishing when its temporary tab closes.
    async function continueAfterManual(result) {
      const ids = [...new Set((result?.details || []).filter(detail => detail.kind === 'chatgpt' &&
        detail.result === 'success' && detail.verification === 'verified-dom' &&
        detail.storageVerified === true && detail.observation?.phase === 'generating').map(detail => detail.id))];
      if (!ids.length) return { scheduled: 0 };
      await recover();
      return command(async () => {
        const [tabs, bookmarks] = await Promise.all([queryTabs(), load()]);
        let scheduled = 0;
        for (const id of ids) {
          if (hasReal(tabs, id)) continue;
          const previous = state.jobs.length;
          enqueue(id, bookmarks, 'manual-refresh-generating');
          if (state.jobs.length > previous) scheduled++;
        }
        if (scheduled) { await save(); await schedule(); }
        return { scheduled };
      });
    }
    async function check(job) {
      let lease, reason = 'timeout', verified = false, phase = null, creationStarted = false;
      try {
        await command(async () => {
          const b = (await load()).find(b => b.id === job.id), tabs = await queryTabs();
          if (!state.jobs.includes(job) || !b || !generating(b.replyState) || !await sourceValid(job,tabs) || job.source&&b.replyState.revision!==job.revision) {
            state.jobs = state.jobs.filter(j => j !== job); reason = 'not-generating-or-reopened'; return;
          }
          const windows = browser.windows?.getAll ? await bounded(() => browser.windows.getAll({ windowTypes: ['normal'] })) :
            tabs.map(t => ({ id: t.windowId }));
          const windowId = windows.find(w => Number.isInteger(w.id) && w.id >= 0)?.id;
          if (windowId === undefined) { reason = 'no-browser-window'; return; }
          const budget = await claim(job.id, job.source?'opened-recovery':'closed');
          if (!budget.allowed) { job.dueAt = budget.nextAt; reason = 'cadence'; return; }
          if(job.source && await repairSource(job.source.tabId)){
            state.jobs=state.jobs.filter(j=>j!==job);reason='receiver-repaired';return;
          }
          if(!await sourceValid(job,await queryTabs())){state.jobs=state.jobs.filter(j=>j!==job);reason='source-changed';return;}
          // An intent is durable before create, covering worker loss before tabs.create returns.
          lease = { id: job.id, tabId: null, windowId: null, kind: 'popup', ready: false, adopted: false,
            marker: `#workbench-refresh-closed-${now().toString(36)}-${Math.random().toString(36).slice(2)}` };
          state.leases.push(lease); job.attempts++; await save();
          creationStarted = true;
          let creation;
          try { creation = Promise.resolve(browser.windows.create({ url: 'about:blank' + lease.marker, focused: false, state: 'minimized', type: 'popup' })); }
          catch (error) { lease.creationFailed = true; throw error; }
          // A late API result keeps the durable intent and occupies capacity until it can be cleaned.
          creation.then(window => {
            const tab = window?.tabs?.[0];
            if (!Number.isInteger(window?.id) || !Number.isInteger(tab?.id)) return;
            lease.tabId = tab.id; lease.windowId = window.id; runtimeOwned.add(tab.id);
            if (window.focused || focusedWindows.has(window.id)) lease.adopted = true;
          }, () => { lease.creationFailed = true; });
          const window = await bounded(() => creation), tab = window?.tabs?.[0];
          if (!Number.isInteger(window?.id) || !Number.isInteger(tab?.id)) throw Error('create-failed');
          await save();
          let current = await bounded(() => browser.windows.get(window.id, { populate: true }));
          if (lease.adopted || current.focused !== false || current.type !== 'popup' || current.tabs?.length !== 1 || current.tabs[0].id !== tab.id) { lease.adopted = true; return; }
          // Edge may ignore the initial minimized state. Only the marked blank document exists during this fallback.
          if (current.state !== 'minimized') await bounded(() => {
            if (lease.adopted || focusedWindows.has(window.id)) return;
            return browser.windows.update(window.id, { state: 'minimized' });
          });
          current = await bounded(() => browser.windows.get(window.id, { populate: true }));
          if (lease.adopted || current.focused !== false || current.state !== 'minimized' || current.tabs?.length !== 1 || current.tabs[0].id !== tab.id) { lease.adopted = true; return; }
          lease.ready = true; lease.navigationPending=true; record(job.id, 'navigation-pending', {tabId:tab.id}); await save();
          // A session-restored real tab can arrive while the window was being prepared.
          if (!await sourceValid(job,await queryTabs()) || !state.jobs.includes(job) || manual || lease.adopted) { reason = 'canceled'; return; }
          // This exception is only for the checker's new minimized blank popup,
          // never an existing user-selected page. Revalidate after all writes/queries.
          const finalWindow = await bounded(() => browser.windows.get(lease.windowId, { populate: true }));
          const finalTab = await bounded(() => browser.tabs.get(tab.id));
          const guard = { at:now(), active:typeof finalTab.active==='boolean'?finalTab.active:null,
            windowFocused:typeof finalWindow.focused==='boolean'?finalWindow.focused:null,
            windowId:finalTab.windowId, decision:'owned-minimized-blank' };
          const safeBlank = finalTab.windowId===lease.windowId && (finalTab.pendingUrl||finalTab.url)==='about:blank'+lease.marker &&
            finalWindow.focused===false && finalWindow.type==='popup' && finalWindow.state==='minimized' &&
            finalWindow.tabs?.length===1 && finalWindow.tabs[0].id===tab.id && runtimeOwned.has(tab.id);
          await bounded(() => {
            if (!safeBlank || lease.adopted || lease.closed || focusedWindows.has(lease.windowId) || manual || job.canceled || !state.jobs.includes(job)) {
              lease.adopted=true;reason='temporary-adopted';guard.decision='interaction-or-ownership-changed';
              record(job.id,'navigation-blocked',{tabId:tab.id,guard});return;
            }
            state.lastNavigation={id:job.id,tabId:tab.id,at:now(),action:'navigate-requested',reason:job.source?'opened-recovery-check':'closed-generating-check',guard};
            record(job.id,'navigation-requested',{tabId:tab.id,guard});
            lease.navigationPending=false;
            return browser.tabs.update(tab.id, { url: b.url.split('#')[0] + lease.marker });
          });
        });
        if (!lease) return;
        const end = Date.now() + timeoutMs;
        while (Date.now() < end) {
          if (manual || lease.adopted || lease.closed || !state.jobs.includes(job) || !await sourceValid(job,await queryTabs())) {
            reason = lease.adopted ? 'temporary-adopted' : 'canceled'; break;
          }
          const tab = await bounded(() => browser.tabs.get(lease.tabId), end - Date.now());
          const window = await bounded(() => browser.windows.get(lease.windowId));
          if (window.focused || window.state !== 'minimized') { await adopt(tab.id); reason = 'temporary-adopted'; break; }
          if (pageId(tab.pendingUrl || tab.url) !== job.id || tab.windowId !== lease.windowId) { reason = 'route-changed'; break; }
          if (tab.status === 'loading') { await pause(pollMs); continue; }
          const requestId = `${lease.marker}:${now()}`, sentAt = now();
          let receipt;
          try { receipt = await bounded(() => browser.tabs.sendMessage(tab.id,
            { channel: 'session-bookmarks-refresh', action: 'rescan', id: job.id, temporary: true, requestId }, { frameId: 0 }), Math.min(1500, end - Date.now())); }
          catch { reason = 'receiver-unavailable'; await pause(pollMs); continue; }
          const current = await bounded(() => browser.tabs.get(tab.id), end - Date.now());
          const currentWindow = await bounded(() => browser.windows.get(lease.windowId));
          if (currentWindow.focused || currentWindow.state !== 'minimized') { await adopt(tab.id); reason = 'temporary-adopted'; break; }
          if (lease.adopted || lease.closed || !state.jobs.includes(job) || !await sourceValid(job,await queryTabs())) { reason = 'canceled'; break; }
          if (pageId(current.url) !== job.id || current.pendingUrl && pageId(current.pendingUrl) !== job.id || current.status === 'loading') { reason = 'route-changed'; break; }
          const r = receipt?.replyState;
          if (receipt?.noData || receipt?.stateConflict || r?.phase === 'unknown') reason = receipt.stateConflict ? 'state-conflict' : 'no-data';
          else if (receipt?.version === browser.runtime.getManifest().version && receipt.id === job.id && pageId(receipt.url) === job.id &&
              receipt.requestId === requestId && Number.isSafeInteger(receipt.sampledAt) && receipt.sampledAt >= sentAt && receipt.sampledAt <= now() + 1000 &&
              receipt.initialized === true && receipt.diagnostic?.stage !== 'candidate' &&
              (generating(r) || ['assistant','tool'].includes(r?.author) && ['complete','awaiting_permission'].includes(r.phase))) {
            const saved = (await load()).find(b => b.id === job.id)?.replyState;
            verified = Boolean(saved && Number.isSafeInteger(r.revision) && receipt.storedRevision === r.revision &&
              ['author', 'phase', 'revision', 'messageId', 'userMessageId'].every(k => (saved[k] ?? null) === (r[k] ?? null)));
            if (verified) {
              phase=r.phase;reason=phase==='complete'?'assistant-complete':phase==='awaiting_permission'?'awaiting-permission':'still-generating';
              if(job.source)state.confirmations=[...state.confirmations.filter(c=>c.id!==job.id),
                {id:job.id,source:{...job.source},requestedAt:job.requestedAt,version:browser.runtime.getManifest().version,
                  confirmed:{...r},checkedAt:now(),documentId:receipt.documentId,routeEpoch:receipt.routeEpoch}].slice(-128);
              break;
            }
            reason = 'storage-unacknowledged';
          }
          await pause(pollMs);
        }
      } catch (error) {
        if (lease && !creationStarted) lease.creationFailed = true;
        reason = error?.message === 'timeout' ? 'timeout' : 'tab-operation-failed';
      }
      finally {
        await command(async () => {
          // Keep the marked page discoverable if its identity checkpoint failed.
          // Otherwise a crash after cleanup would leave a durable creation intent
          // with neither a page nor proof that creation finished.
          if (lease && dirty) await save();
          if (lease) await cleanup(lease);
          record(job.id, reason, { verified, phase, attempts: job.attempts });
          if (job.canceled || verified && ['complete','awaiting_permission'].includes(phase)) state.jobs = state.jobs.filter(j => j !== job);
          else if (state.jobs.includes(job) && reason !== 'cadence') {
            job.dueAt = now() + INTERVAL;
            if(job.acceptedRevision)job.revision=job.acceptedRevision;
          }
          await save(); await schedule();
        });
      }
    }
    function tick() {
      if (ticking) return ticking;
      ticking = (async () => {
        await recover();
        if (manual) return;
        if (!state.jobs.length && !state.leases.length) return;
        // onStartup may be queued behind recovery while this alarm is delivered in the same turn.
        await command(() => {});
        if (!await settleStartup()) return;
        await command(async () => { for (const lease of [...state.leases]) await cleanup(lease); await save(); });
        // A failed or unverified close occupies capacity; each alarm performs at most two sequential checks.
        for (let count = 0; count < 2 && !manual && !state.leases.length; count++) {
          const job = [...state.jobs].sort((a, b) => a.dueAt - b.dueAt).find(j => j.dueAt <= now());
          if (!job) break;
          await check(job);
        }
        await command(schedule);
      })().catch(async () => {
        await command(async () => {
          for (const job of state.jobs) if (job.dueAt <= now()) job.dueAt = now() + INTERVAL;
          await save(); await schedule();
        });
      }).finally(() => { ticking = null; });
      return ticking;
    }
    async function withManualRun(operation) {
      manual++;
      try { await recover(); if (ticking) await ticking; return await operation(); }
      finally { manual--; await command(schedule); }
    }
    return { recover, startup, tick, tabSeen, tabRemoved, tabActivated, windowChanged, windowRemoved, windowCreated, ownsWindow,
      retryPersistence, persistence, beginManual,confirmManual,endManual,requestRecovery, isRecoveryPending, confirmations, sourceChanged, cancelSource, observed, adopt, wasRemoved, authorizeObservation, reconcile, continueAfterManual, withManualRun, isTemporary: temporary };
  }
  const api = { KEY, ALARM, RETRY_ALARM, INTERVAL, pageId, generating, createService };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.BookmarkClosedWatch = api;
})(globalThis);
